import React, { useEffect } from "react";

import { connect, useDispatch } from "react-redux";
import { push } from "connected-react-router";
import { useLocation } from "react-router";
import Header from "../../components/Header/component";
import { logoutAction } from "../../../users/actions/currentUser/actions";

import "./styles.scss";
import { activateProjectAction } from "../../../projects/actions/projects/actions";
import { openRightColumnContainerAction } from "../../../shared/actions/RightColumnContainer/actions";
import { usersCRUDActions } from "../../../users/actions/actions";
import { WIDGET_TYPES } from "../../../shared/constants/widgetTypes";
import { refreshProjectDataAction } from "../../../projects/actions/actions";
import { selectActiveProject } from "../../../projects/selectors/projects";
import {
    canAdministrateCompanies,
    canAdministrateProjects,
    canAdministrateUsers,
} from "../../../users/selectors/permissions";
import { getURL } from "../../../shared/helpers/getPath";

import { systemSettingsCRUDActions } from "../../actions/actions";

// TODO: this is in-between two worlds
function HeaderContainer(props) {
    const location = useLocation();
    const {
        selections, activateProject, user, roleName, logout, openRightColumn, getUserDetails,
        selectUser, project, refresh, showProjectsAdminPanelLink, showUsersAdminPanelLink,
        showCompaniesAdminPanelLink, routerPathParams,
    } = props;

    const preview = () => {
        // TODO: this object uses wrong user model without converters and styles
        getUserDetails({ source: { key: user.sid } });
        selectUser({ key: user.sid });
        openRightColumn(WIDGET_TYPES.USER_PROFILE, { key: user.sid, ...user });
    };

    const edit = () => {
        // TODO: this object uses wrong user model without converters and styles
        openRightColumn(WIDGET_TYPES.USER_MANAGEMENT_FORM, { key: user.sid });
        selectUser({ key: user.sid });
        getUserDetails({ source: { key: user.sid } });
    };

    const refreshData = () => {
        refresh(project);
    };

    const dispatch = useDispatch();

    // const handleSelectItem = (id) => {
    //     const path = getURL(routerPathParams, ["projects", "section", "group", ["document", id]]);
    //     dispatch(push(path));
    // };

    const handleChangeSelected = (sid) => {
        // activateProject(selections[sid]);
        const path = getURL(routerPathParams, [["projects", sid]]);
        dispatch(push(path));
    };

    useEffect(() => {
        const projectId = selections[routerPathParams.projects];
        // const project = selections[sid];

        if (projectId) {
            activateProject(projectId);
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        routerPathParams.projects,
        selections,
    ]);

    useEffect(() => {
        if (project && location.pathname === "/") {
            const path = getURL(routerPathParams, [["projects", project.key]]);
            dispatch(push(path));
        }
    }, [dispatch, location, project, routerPathParams]);

    const handleOpenSystemSettings = () => {
        dispatch(systemSettingsCRUDActions.use.ENTITY_FORM_EDIT({ widget: WIDGET_TYPES.SYSTEM_SETTINGS, sid: "default" }));
        // openRightColumn(WIDGET_TYPES.SYSTEM_SETTINGS);
    };

    return (
        <Header
            currentSelect={routerPathParams.projects}
            selections={selections}
            changeSelected={handleChangeSelected}
            fullname={user.full_name}
            roleName={roleName}
            avatar={user.avatar}
            position={user.position}
            company={user.company}
            logout={logout}
            project={project}
            refreshData={refreshData}
            showProjectsAdminPanelLink={showProjectsAdminPanelLink}
            showUsersAdminPanelLink={showUsersAdminPanelLink}
            showCompaniesAdminPanelLink={showCompaniesAdminPanelLink}
            openOwnProfilePreview={preview}
            openOwnProfileSettings={edit}
            openSystemSettings={handleOpenSystemSettings}
        />
    );
}

const mapStateToProps = (store) => ({
    showProjectsAdminPanelLink: canAdministrateProjects(store),
    showUsersAdminPanelLink: canAdministrateUsers(store),
    showCompaniesAdminPanelLink: canAdministrateCompanies(store),
    project: selectActiveProject(store),
    currentSelect: store.projects.list.active,
    selections: store.projects.crud.items,
    user: store.users.currentUser.user,
    roleName: store.users.currentUser.roleName,
    routerPathParams: store.core.router,
});

export default connect(mapStateToProps, {
    activateProject: activateProjectAction,
    openRightColumn: openRightColumnContainerAction,
    getUserDetails: usersCRUDActions.use.GET_ENTITY_DETAILS,
    selectUser: usersCRUDActions.use.SELECT_SINGLE_ENTITY,
    logout: logoutAction,
    refresh: refreshProjectDataAction,
})(HeaderContainer);
