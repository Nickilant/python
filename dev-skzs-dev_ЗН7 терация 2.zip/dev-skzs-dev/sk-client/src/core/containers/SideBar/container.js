import React from "react";
import cx from "classnames";
import { useSelector } from "react-redux";
import SideBarSearch from "../../components/SideBarSearch/component";
import SideBarMenu from "../../components/SideBarMenu/component";
import { SideBarDate } from "../../components/SideBarDate/component";
import "./styles.scss";
import { menuWithSections } from "../../selectors/menu";

export const SideBar = ({ sidebarOpen, setSidebarOpen }) => {
    const menu = useSelector((state) => menuWithSections(state.core.sidebar.menu, state.projects.list.active, state.categories.treeStructure.nested_tree));

    const toggleSidebar = () => {
        setSidebarOpen(!sidebarOpen);
    };

    return (
        <div className={cx("sidebar", { open: sidebarOpen })}>
            <span className="menu-icon icon" onClick={toggleSidebar} />
            <SideBarSearch />
            <SideBarMenu menu={menu} />
            <SideBarDate />
        </div>

    );
};
