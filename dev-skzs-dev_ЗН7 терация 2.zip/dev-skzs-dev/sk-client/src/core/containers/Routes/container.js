import React from "react";

import { connect } from "react-redux";

import { Route, Switch } from "react-router-dom";

import { changeSectionAction } from "../../../projects/actions/actions";

import { DocumentsPage } from "../../../documents/pages/Index/page";
import { ExecutiveDocumentationPage } from "../../../executive_documentation/pages/Index/component";
import { JournalsPage } from "../../../executive_documentation/pages/Journal/component";
import { ConstructionControlPage } from "../../../construction_control/base/pages/Index/page";
import { activateProjectAction } from "../../../projects/actions/projects/actions";
import { categoryByName } from "../../selectors/menu";
import { ConstructionControlGeoDataPage } from "../../../construction_control/extra_2d/pages/Index/page";
import { ActivitiesPage } from "../../../activities/pages/Index/page";
import { AirMonitoringPage } from "../../../air_monitoring/pages/Index/component";

const Routes = (props) => {
    const {
        tree, match, changeSection, selectedSection, project_id,
    } = props;

    const new_section_name = match.params.section_name;
    const new_project_id = match.params.project_id;

    if (project_id !== new_project_id) {
        // projects[new_project_id] && activateProject(projects[new_project_id]);
    }

    const section = categoryByName(tree, new_section_name);
    const sectionSid = section && section.sid;

    if (selectedSection !== sectionSid) {
        changeSection(section);
    }

    return (
        <Switch>
            <Route path="/projects/:project_id/section/air-monitoring" component={AirMonitoringPage} />
            <Route path="/projects/:project_id/section/activities" component={ActivitiesPage} />
            <Route path="/projects/:project_id/section/geodata" component={ConstructionControlGeoDataPage} />
            <Route path="/projects/:project_id/section/executive-documents/group/:group_name/journals/:journal_id" component={JournalsPage} />
            <Route path="/projects/:project_id/section/executive-documents" component={ExecutiveDocumentationPage} />
            <Route path="/projects/:project_id/section/construction-control" component={ConstructionControlPage} />
            <Route path="/projects/:project_id/section/:section_name" component={DocumentsPage} />
            <Route path="/" />
        </Switch>
    );
};

const mapStateToProps = (state) => ({
    tree: state.categories.treeStructure.categories_tree,
    projects: state.projects.list.map,
    project_id: state.projects.list.active,
    selectedSection: state.categories.treeStructure["documents-list"].section,
});

const actions = {
    changeSection: changeSectionAction,
    activateProject: activateProjectAction,
};

export const RoutesContainer = connect(mapStateToProps, actions)(Routes);
