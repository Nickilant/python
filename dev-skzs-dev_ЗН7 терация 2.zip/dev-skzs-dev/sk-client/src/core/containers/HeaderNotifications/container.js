import React, { createRef } from "react";
import { connect, useDispatch, useSelector } from "react-redux";

import { NotificationsList } from "../../../notifications/containers/NotificationsList/container";

import "./styles.scss";
import bell from "./assets/bell.svg";
import { selectDropdownState, selectNotifications } from "../../../notifications/selectors/notifications";
import { toggleNotificationsDropdown } from "../../../notifications/actions/notifications/actions";

export const HeaderNotificationsContainer = (props) => {
    const { notificationsLength } = props;
    const refNotifications = createRef();
    const isDropdownOpen = useSelector(selectDropdownState);
    const dispatch = useDispatch();

    const handleOpenDropdown = () => {
        dispatch(toggleNotificationsDropdown(!isDropdownOpen));
    };

    return (
        <>
            <div
                ref={refNotifications}
                className="header-notifications"
                title="Список уведомлений"
            >
                <div
                    className="bell-block"
                    onClick={handleOpenDropdown}
                >
                    <img className="bell" src={bell} alt="Оповещения" />
                    {notificationsLength > 0 && <span className="badge">{notificationsLength}</span>}
                </div>
                {
                    isDropdownOpen && (
                        <div className="notifications-list">
                            <NotificationsList />
                        </div>
                    )
                }
            </div>
            {
                isDropdownOpen && (
                    <div className="overlay" onClick={handleOpenDropdown} />
                )
            }
        </>
    );
};

export const mapStateToProps = (state) => ({
    notificationsLength: selectNotifications(state).filter((item) => !item.acknowledged).length,
});

export const HeaderNotifications = connect(mapStateToProps)(HeaderNotificationsContainer);
