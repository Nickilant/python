import React from "react";
import cx from "classnames";
import { connect } from "react-redux";

import "./styles.scss";
import { isLoading } from "../../selectors/preloader";

function PreloaderContainer(props) {
    const {
        loading,
    } = props;

    return (
        <>
            {
                loading ? (
                    <div className={cx("preloader-container", { loading })}>
                        <div className="preloader-icon" />
                    </div>
                )
                    : null
            }
        </>
    );
}

const mapStateToProps = (state) => ({
    loading: isLoading(state),
});

export const Preloader = connect(mapStateToProps, {
})(PreloaderContainer);
