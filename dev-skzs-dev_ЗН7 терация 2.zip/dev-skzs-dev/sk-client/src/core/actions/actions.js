import {
    CLOSE_DETAILS, CLOSE_SIDEBAR, ERROR_PAGE_SET_MESSAGE, OPEN_DETAILS, OPEN_SIDEBAR,
} from "./actionTypes";
import { getCRUDEntityActions } from "../../shared/actions/entityCrudActions";
import { MODULE } from "../constants/system_settings";

export const systemSettingsCRUDActions = getCRUDEntityActions(MODULE, "setting");

export const openSidebarAction = () => ({
    type: OPEN_SIDEBAR,
});

export const closeSidebarAction = () => ({
    type: CLOSE_SIDEBAR,
});

export const openDetailsAction = () => ({
    type: OPEN_DETAILS,
});

export const closeDetailsAction = () => ({
    type: CLOSE_DETAILS,
});

export const setErrorPageMessage = (code, message) => ({
    type: ERROR_PAGE_SET_MESSAGE,
    payload: {
        code,
        message,
    },
});
//
// export const setRouterParam = (param, value) => ({
//     type: SET_ROUTER_PARAMS
// });
