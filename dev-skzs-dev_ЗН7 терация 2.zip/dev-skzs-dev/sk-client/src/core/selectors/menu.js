// TODO: this is VERY not very good
export const categoryByName = (tree, name) => (tree && {
    "construction-control": Object.values(tree).find((it) => !it.parent_category && it.name === "Строительный контроль"),
    "project-documents": Object.values(tree).find((it) => !it.parent_category && it.name === "Проектная документация"),
    "executive-documents": Object.values(tree).find((it) => !it.parent_category && it.name === "Исполнительная документация"),
    "normative-documents": Object.values(tree).find((it) => !it.parent_category && it.name === "Нормативная документация"),
    activities: Object.values(tree).find((it) => !it.parent_category && it.name === "Исполнительная документация"),
    geodata: Object.values(tree).find((it) => !it.parent_category && it.name === "Строительный контроль"),

}[name]);

export const menuWithSections = (menu, project) => menu.map((lvl1) => lvl1.map(
    (lvl2) => (lvl2.href ? lvl2 : { ...lvl2, href: `/projects/${project}/section/${lvl2.linkToSection}` }),
));
