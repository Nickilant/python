export const isLoading = (state) => {
    const { preloader } = state.core;
    return Object.values(preloader).every((item) => item === false);
};
