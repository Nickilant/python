import { managementFormReducerFactory } from "../../shared/reducers/formFactory";
import { MODULE } from "../constants/system_settings";

const initialState = {
    type: "setting",
    isEdited: false,
    isValidated: false,
    changedFields: {},
    validatedFields: {},
    data: {},
};

export const systemSettingsManagementFormReducer = managementFormReducerFactory(initialState, initialState.type, MODULE);
