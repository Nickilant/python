import { combineReducers } from "redux";
import sidebarReducer from "./sidebar";
import detailsReducer from "./details";
import { RouterReducer } from "./router";
import { PreloaderReducer } from "./preloader";
import { ErrorPageReducer } from "./errorPage";
import { systemSettingsManagementFormReducer } from "./systemSettingsForm";
import { crudReducerFactory } from "../../shared/reducers/crudFactory";
import { MODULE } from "../constants/system_settings";

export default combineReducers({
    sidebar: sidebarReducer,
    details: detailsReducer,
    router: RouterReducer,
    preloader: PreloaderReducer,
    errorPage: ErrorPageReducer,
    systemSettingsManagementForm: systemSettingsManagementFormReducer,
    systemSettings: crudReducerFactory(MODULE, "setting", "sid"),
});
