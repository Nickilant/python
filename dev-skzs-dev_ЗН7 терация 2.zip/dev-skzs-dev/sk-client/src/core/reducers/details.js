import { CLOSE_DETAILS, OPEN_DETAILS } from "../actions/actionTypes";

const initialState = {
    detailsOpen: true,
};

export default (state = initialState, action) => {
    switch (action.type) {
        case OPEN_DETAILS: {
            return {
                ...state,
                detailsOpen: true,
            };
        }
        case CLOSE_DETAILS: {
            return {
                ...state,
                detailsOpen: false,
            };
        }
        default:
            return state;
    }
};
