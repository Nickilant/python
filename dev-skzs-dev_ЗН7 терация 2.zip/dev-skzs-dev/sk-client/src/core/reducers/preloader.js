const initialState = {
    projects: true,
    users: true,
    companies: true,
    categories: true,
    documents: true,
    details: true,
};

export const PreloaderReducer = (state = initialState, action) => {
    switch (action.type) {
        case "USER_AUTH_TOKEN_RECEIVED": {
            return {
                projects: false,
                users: false,
                companies: false,
                categories: false,
                documents: false,
                details: false,
            };
        }
        case "PROJECTS_ACTIVATE_PROJECT": {
            return {
                projects: false,
                users: false,
                companies: false,
                categories: false,
                documents: false,
                details: false,
            };
        }
        case "CRUD_PROJECTS_LIST_PROJECT_COMPLETE": {
            return {
                ...state,
                projects: true,
            };
        }
        case "CRUD_PROJECTS_LIST_PROJECT_FAILED": {
            return initialState;
        }
        case "CRUD_ORGANIZATIONS_LIST_COMPANY_COMPLETE": {
            return {
                ...state,
                companies: true,
            };
        }
        case "CRUD_ORGANIZATIONS_LIST_COMPANY_FAILED": {
            return {
                ...state,
                companies: true,
            };
        }

        case "CRUD_USERS_LIST_USER_COMPLETE": {
            return {
                ...state,
                users: true,
            };
        }
        case "CRUD_USERS_LIST_USER_FAILED": {
            return {
                ...state,
                users: true,
            };
        }
        case "USER_AUTH_PROFILE_FAILED": {
            return initialState;
        }

        case "CRUD_CATEGORIES_LIST_CATEGORY_COMPLETE": {
            return {
                ...state,
                categories: true,
            };
        }
        case "CRUD_CATEGORIES_LIST_CATEGORY_FAILED": {
            return {
                ...state,
                categories: true,
            };
        }

        case "CRUD_DOCUMENTS_LIST_DOCUMENT_COMPLETE": {
            return {
                ...state,
                documents: true,
            };
        }
        case "CRUD_DOCUMENTS_LIST_DOCUMENT_FAILED": {
            return initialState;
        }

        case "CRUD_DOCUMENTS_GET_DOCUMENT_DETAILS_COMPLETE": {
            return {
                ...state,
                details: true,
            };
        }
        case "CRUD_DOCUMENTS_GET_DOCUMENT_DETAILS_FAILED": {
            return {
                ...state,
                details: true,
            };
        }

        default:
            return state;
    }
};
