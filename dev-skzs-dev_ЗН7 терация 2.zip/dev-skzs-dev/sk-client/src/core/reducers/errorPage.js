import { ERROR_PAGE_SET_MESSAGE } from "../actions/actionTypes";

const initialState = {
    404: {
        message: "Страница не найдена",
    },
    403: {
        message: "Вы не имеете доступа к этой странице",
    },
};

export const ErrorPageReducer = (state = initialState, action) => {
    switch (action.type) {
        case ERROR_PAGE_SET_MESSAGE: {
            return {
                ...state,
                [action.payload.code]: { message: action.payload.message },
            };
        }
        default:
            return state;
    }
};
