const initialState = {
    projects: "",
    section: "",
    group: "",
    document: "",
};

const getParams = (str) => {
    const result = {};
    let currentKey = "";
    str.split("/").forEach((item, i) => {
        if (i % 2 === 1) {
            currentKey = item;
        } else {
            result[currentKey] = item;
        }
    });
    return result;
};

export const RouterReducer = (state = initialState, action) => {
    switch (action.type) {
        case "@@router/LOCATION_CHANGE": {
            const { pathname } = action.payload.location;

            return getParams(pathname);
        }
        default:
            return state;
    }
};
