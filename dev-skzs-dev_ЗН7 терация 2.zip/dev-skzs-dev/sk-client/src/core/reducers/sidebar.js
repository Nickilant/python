import { CLOSE_SIDEBAR, OPEN_SIDEBAR } from "../actions/actionTypes";

const initialState = {
    sidebarOpen: false,

    menu: [
        [
            {
                title: "Проектная документация",
                icon: "/assets/menu-1.svg",
                linkToSection: "project-documents",
            },
            {
                title: "Исполнительная документация",
                icon: "/assets/menu-2.svg",
                linkToSection: "executive-documents",
            },
            {
                title: "Нормативная документация",
                icon: "/assets/menu-3.svg",
                linkToSection: "normative-documents",
            },
            // {
            //     title: "Разрешительная документация",
            //     icon: "/assets/menu-3.svg",
            //     linkToSection: "enabling-documents",
            //     disabled: true,
            // },
        ],
        [
            {
                title: "Карта/план",
                icon: "/assets/menu-4.svg",
                linkToSection: "geodata",
                sectionOverride: "construction-control",
            },
            // {
            //     title: "3D-модели",
            //     icon: "/assets/menu-5.svg",
            //     href: "/3d-models",
            //     disabled: true,
            //
            // },
        ],
        [
            {
                title: "Месячно-суточные графики",
                icon: "/assets/menu-6.svg",
                linkToSection: "activities",
            },
        ],
        [
            {
                title: "Строительный контроль",
                icon: "/assets/menu-7.svg",
                linkToSection: "construction-control",
            },
            // {
            //     title: "Аэромониторинг",
            //     icon: "/assets/menu-11.svg",
            //     linkToSection: "air-monitoring",
            // },
            // {
            //     title: "Авторский надзор",
            //     icon: "/assets/menu-8.svg",
            //     href: "/author-supervision",
            //     disabled: true,
            //
            // },
            // {
            //     title: "Промышленная безопасность (HSE)",
            //     icon: "/assets/menu-9.svg",
            //     href: "/hse",
            //     disabled: true,
            //
            // },
        ],
        [
            // {
            //     title: "Комплекс виртуальной реальности",
            //     icon: "/assets/menu-10.svg",
            //     href: "/virtual-reality",
            //     disabled: true,
            //
            // },
        ],
    ],

};

export default (state = initialState, action) => {
    switch (action.type) {
        case OPEN_SIDEBAR: {
            return {
                ...state,
                sidebarOpen: true,
            };
        }
        case CLOSE_SIDEBAR: {
            return {
                ...state,
                sidebarOpen: false,
            };
        }
        default:
            return state;
    }
};
