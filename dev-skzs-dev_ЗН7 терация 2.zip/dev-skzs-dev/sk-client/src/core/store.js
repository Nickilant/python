import { applyMiddleware, createStore } from "redux";
import createSagaMiddleware from "redux-saga";
import { composeWithDevTools } from "redux-devtools-extension";
import { all } from "redux-saga/effects";
import { routerMiddleware } from "connected-react-router";
import { createBrowserHistory } from "history";
import { usersRootSaga } from "../users/sagas/rootSaga";
import { getRootReducer } from "./reducer";
import { documentsRootSaga } from "../documents/sagas/rootSaga";
import { projectsRootSaga } from "../projects/sagas/rootSaga";
import { organizationsRootSaga } from "../organizations/sagas/rootSaga";
import { commentsRootSaga } from "../comments/sagas/rootSaga";
import { categoriesRootSaga } from "../categories/sagas/rootSaga";
import { notificationsRootSaga } from "../notifications/sagas/rootSaga";
import { extra2dRootSaga } from "../construction_control/extra_2d/sagas/rootSaga";
import { eventsRootSaga } from "../event_log/sagas/rootSaga";
import { activitiesRootSaga } from "../activities/sagas/rootSaga";
import { executiveDocumentationRootSaga } from "../executive_documentation/sagas/rootSaga";
import { systemSettingsRootSaga } from "./sagas/rootSaga";

export const connectedHistory = createBrowserHistory();

const sagaMiddleware = createSagaMiddleware();

function* rootSaga() {
    yield all([
        usersRootSaga(),
        organizationsRootSaga(),
        documentsRootSaga(),
        projectsRootSaga(),
        commentsRootSaga(),
        categoriesRootSaga(),
        notificationsRootSaga(),
        extra2dRootSaga(),
        eventsRootSaga(),
        activitiesRootSaga(),
        executiveDocumentationRootSaga(),
        systemSettingsRootSaga(),
    ]);
}

export default createStore(
    getRootReducer(connectedHistory),
    composeWithDevTools(
        applyMiddleware(
            sagaMiddleware,
            routerMiddleware(connectedHistory),
        ),
    ),
);

sagaMiddleware.run(rootSaga);
