import React, { useEffect, useState } from "react";
import { Route, Switch } from "react-router-dom";
import { connect } from "react-redux";
import cx from "classnames";
import { OrganizationsPage } from "../organizations/pages/Index/page";
import { UsersManagementPage } from "../users/pages/UsersManagementPage/page";
import { page403, page404 } from "./pages/ResultPage/page";
import { ProjectsListPage } from "../projects/pages/Index/page";

import { SideBar } from "./containers/SideBar/container";
import Header from "./containers/Header/container";

import { RoutesContainer } from "./containers/Routes/container";
import {
    closeDetailsAction,
    closeSidebarAction,
    openDetailsAction,
    openSidebarAction,
} from "./actions/actions";

import "antd/dist/antd.css";
import "./App.scss";
import { authTokenReceivedAction } from "../users/actions/userLogin/actions";
import { initApi } from "../shared/api";
import { RightColumnContainer } from "../shared/RightColumnContainer/component";
import {
    canAdministrateCompanies,
    canAdministrateProjects,
    canAdministrateUsers,
} from "../users/selectors/permissions";
import { Modal } from "../shared/containers/Modal/container";
import { Preloader } from "./containers/Preloader/container";
import { EventLogPage } from "../event_log/pages/Index/page";
import { loginAction } from "../users/actions/currentUser/actions";
import { NotAvailablePage } from "./pages/NotAvailablePage/page";

initApi();

function App(props) {
    const {
        loggedIn,
        showProjectsAdminPanelLink,
        showUsersAdminPanelLink,
        showCompaniesAdminPanelLink,
        login,
        isOnlyDemoProject,
        loginErrors,
    } = props;

    useEffect(() => {
        login();
    }, [login]);

    useEffect(() => {
        setProjectsWindow(isOnlyDemoProject);
    }, [isOnlyDemoProject]);

    const [sidebarOpen, setSidebarOpen] = useState(false);
    const [noProjectsWindowIsOpen, setProjectsWindow] = useState(false);

    return (
        <div>
            <Preloader />
            {/* <Switch> */}
            {/* <Route path={!loggedIn ? "" : "/user-login"} component={UserLoginPage} /> */}
            {/* </Switch> */}
            {
                loginErrors.length !== 0 && (
                    <div className="error-with-login">
                        <div className="inner">
                            Нет доступа к системе. Необходимо проверить права доступа
                        </div>
                    </div>
                )
            }
            {
                loggedIn && (
                    <div className={cx(["App", "core-module", { tablet: (/Android|iPad/i.test(navigator.userAgent)) }])}>
                        <div className="basic-layout">
                            <div className="sidebar-container">
                                <SideBar
                                    sidebarOpen={sidebarOpen}
                                    setSidebarOpen={setSidebarOpen}
                                />
                            </div>

                            <div className={cx(["main", { "sidebar-opened": sidebarOpen }])}>
                                <div className="header">
                                    <Header />
                                </div>
                                <div className="columns-wrapper">
                                    {noProjectsWindowIsOpen && (
                                        <div className="no-projects-available-window">
                                            <div className="window">
                                                <div className="head">
                                                    <div className="block-title" />
                                                    <div className="close-icon" onClick={() => setProjectsWindow(false)} />
                                                </div>
                                                <div className="body">
                                                    Доступен только
                                                    {" "}
                                                    <u>Тестовый проект</u>
                                                    . Вы не авторизованы для доступов к другим проектам. Обратитесь к администратору домена.
                                                </div>
                                            </div>
                                        </div>
                                    )}
                                    <div className="columns">
                                        <Switch>
                                            <Route
                                                path="/projects/:id"
                                                exact
                                            >
                                                <div className="bg-picture-wrapper">
                                                    <div className="bg-img bg-picture" />
                                                </div>
                                            </Route>

                                            <Route
                                                path="/projects/:project_id/section/:section_name"
                                                component={RoutesContainer}
                                            />

                                            {showProjectsAdminPanelLink
                                            && <Route path="/projects/" component={ProjectsListPage} />}
                                            {showCompaniesAdminPanelLink
                                            && <Route path="/organizations" component={OrganizationsPage} />}
                                            {showUsersAdminPanelLink
                                            && <Route path="/users" component={UsersManagementPage} />}
                                            {showUsersAdminPanelLink
                                            && <Route path="/event-log/:project_sid" component={EventLogPage} />}

                                            <Route path="/" exact>
                                                <div className="bg-picture-wrapper">
                                                    <div className="bg-img bg-picture" />
                                                </div>
                                            </Route>
                                            <Route path="/403" component={page403} />
                                            <Route path="/:404" component={page404} />

                                        </Switch>
                                        <RightColumnContainer />
                                        <Modal />
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                )
            }
            <Route path="/not-available" component={NotAvailablePage} />
        </div>
    );
}

const mapStateToProps = (state) => ({
    details: state.core.details,
    loggedIn: state.users.currentUser.loggedIn,
    loginErrors: state.users.currentUser.errors,
    showProjectsAdminPanelLink: canAdministrateProjects(state),
    showUsersAdminPanelLink: canAdministrateUsers(state),
    showCompaniesAdminPanelLink: canAdministrateCompanies(state),
    isOnlyDemoProject: state.projects.list.isOnlyDemoProject,
});

export default connect(mapStateToProps, {
    openSidebar: openSidebarAction,
    closeSidebar: closeSidebarAction,
    openDetails: openDetailsAction,
    closeDetails: closeDetailsAction,
    authTokenReceived: authTokenReceivedAction,
    login: loginAction,
})(App);
