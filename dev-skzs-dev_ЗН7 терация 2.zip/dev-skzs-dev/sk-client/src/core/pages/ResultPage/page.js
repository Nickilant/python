import React from "react";
import { Button, Result } from "antd";
import { NavLink } from "react-router-dom";
import "./styles.scss";
import { useSelector } from "react-redux";

export const ResultPage = (props) => {
    const { status } = props;

    const { message } = useSelector((state) => state.core.errorPage[status]);

    return (
        <div className="main-area">
            <Result
                status={status.toString()}
                title={`Код ${status}`}
                subTitle={message}
                icon="./icon"
                extra={(
                    <NavLink to="/">
                        <Button type="primary">Вернуться на главную</Button>
                    </NavLink>
                )}
            />
        </div>
    );
};

export const page404 = () => <ResultPage status="404" />;
export const page403 = () => <ResultPage status="403" />;
