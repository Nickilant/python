import React from "react";
import "./styles.scss";

export const NotAvailablePage = () => (
    <div className="wrapper">
        <div className="inner">
            Бэкенд-сервис недоступен, обратитесь к администратору
        </div>
    </div>
);
