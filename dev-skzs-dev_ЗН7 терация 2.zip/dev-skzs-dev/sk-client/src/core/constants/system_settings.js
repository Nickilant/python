export const MODULE = "core";
