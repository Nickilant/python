import { all } from "redux-saga/effects";
import { takeEvery } from "@redux-saga/core/effects";
import { createCRUDSaga } from "../../shared/sagas/entityCrudFactory";
import { WIDGET_TYPES } from "../../shared/constants/widgetTypes";
import { entityManagementSaga } from "../../shared/sagas/formFactory";
import { systemSettingsCRUDActions } from "../actions/actions";

const systemSettingsCrudSaga = createCRUDSaga({
    moduleName: "core",
    entityName: "setting",
    idField: "sid",

    getPrefixPath: () => "/system-settings",
    entityPath: () => "/system-settings/default/",

    listEntityIn: (item) => ({
        ...item,
    }),

    detailsEntityOut: (item) => ({
        ...item,
    }),

});

// function* settingsManagementSaga() {
//     // yield takeLatest(LOCATION_CHANGE, watchRouteChanges);
// }

function* settingsUpdate({ payload }) {
    // yield put(profileUpdateAction(payload));
}

function* watchSettingsUpdate() {
    yield takeEvery("CORE_SUBMIT_FORM_SYSTEM-SETTINGS", settingsUpdate);
}

export function* systemSettingsRootSaga() {
    yield all([
        // usersCombinedSaga(),
        systemSettingsCrudSaga(),
        entityManagementSaga({
            actions: systemSettingsCRUDActions,
            moduleName: "CORE",
            entityName: "setting",
            // viewWidget: WIDGET_TYPES.USER_PROFILE,
            editWidget: WIDGET_TYPES.SYSTEM_SETTINGS,
        }),
        watchSettingsUpdate(),
    ]);
}
