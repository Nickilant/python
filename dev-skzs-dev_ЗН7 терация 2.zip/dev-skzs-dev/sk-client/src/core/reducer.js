import { combineReducers } from "redux";
import { connectRouter } from "connected-react-router";
import coreReducers from "./reducers/combined";
import constructionControlBaseReducers from "../construction_control/base/reducers/combined";
import documentsReducers from "../documents/reducers/combined";
import { projectsReducers } from "../projects/reducers/combined";
import { organizationsReducers } from "../organizations/reducers/combined";
import { usersReducers } from "../users/reducers/combined";
import { sharedReducers } from "../shared/reducers/combined";
import { commentsReducers } from "../comments/reducers/combined";
import { categoriesReducers } from "../categories/reducers/combined";
import { notificationsReducer } from "../notifications/reducers/combined";
import { eventsReducers } from "../event_log/reducers/combined";
import { activityReducer } from "../activities/reducers/combined";
import { executiveDocumentationReducers } from "../executive_documentation/reducer/combined";

export function getRootReducer(connectedHistory) {
    return combineReducers({
        router: connectRouter(connectedHistory),
        shared: sharedReducers,
        core: coreReducers,
        constructionControl: constructionControlBaseReducers,
        documents: documentsReducers,
        projects: projectsReducers,
        organizations: organizationsReducers,
        users: usersReducers,
        comments: commentsReducers,
        categories: categoriesReducers,
        notifications: notificationsReducer,
        events: eventsReducers,
        activities: activityReducer,
        executiveDocumentation: executiveDocumentationReducers,
    });
}
