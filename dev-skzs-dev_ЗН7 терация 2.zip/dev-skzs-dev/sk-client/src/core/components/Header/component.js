import React from "react";
import { Dropdown, Menu, Select } from "antd";
import { NavLink } from "react-router-dom";

import { useSelector } from "react-redux";
import { HeaderNotifications } from "../../containers/HeaderNotifications/container";

import "./styles.scss";
import logo from "./assets/logo.svg";
import refresh from "./assets/refresh.svg";
import dropdownIcon from "./assets/dropdown.svg";
import settingsIcon from "./assets/settings.svg";
import keyIcon from "./assets/key.svg";

const { Option } = Select;

export default function Header(props) {
    const {
        selections,
        currentSelect,
        changeSelected,
        showProjectsAdminPanelLink,
        showUsersAdminPanelLink,
        showCompaniesAdminPanelLink,
        refreshData,
        openSystemSettings,
    } = props;

    const {
        fullname, company, position, avatar, roleName, openOwnProfileSettings, openOwnProfilePreview, project,
    } = props;

    const handleChangeSelect = (value) => {
        changeSelected(value);
    };

    const projectInURL = useSelector((state) => state.core.router.projects);
    const showProjectSelector = Boolean(projectInURL);

    const management = [];

    if (showUsersAdminPanelLink) {
        // management.push(
        // <Menu.Item key="users">
        //     <NavLink to="/users">
        //         <div className="admin-panel">
        //             <img
        //                 className="profile-prefix-icon"
        //                 src={keyIcon}
        //                 alt="Панель"
        //             />
        //             Управление пользователями
        //         </div>
        //     </NavLink>
        // </Menu.Item>,пол
        // );
    }

    if (showCompaniesAdminPanelLink) {
        management.push(
            <Menu.Item key="organizations">
                <NavLink to="/organizations">
                    <div className="admin-panel">
                        <img
                            className="profile-prefix-icon"
                            src={keyIcon}
                            alt="Панель"
                        />
                        Управление организациями
                    </div>
                </NavLink>
            </Menu.Item>,
        );
    }

    if (showProjectsAdminPanelLink) {
        management.push(
            <Menu.Item key="projects">
                <NavLink to="/projects">
                    <div className="admin-panel">
                        <img
                            className="profile-prefix-icon"
                            src={keyIcon}
                            alt="Панель"
                        />
                        Управление проектами
                    </div>
                </NavLink>
            </Menu.Item>,
        );
    }

    if (showProjectsAdminPanelLink && project) {
        management.push(
            <Menu.Item key="event-log">
                <NavLink to={`/event-log/${project.key}`}>
                    <div className="admin-panel">
                        <img
                            className="profile-prefix-icon"
                            src={keyIcon}
                            alt="Панель"
                        />
                        Журнал событий
                    </div>
                </NavLink>
            </Menu.Item>,
        );
    }

    const profileMenu = (
        <Menu>
            <div className="user-info">
                <div className="profile-first-name">
                    {fullname}
                </div>
                <div className="profile-position">
                    <b>Роль: </b>
                    {" "}
                    {roleName}
                </div>
                <div className="profile-organization">
                    <b>Компания: </b>
                    {company}
                </div>
                {
                    position && (
                        <div className="profile-position">
                            <b>Должность: </b>
                            {position}
                        </div>
                    )
                }
            </div>
            <Menu.Divider />
            <Menu.Item>
                <div onClick={openOwnProfileSettings} className="profile-settings">
                    <img className="profile-prefix-icon" src={settingsIcon} alt="Настройки" />
                    Настройки профиля
                </div>
            </Menu.Item>

            {
                showUsersAdminPanelLink
                    && (
                        <Menu.Item>

                            <div onClick={openSystemSettings} className="profile-settings">
                                <img className="profile-prefix-icon" src={settingsIcon} alt="Настройки" />
                                Настройки системы
                            </div>
                        </Menu.Item>

                    )
            }

            {
                management.length && [
                    <Menu.Divider key="divider" />,
                    ...management,
                ]
            }
            <Menu.Divider />
        </Menu>
    );

    return (
        <div className="core-header" id="area">
            <NavLink to="/">
                <img className="logo" src={logo} alt="Логотип" />
            </NavLink>
            <div className="header-title">{company}</div>
            <div className="divider with-select-right" />
            <div className="header-select" title="Выбрать проект">
                {showProjectSelector && (
                    <Select
                        value={Object.keys(selections).includes(currentSelect) ? currentSelect : "Проект не выбран"}
                        suffixIcon={<img src={dropdownIcon} alt="Развернуть" />}
                        dropdownClassName="header-select-dropdown"
                        onChange={handleChangeSelect}
                    >
                        {
                            Object.values(selections).map((project) => (
                                <Option key={project.key} value={project.key}>
                                    <div className="header-select-title">Проект</div>
                                    <div className="header-select-desc">{project.name}</div>
                                </Option>
                            ))
                        }
                    </Select>
                )}
            </div>
            <div className="divider with-select-left" />
            <HeaderNotifications />
            <div className="divider" />
            <Dropdown
                trigger={["click"]}
                placement="bottomCenter"
                align={{
                    points: ["tl", "bl"],
                    offset: [-100, 4],
                    overflow: {
                        adjustX: 0,
                        adjustY: 0,
                    },
                }}
                overlayClassName="profile"
                overlay={profileMenu}
                // overlayStyle={{paddingLeft: "15px"}}
                getPopupContainer={() => document.getElementById("area")}
            >
                <div
                    className="ant-dropdown-link"
                >
                    <div
                        className="current-user"
                        title="Меню пользователя"
                    >
                        <div className="avatar-block">
                            <img className="avatar" src={avatar} alt="Аватар" />
                        </div>
                        <span className="user-name">
                            {
                                fullname || "Аноним"
                            }
                        </span>
                    </div>
                    <img className="dropdown-icon" src={dropdownIcon} alt="Развернуть" />
                </div>
            </Dropdown>
            <div className="divider" />
            {/* <div className="status">Offline</div> */}
            {/* <div className="status-dot" /> */}
            <img className="refresh" onClick={refreshData} src={refresh} title="Обновить данные" alt="Обновить" />
        </div>
    );
}
