import React from "react";
import "./styles.scss";

export default () => (
    <div className="favorites">
        <div className="icon bg-img" />
        <div className="title">Избранное</div>
    </div>
);
