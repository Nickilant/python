import React from "react";

import { uniqueId } from "lodash";

import "./styles.scss";

export default function RightColumn(props) {
    const {
        icon,
        title,
        subTitle,
        otherActions,
        TopAction,
        BottomAction,
        Body,
    } = props;

    return (
        <div className="right-column">
            <div className="doc-block">
                {icon}
                <div className="desc">
                    <div className="title-block">
                        <p className="title">{title}</p>
                        <div className="other-actions">
                            {
                                otherActions && otherActions.map((Item) => (
                                    <Item key={uniqueId()} />
                                ))
                            }
                        </div>
                    </div>
                    <div className="sub-title">{subTitle}</div>
                </div>
            </div>
            {TopAction}
            <div className="divider" />
            {/* <Body /> */}
            {Body}
            <div className="divider" />
            {BottomAction}
        </div>
    );
}
