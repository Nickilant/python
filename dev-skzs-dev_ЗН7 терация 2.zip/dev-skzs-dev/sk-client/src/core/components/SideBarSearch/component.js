import React from "react";
import "./styles.scss";

export default () => (

    <div className="search">
        <div className="searchbar">
            <input placeholder="Что ищем?" />
            <span className="cross icon bg-img" />
            <span className="search-icon icon bg-img" />
        </div>
        <span className="settings icon bg-img" />
        <span className="info icon bg-img" />
    </div>
);
