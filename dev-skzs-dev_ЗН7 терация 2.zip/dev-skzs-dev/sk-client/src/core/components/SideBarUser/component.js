import React from "react";

import "./styles.scss";

export default ({
    user, open, openSidebar, closeSidebar,
}) => {
    const getInitials = (firstname) => firstname.split(" ").map((str) => `${str[0]}.`).join(" ");

    const handleToggleSidebar = () => {
        if (open) {
            closeSidebar();
        } else {
            openSidebar();
        }
    };

    return (
        <div className="user" onClick={handleToggleSidebar}>
            <div className="avatar"><img alt="avatar" src={user.avatar} /></div>
            <div className="user-info">
                <div className="lastname">{user.lastname}</div>
                <div className="firstname">{open ? user.firstname : getInitials(user.firstname)}</div>
                <div className="company">{open && user.company}</div>
                <div className="position">{open && user.position}</div>
            </div>
        </div>
    );
};
