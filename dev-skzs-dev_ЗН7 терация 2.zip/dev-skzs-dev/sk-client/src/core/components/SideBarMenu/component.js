import React from "react";

import cx from "classnames";
import { NavLink } from "react-router-dom";

import "./styles.scss";

export default ({ menu }) => {
    const handleNavigate = (disabled) => (e) => {
        if (disabled) {
            e.preventDefault();
        }
    };
    return (
        <div className="menu">
            <ul className="lvl-1">
                {
                    menu.map((block, idx) => (
                        <ul className="lvl-2" key={idx}>
                            {block.map((item) => (
                                <li key={item.href} title={item.title}>
                                    <NavLink to={item.href} onClick={handleNavigate(item.disabled)} className={cx("menu-item", { disabled: item.disabled })}>
                                        <span className="icon"><img alt="icon" src={item.icon} /></span>
                                        <span className="title">{item.title}</span>
                                    </NavLink>
                                </li>
                            ))}
                        </ul>
                    ))
                }
            </ul>
        </div>
    );
};
