import { formTypes } from "../../../shared/containers/ManagementForm/formTypes";
import { universalSubmitValueAction } from "../../../shared/actions/managementForm/actions";

export const formConfig = [
    {
        name: "logout_minutes",
        type: formTypes.INPUT_NUMBER,
        label: "Время завершения неактивной сессии пользователя",
    },
    {
        name: "submit",
        type: formTypes.BUTTON,
        on_click: ({
            data, type, isEdited, isValidated, changedFields, dispatch,
        }) => {
            dispatch(universalSubmitValueAction("CORE", type, {
                isEdited,
                isValidated,
                changedFields,
                data,
            }));
        },
        source: ({ config, changedFields }) => ({
            ...config,
            is_disabled: Object.keys(changedFields).length === 0,
            btn_label: "Сохранить изменения",
        }),
    },
];
