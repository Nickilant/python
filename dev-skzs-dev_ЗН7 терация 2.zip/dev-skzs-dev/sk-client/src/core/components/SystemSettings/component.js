import React from "react";
import { Form } from "antd";

import { ManagementForm } from "../../../shared/containers/ManagementForm/container";
import { formConfig } from "./form_config";

import "./styles.scss";

export const SystemSettings = () => (
    <div className="system-settings-management-form">
        <Form className="details-form">
            <ManagementForm
                formConfig={formConfig}
                reducer="systemSettingsManagementForm"
                moduleAction="CORE"
                module="core"
            >
                {
                    () => (
                        <div className="form-header">
                            <div className="title">
                                Редактирование настроек системы
                            </div>
                        </div>
                    )
                }
            </ManagementForm>
        </Form>
    </div>
);
