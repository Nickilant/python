import React, { useEffect, useState } from "react";
import moment from "moment";

import { dateFormat, timeFormat } from "../../../shared/constants/dateFormats";

import "./styles.scss";

const capitalizeFirstLetter = (string) => string.charAt(0).toUpperCase() + string.slice(1);

export const SideBarDate = () => {
    const [currentDate, setCurrentDate] = useState(moment());

    const intervalID = setInterval(() => setCurrentDate(moment()), 1000);

    useEffect(() => () => {
        clearInterval(intervalID);
    }, [intervalID]);

    return (
        <div className="date">
            <div className="icon bg-img" />

            <div className="fullDate">
                <div className="weekday">{capitalizeFirstLetter(currentDate.format("dddd"))}</div>
                <div className="day">{currentDate.format("DD MMMM YYYY")}</div>
                <div className="time">{currentDate.format(timeFormat)}</div>
            </div>

            <div className="shortDate">
                <div className="weekday-n-time">
                    {`${currentDate.format("dd").toUpperCase()}, ${currentDate.format(timeFormat)}`}
                </div>
                <div className="day">{currentDate.format(dateFormat)}</div>
            </div>
        </div>
    );
};
