# Роутер
Роутер позволяет создать ссылку на любую сущность.

## Получение сущности

Например есть URL `<host>/projects/15370eff/section/construction-control/group/5179656f/document/580a4cd1`  
Его параметры находятся в `state.core.router`
```json
{
    projects: "15370eff",
    section: "construction-control",
    group: "5179656f",
    document: "580a4cd1",
    // ... something else
}
```

Во время рендера страницы мы должны получить ID текущей сущности, и открыть её.

```javascript
useEffect(() => {
    const documentId = routerPathParams.document;
    const item = documents.filter((it) => it.id === documentId)[0];

    if (item) {
        openDocument(item);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
}, [
    routerPathParams, 
    documentsCount
]);
```

**Важный момент:** нам необходимо правильно указать наблюдаемые переменные:  
`routerPathParams` = `state.core.router`, наблюдаем за изменением параметров  
`documentCount` поскольку во время рендера компонента количество документов может быть равно 0, нам следует открывать сущность тогда, когда она появится в списке.

 ## Запись сущности
Когда мы выбираем сущность нам нужно задиспатчить экшен, который изменит URL соответствующим образом.

```javascript
const path = "/projects/15370eff/section/construction-control/group/5179656f/document/580a4cd1";
dispatch(push(path));
```

Для генерации URL используем функцию getPath, в которую передаем текущие параметры из стейта и массив из значений.  
Каждое значение это либо просто текстовое значние key, например `section`, в таком случае value будет взято из `routerPathParams`, либо массив из двух значений: key и value, в случае если value нужно добавить или перезаписать.  

Пример использования:
```javascript
import { useDispatch } from "react-redux";
import { push } from "connected-react-router";

// ...

const dispatch = useDispatch();

const handleSelectItem = (id) => {
    const path = getURL(routerPathParams, ["projects", "section", "group", ["document", id]]);
    dispatch(push(path));
};
```
