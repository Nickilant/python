import { LIST_ATTRIBUTES_SET } from "./listAttributes";

export const setAttrAction = (payload) => ({
    type: LIST_ATTRIBUTES_SET,
    payload,
});
