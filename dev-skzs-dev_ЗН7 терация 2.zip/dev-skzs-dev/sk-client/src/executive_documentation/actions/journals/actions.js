import { JOURNALS_ACTIONS } from "./actionTypes";

export const getSections = (payload) => ({
    type: JOURNALS_ACTIONS.GET_SECTIONS,
    payload,
});

export const getSectionsComplete = (payload) => ({
    type: JOURNALS_ACTIONS.GET_SECTIONS_COMPLETE,
    payload,
});

export const getSectionsFailed = (payload) => ({
    type: JOURNALS_ACTIONS.GET_SECTIONS_FAILED,
    payload,
});

export const getJournal = (payload) => ({
    type: JOURNALS_ACTIONS.GET_JOURNAL,
    payload,
});

export const getJournalComplete = (payload) => ({
    type: JOURNALS_ACTIONS.GET_JOURNAL_COMPLETE,
    payload,
});

export const getJournalFailed = (payload) => ({
    type: JOURNALS_ACTIONS.GET_JOURNAL_FAILED,
    payload,
});

export const changeJournalsDate = (payload) => ({
    type: JOURNALS_ACTIONS.SET_DATE,
    payload,
});

export const changeJournalsDateComplete = (payload) => ({
    type: JOURNALS_ACTIONS.SET_DATE_COMPLETE,
    payload,
});

export const changeJournalsDateFailed = (payload) => ({
    type: JOURNALS_ACTIONS.SET_DATE_FAILED,
    payload,
});
