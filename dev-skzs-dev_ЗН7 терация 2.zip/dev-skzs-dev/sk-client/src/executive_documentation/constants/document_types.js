export const DOCUMENT_TYPES = {
    AOSR: "aosr",
};
