import { journals } from "./journals";

export const journalLabels = {
    [journals.SECTION_1]: "Раздел 1",
    [journals.SECTION_2]: "Раздел 2",
    [journals.SECTION_3]: "Раздел 3",
    [journals.SECTION_4]: "Раздел 4",
    [journals.SECTION_5]: "Раздел 5",
    [journals.SECTION_6]: "Раздел 6",
};
