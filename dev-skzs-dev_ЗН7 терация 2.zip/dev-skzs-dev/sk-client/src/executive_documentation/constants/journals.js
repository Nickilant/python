export const journals = {
    SECTION_1: "SECTION_1",
    SECTION_2: "SECTION_2",
    SECTION_3: "SECTION_3",
    SECTION_4: "SECTION_4",
    SECTION_5: "SECTION_5",
    SECTION_6: "SECTION_6",
};
