import React from "react";

import "./styles.scss";
import { TopNavigate } from "../../containers/TopNavigate/component";
import { TableActionsPanel } from "../../containers/TableActionsPanel/container";
import { SelectJournal } from "../../containers/SelectJournal/container";
import { JournalTable } from "../../containers/JournalTable/container";
import { TreeStructureContainer } from "../../../categories/containers/TreeStructure/container";

export const JournalsPage = () => (
    <div className="executive-documentation-module journals-page columns">
        <TreeStructureContainer treeName="documents-list" disableContext rememberGroupInStorage />
        <div className="content">
            <TopNavigate />
            <TableActionsPanel />
            <SelectJournal />
            <JournalTable />
        </div>
    </div>
);
