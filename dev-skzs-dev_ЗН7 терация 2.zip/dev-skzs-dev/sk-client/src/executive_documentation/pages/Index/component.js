import React from "react";
import { useSelector } from "react-redux";

import { TopNavigate } from "../../containers/TopNavigate/component";
import { StatusFilters } from "../../containers/StatusFilters/container";
import { SearchBar } from "../../containers/SearchBar/container";
import { TypeFilters } from "../../containers/TypeFilters/container";
import { AttrFilters } from "../../containers/AttrFilters/container";
import { DocumentsList } from "../../containers/DocumentsList/container";
import { TreeStructureContainer } from "../../../categories/containers/TreeStructure/container";
import { FileAttachment } from "../../../documents/containers/FileAttachment/container";

import "./styles.scss";

export const ExecutiveDocumentationPage = () => {
    const attachmentFormOpened = useSelector((state) => state.documents.attachmentForm.attachmentFormOpened);

    return (
        <div className="executive-documentation-module executive-documentation-page columns">
            { attachmentFormOpened && <FileAttachment /> }
            <TreeStructureContainer treeName="documents-list" disableContext rememberGroupInStorage />
            <div className="content">
                <div className="top-panel">
                    <TopNavigate />
                    <StatusFilters />
                </div>
                <SearchBar />
                <TypeFilters />
                <div className="divider" />
                <div className="list-head">
                    <AttrFilters />
                </div>
                <DocumentsList />
            </div>
        </div>
    );
};
