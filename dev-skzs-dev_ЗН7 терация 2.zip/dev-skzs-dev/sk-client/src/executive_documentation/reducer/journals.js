import { JOURNALS_ACTIONS } from "../actions/journals/actionTypes";

const initialState = {
    sections: [],
    journal: [],
    pending: false,
    error: null,
};

export const journalsReducer = (state = initialState, action) => {
    switch (action.type) {
        case JOURNALS_ACTIONS.SET_DATE:
        case JOURNALS_ACTIONS.GET_JOURNAL:
        case JOURNALS_ACTIONS.GET_SECTIONS: {
            return {
                ...state,
                pending: true,
                error: false,
            };
        }
        case JOURNALS_ACTIONS.SET_DATE_FAILED:
        case JOURNALS_ACTIONS.GET_JOURNAL_FAILED:
        case JOURNALS_ACTIONS.GET_SECTIONS_FAILED: {
            const { error } = action.payload;

            return {
                ...state,
                pending: false,
                error,
            };
        }
        case JOURNALS_ACTIONS.GET_SECTIONS_COMPLETE: {
            const { sections } = action.payload;

            return {
                ...state,
                sections,
                pending: false,
            };
        }
        case JOURNALS_ACTIONS.SET_DATE_COMPLETE:
        case JOURNALS_ACTIONS.GET_JOURNAL_COMPLETE: {
            const { journal } = action.payload;

            return {
                ...state,
                journal,
                pending: false,
            };
        }
        default:
            return state;
    }
};
