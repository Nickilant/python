import { LIST_ATTRIBUTES_SET } from "../actions/listAttributes/listAttributes";

const initialState = {
    statusFilters: [],
    searchQuery: "",
    typeFilters: [],
    attribute: {},
};

export const listAttributesReducer = (state = initialState, action) => {
    switch (action.type) {
        case LIST_ATTRIBUTES_SET: {
            return {
                ...state,
                ...action.payload,
            };
        }
        default:
            return state;
    }
};
