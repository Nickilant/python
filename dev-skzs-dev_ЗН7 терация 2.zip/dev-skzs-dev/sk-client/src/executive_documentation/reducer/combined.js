import { combineReducers } from "redux";
import { listAttributesReducer } from "./listAttributes";
import { journalsReducer } from "./journals";

export const executiveDocumentationReducers = combineReducers({
    listAttributes: listAttributesReducer,
    journals: journalsReducer,
});
