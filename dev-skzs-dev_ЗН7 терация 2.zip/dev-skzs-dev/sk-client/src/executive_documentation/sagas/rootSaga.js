import { all } from "redux-saga/effects";
import { journalsCombinedSaga } from "./journalsSaga";

export function* executiveDocumentationRootSaga() {
    yield all([
        journalsCombinedSaga(),
    ]);
}
