import moment from "moment";

import { journals } from "../constants/journals";
import { dateFormat } from "../../shared/constants/dateFormats";

export const journalConverters = {
    [journals.SECTION_3]: (document) => ({
        id: document.sid,
        number: document.serial_number,
        date: moment(document.timestamp).format(dateFormat),
        name: document.name,
        author: `${document.author.position} ${document.author.full_name}`,
    }),
    [journals.SECTION_6]: (document) => ({
        id: document.sid,
        number: document.serial_number,
        name: document.name,
        info: document.aosr_signature_info,
    }),
};
