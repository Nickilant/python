import axios from "axios";
import {
    all, call, put, takeLatest,
} from "@redux-saga/core/effects";

import { LOCATION_CHANGE } from "connected-react-router";
import { JOURNALS_ACTIONS } from "../actions/journals/actionTypes";
import {
    changeJournalsDateComplete,
    changeJournalsDateFailed,
    getJournal,
    getJournalComplete,
    getJournalFailed,
    getSections,
    getSectionsComplete,
    getSectionsFailed,
} from "../actions/journals/actions";
import { journalConverters } from "./journalConverters";

const exceptionHandler = ({ e }) => {
    // TODO: other terrible cases
    console.error("Unhandled server issue", e);
};

export function* journalsSaga() {
    function* changeDate({ payload }) {
        try {
            const journal = (yield call(axios.get,
                `/projects/${payload.project}/work-journals/${payload.section}/work-journal-entries`, {
                    params: {
                        ...payload.form,
                    },
                })
            ).data.results;
            const mappedJournal = journal.map((it) => journalConverters[it.work_journal.section](it));

            yield put(changeJournalsDateComplete({ journal: mappedJournal }));
        } catch (e) {
            if (e.response.status === 400) {
                yield call(exceptionHandler, { payload, e });
                yield put(changeJournalsDateFailed({ error: e.message }));
            } else {
                yield call(exceptionHandler, { payload, e });
            }
        }
    }

    function* getSectionsRequest({ payload }) {
        try {
            const sections = (yield call(axios.get, `/projects/${payload.project}/work-journals`)).data.results;
            yield put(getSectionsComplete({ sections }));
        } catch (e) {
            if (e.response.status === 400) {
                yield call(exceptionHandler, { payload, e });
                yield put(getSectionsFailed({ error: e.message }));
            } else {
                yield call(exceptionHandler, { payload, e });
            }
        }
    }

    function* getJournalRequest({ payload }) {
        try {
            const journal = (yield call(axios.get, `/projects/${payload.project}/work-journals/${payload.section}/work-journal-entries`)).data.results;
            const mappedJournal = journal.map((it) => journalConverters[it.work_journal.section](it));

            yield put(getJournalComplete({ journal: mappedJournal }));
        } catch (e) {
            if (e.response.status === 400) {
                yield call(exceptionHandler, { payload, e });
                yield put(getJournalFailed({ error: e.message }));
            } else {
                yield call(exceptionHandler, { payload, e });
            }
        }
    }

    yield takeLatest(JOURNALS_ACTIONS.GET_SECTIONS, getSectionsRequest);
    yield takeLatest(JOURNALS_ACTIONS.GET_JOURNAL, getJournalRequest);
    yield takeLatest(JOURNALS_ACTIONS.SET_DATE, changeDate);
}

function* journalsManagementSaga() {
    function* watchRouteChanges({ payload }) {
        const path = payload.location.pathname;
        const pathArr = path.split("/");

        if (path.indexOf("executive-documents") + 1) {
            const project = pathArr[pathArr.indexOf("projects") + 1];

            yield put(getSections({ project }));

            if (pathArr.indexOf("journals") + 1) {
                const section = pathArr[pathArr.indexOf("journals") + 1];

                yield put(getJournal({ project, section }));
            }
        }
    }

    yield takeLatest(LOCATION_CHANGE, watchRouteChanges);
}

export function* journalsCombinedSaga() {
    yield all([
        journalsSaga(),
        journalsManagementSaga(),
    ]);
}
