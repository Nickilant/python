import React from "react";
import { useDispatch, useSelector } from "react-redux";
import { push } from "connected-react-router";

import { getGeotags } from "../../../construction_control/base/selectors/geotags";
import {
    geoMarkersCRUDActions,
    markerCreatingAction,
    selectLayerAction,
} from "../../../construction_control/extra_2d/actions/actions";
import { getURL } from "../../../shared/helpers/getPath";
import { getCurrentDocument } from "../../selectors/documents";
import { selectGeotagAction } from "../../../construction_control/base/actions/geoList/actions";
import { selectActiveProject } from "../../../projects/selectors/projects";
import { currentCategory } from "../../../categories/selectors/treeStructure";

import "./styles.scss";
import {
    canAddGeotagPredicate,
    canDeleteGeotagPredicate,
} from "../../../construction_control/base/selectors/permissions";

export const Geotags = (props) => {
    const dispatch = useDispatch();
    const currentDocument = useSelector((state) => getCurrentDocument(state));
    const defaultGeotags = useSelector((state) => getGeotags(state));
    const routerPathParams = useSelector((state) => state.core.router);
    const documents = useSelector((state) => state.documents.crud.items);
    const project = useSelector((state) => selectActiveProject(state));
    const category = useSelector((state) => currentCategory(state));

    const {
        geotags = defaultGeotags,
        onAdd = () => {
            dispatch(markerCreatingAction({
                type: "document",
                id: currentDocument.id,
            }));

            const path = getURL(routerPathParams, ["projects", ["section", "geodata"], "group"]);
            dispatch(push(path));
        },
        onSelect = (geotag) => {
            dispatch(selectLayerAction(geotag.layer));
            dispatch(selectGeotagAction(geotag));

            const path = getURL(routerPathParams,
                ["projects", ["section", "geodata"],
                    ["group", documents[geotag.map].project_document.related_category],
                ]);
            dispatch(push(path));
        },
        onRemove = (geotag) => {
            dispatch(geoMarkersCRUDActions.use.DELETE_ENTITY({
                source: {
                    project,
                    sid: geotag.sid,
                    map: { sid: geotag.map },
                    category,
                    document: currentDocument,
                },
            }));
        },
        // onEdit = () => {
        // },
    } = props;
    const canAddGeotag = useSelector((state) => canAddGeotagPredicate(state, currentDocument.type));
    const canDeleteGeotag = useSelector((state) => canDeleteGeotagPredicate(state));
    return (
        <div className="geotags">
            {
                canAddGeotag
                && (
                    <div className="add-block">
                        <div className="add-icon" />

                        <button
                            className="add-btn"
                            onClick={onAdd}
                        >
                            Добавить новую
                            <div className="plus" />
                        </button>

                    </div>
                )
            }
            <div className="divider" />
            <div className="list">
                {
                    geotags && geotags.length
                        ? geotags.map((g) => (
                            <div onClick={() => onSelect(g)} className="geotag" key={g.sid}>
                                <div className="geotag-icon" />
                                <div className="info">
                                    <div className="title">
                                        {g.name}
                                        {g.favorite && <div className="star" />}
                                    </div>
                                    <div className="desc">
                                        {g.description}
                                    </div>
                                </div>
                                <div className="actions">
                                    {/* <div */}
                                    {/*    onClick={(e) => { */}
                                    {/*        e.stopPropagation(); */}
                                    {/*        return onEdit(g); */}
                                    {/*    }} */}
                                    {/*    className="action-icon edit" */}
                                    {/* /> */}
                                    {
                                        canDeleteGeotag && (
                                            <div
                                                onClick={(e) => {
                                                    e.stopPropagation();
                                                    return onRemove(g);
                                                }}
                                                className="action-icon remove"
                                            />
                                        )
                                    }
                                </div>
                            </div>
                        ))
                        : (
                            <div className="no-geotags">
                                <div className="no-img" />
                                Геотеги к текущему документу еще не созданы
                            </div>
                        )
                }
            </div>
        </div>
    );
};
