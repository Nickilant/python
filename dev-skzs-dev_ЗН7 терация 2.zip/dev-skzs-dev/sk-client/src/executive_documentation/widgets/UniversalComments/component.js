import React, { useState } from "react";
import { connect, useSelector } from "react-redux";
import { Input } from "antd";

import { UniversalComment } from "../UniversalComment/component";
import { selectActiveProject } from "../../../projects/selectors/projects";
import { commentsCRUDActions } from "../../../comments/actions/actions";

import "./styles.scss";
import { documentsCRUDActions } from "../../../documents/actions/actions";
import { canAddCommentPredicate } from "../../../construction_control/base/selectors/permissions";

const { TextArea } = Input;

export const UniversalCommentsComponent = (props) => {
    const {
        document,
        user,
        comments,
        addComment,
        project,
        updateComment,
        removeComment,
        refreshDocument,
    } = props;

    const {
        full_name,
        avatar,
    } = user;

    const [text, changeText] = useState("");

    const handleChange = (e) => {
        changeText(e.target.value);
    };

    const handleRefreshDocument = () => {
        refreshDocument({
            source: {
                ...document,
                project,
            },
        });
    };

    const handleSubmitComment = () => {
        if (!text.trim()) {
            return null;
        }

        addComment({ source: { project, entity: document }, form: { body: text.trim() } });

        handleRefreshDocument();
        changeText("");
    };

    const canAddComment = useSelector((state) => canAddCommentPredicate(state));

    const handleEdit = (id, commentText) => {
        updateComment({
            source: {
                project,
                entity: document,
                sid: id,
            },
            form: {
                body: commentText,
            },
        });
    };

    const handleRemove = (id) => {
        removeComment({ source: { project, entity: document, sid: id } });
    };

    const handleCtrlEnter = (e) => {
        if (e.ctrlKey && e.keyCode === 13) {
            handleSubmitComment();
        }
    };

    return (
        <div className="universal-comments">
            {canAddComment && (
                <div className="add-comment">
                    <div className="comment-text-block">
                        <TextArea
                            className="comment-text"
                            placeholder="Написать свой комментарий"
                            autoSize={{ minRows: 1, maxRows: 6 }}
                            value={text}
                            onKeyDown={handleCtrlEnter}
                            onChange={handleChange}
                        />
                    </div>
                    <div className="comment-desc">
                        <div className="avatar-block">
                            <img className="avatar" src={avatar} alt="Аватар" />
                        </div>
                        <div className="name">{full_name}</div>
                        <button className="submit-comment" onClick={handleSubmitComment}>Прокомментировать</button>
                    </div>
                </div>
            )}
            <div className="divider" />
            <div className="comments-list">
                {
                    comments && comments.length
                        ? comments.map((item) => (
                            <UniversalComment
                                key={item.sid}
                                comment={item}
                                onEdit={(newText) => handleEdit(item.sid, newText)}
                                onRemove={() => handleRemove(item.sid)}
                                own={item.user.sid === user.sid}
                            />
                        ))
                        : (
                            <div className="no-comments">
                                <div className="no-comments-icon" />
                                Пока ещё никто не оставил свой комментарий.
                            </div>
                        )
                }
            </div>
        </div>
    );
};

export const UniversalComments = connect((state) => ({
    comments: Object.values(state.comments.crud.items),
    user: state.users.currentUser.user,
    project: selectActiveProject(state),

}), {
    addComment: commentsCRUDActions.use.CREATE_ENTITY,
    updateComment: commentsCRUDActions.use.UPDATE_ENTITY,
    removeComment: commentsCRUDActions.use.DELETE_ENTITY,
    refreshDocument: documentsCRUDActions.use.GET_ENTITY_DETAILS,
})(UniversalCommentsComponent);
