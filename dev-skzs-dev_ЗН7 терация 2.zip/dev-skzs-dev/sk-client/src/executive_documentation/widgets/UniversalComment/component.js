import React, { useState } from "react";
import cx from "classnames";
import { useSelector } from "react-redux";
import { Input } from "antd";
import { NavLink } from "react-router-dom";

import "./styles.scss";
import updateIcon from "../../../shared/Comment/assets/update.svg";
import removeIcon from "../../../shared/Comment/assets/remove.svg";
import { canDeleteCommentPredicate, canEditComment } from "../../../construction_control/base/selectors/permissions";

const { TextArea } = Input;

export const UniversalComment = (props) => {
    const {
        comment, onEdit, onRemove, own,
    } = props;

    const {
        body: text,
        user,
        status,
        creation_date: date,
    } = comment;

    const textField = React.createRef();

    const [inputValue, setInputValue] = useState(text);
    const [updatingComment, setCommentStatus] = useState(false);

    const canEdit = useSelector((state) => canEditComment(state, comment));
    const canDelete = useSelector((state) => canDeleteCommentPredicate(state, comment));

    const handleUpdate = () => {
        setCommentStatus(true);
        textField.current.focus();
    };

    const changeTextarea = (e) => {
        setInputValue(e.target.value);
    };
    const blurTextarea = () => {
        setCommentStatus(false);
        onEdit(inputValue);
    };

    const handleCtrlEnter = (e) => {
        if (e.ctrlKey && e.keyCode === 13) {
            blurTextarea();
        }
    };

    return (
        <div
            className={cx(
                "universal-comment",
                {
                    own,
                    "not-send": status === "not_send" && !updatingComment,
                },
            )}
        >
            <div className="comment-text-block">
                <TextArea
                    className="comment-text"
                    placeholder="Написать свой комментарий"
                    ref={textField}
                    autoSize={{
                        minRows: 1,
                        maxRows: 6,
                    }}
                    readOnly={!updatingComment}
                    value={inputValue}
                    onChange={changeTextarea}
                    onBlur={blurTextarea}
                    onKeyDown={handleCtrlEnter}
                />
                <div className="controls">
                    {canEdit && (
                        <img
                            src={updateIcon}
                            alt="Изменить"
                            className="update"
                            onClick={handleUpdate}
                        />
                    )}
                    {canDelete && (
                        <img
                            src={removeIcon}
                            alt="Удалить"
                            className="remove"
                            onClick={onRemove}
                        />
                    )}
                </div>
            </div>
            <div className="comment-desc">
                <img
                    className="avatar"
                    src={(user && user.avatar) || `https://avatars.dicebear.com/v2/jdenticon/${Math.random()}.svg`}
                    alt="Аватар"
                />
                <NavLink className="link name" to={`/users/${user && user.sid}`}>{user && user.full_name}</NavLink>
                <div className="date">{new Date(date).toLocaleString("ru")}</div>
            </div>
        </div>
    );
};
