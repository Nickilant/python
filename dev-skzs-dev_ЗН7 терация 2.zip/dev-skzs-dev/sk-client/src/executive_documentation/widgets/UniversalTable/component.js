import React from "react";

import "./styles.scss";

export const UniversalTable = (props) => {
    const { columns, rows } = props;

    return (
        <table className="universal-table">
            <thead className="table-head">
                <tr>
                    {
                        columns.map((c) => (
                            <th
                                key={c.value}
                                className="th"
                                width={c.width}
                                align={c.align}
                            >
                                {c.label}
                            </th>
                        ))
                    }
                </tr>
            </thead>
            <tbody>
                {
                    rows.map((r, index) => (
                        <tr
                            key={index}
                            className="row"
                        >
                            {
                                columns.map((c) => (
                                    <td
                                        key={c.value}
                                        className="td"
                                        align={c.align}
                                    >
                                        {r[c.value]}
                                    </td>
                                ))
                            }
                        </tr>
                    ))
                }
            </tbody>
        </table>
    );
};
