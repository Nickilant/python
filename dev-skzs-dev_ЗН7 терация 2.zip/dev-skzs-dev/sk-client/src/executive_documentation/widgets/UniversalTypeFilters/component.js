import React, { useEffect, useState } from "react";
import { useDispatch } from "react-redux";

import { FiltersLogic } from "../../../shared/components/FiltersLogic/component";
import { UniversalTypeFilter } from "../UniversalTypeFilter/component";

import "./styles.scss";

export const UniversalTypeFilters = (props) => {
    const {
        types,
        setActionReducer,
    } = props;
    const [filters, setFilters] = useState(types);
    const dispatch = useDispatch();

    const handleSelectFilter = ({ name, active }, clearAll = false) => {
        const newFilters = clearAll
            ? filters.map((filter) => ({ ...filter, active: false }))
            : filters.map((filter) => (filter.name === name
                ? { ...filter, active: !active }
                : filter));

        setFilters([...newFilters]);
    };

    useEffect(() => {
        dispatch(setActionReducer({
            typeFilters: filters.filter((filter) => filter.active).map((filter) => filter.name),
        }));
    }, [filters, setActionReducer, dispatch]);

    const allItemConfig = {
        label: "Все документы",
    };

    return (
        <div className="universal-type-filters">
            <FiltersLogic
                items={filters}
                ItemComponent={UniversalTypeFilter}
                allItemConfig={allItemConfig}
                onSelect={handleSelectFilter}
            />
        </div>
    );
};
