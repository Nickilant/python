import React, { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import cx from "classnames";

import { FiltersLogic } from "../../../shared/components/FiltersLogic/component";
import { UniversalStatusFilter } from "../UniversalStatusFilter/component";

import "./styles.scss";
import infoIcon from "./assets/info.svg";

export const UniversalStatusFilters = (props) => {
    const {
        title,
        statuses,
        infoContent,
        setActionReducer,
        items,
        allConfig,
    } = props;

    const dispatch = useDispatch();
    const [filters, setFilters] = useState([...statuses]);
    const [show, toggleShow] = useState(false);

    useEffect(() => {
        const statusesFilter = (documents, status) => documents.filter((i) => i.status === status);

        setFilters((prev) => prev.map((s) => ({
            ...s,
            count: statusesFilter(items, s.name).length,
        })));
    }, [items]);

    const handleSelectFilter = ({ name, active }, clearAll = false) => {
        const newFilters = clearAll
            ? filters.map((filter) => ({ ...filter, active: false }))
            : filters.map((filter) => (filter.name === name
                ? { ...filter, active: !active }
                : filter));

        setFilters([...newFilters]);

        dispatch(setActionReducer({
            statusFilters: newFilters.filter((filter) => filter.active).map((filter) => filter.name),
        }));
    };

    const allItemConfig = {
        count: (allConfig && Number.isInteger(allConfig.count)) ? allConfig.count : filters.reduce((acc, f) => acc + f.count, 0),
    };

    return (
        <div className="universal-status-filters">
            <div className="title">
                {title}
            </div>
            <div className="filters">
                <FiltersLogic
                    items={filters}
                    ItemComponent={UniversalStatusFilter}
                    allItemConfig={allItemConfig}
                    onSelect={handleSelectFilter}
                />
            </div>
            <div className="info-block">
                <img
                    className="info-icon"
                    onMouseLeave={() => toggleShow(false)}
                    onMouseEnter={() => toggleShow(true)}
                    src={infoIcon}
                    alt="Доп. информация"
                />
                <div className={cx("info-text", show && "show")}>
                    {infoContent()}
                </div>
            </div>
        </div>
    );
};
