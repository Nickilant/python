import React, { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import cx from "classnames";

import "./styles.scss";

export const UniversalAttrFilters = (props) => {
    const {
        attrs,
        setActionReducer,
    } = props;
    const dispatch = useDispatch();

    const [filters, setFilters] = useState(attrs);

    const handleToggleAttr = (attr) => {
        setFilters(filters.map((a) => {
            if (attr.name === a.name) {
                return {
                    ...a,
                    active: true,
                    order: attr.active && a.order === "asc" ? "desc" : "asc",
                };
            }

            return {
                ...a,
                active: false,
                order: "asc",
            };
        }));
    };

    useEffect(() => {
        dispatch(setActionReducer({
            attribute: {
                ...(() => {
                    const founded = filters.find((attr) => attr.active);
                    return founded && { name: founded.name, order: founded.order };
                })(),
            },
        }));
    }, [filters, setActionReducer, dispatch]);

    return (
        <div className="universal-attr-filters">
            {
                filters.map((attr) => (
                    <div
                        key={attr.name}
                        onClick={() => handleToggleAttr(attr)}
                        className={cx("attr", { [`attr-active attr-${attr.order}`]: attr.active })}
                    >
                        {attr.label}
                    </div>
                ))
            }
        </div>
    );
};
