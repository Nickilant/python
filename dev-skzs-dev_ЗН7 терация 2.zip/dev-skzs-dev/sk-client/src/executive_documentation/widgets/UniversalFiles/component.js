import React from "react";
import { useDispatch, useSelector } from "react-redux";

import { SectionDocumentListItem } from "../../../documents/components/SectionDocumentsListItem/component";
import { getCurrentDocument } from "../../selectors/documents";

import "./styles.scss";
import { openAttachmentFormAction } from "../../../documents/actions/FileAttachment/actions";
import { documentsCRUDActions } from "../../../documents/actions/actions";
import { selectActiveProject } from "../../../projects/selectors/projects";
import { setUploadingListAction } from "../../../documents/actions/SectionDocumentList/actions";
import {
    canAttachFilePredicate,
    canDeleteFilePredicate,
} from "../../../construction_control/base/selectors/permissions";

export const UniversalFiles = (props) => {
    const dispatch = useDispatch();
    const defaultFiles = useSelector((state) => getCurrentDocument(state).file_documents);
    const currentDocument = useSelector((state) => getCurrentDocument(state));
    const project = useSelector((state) => selectActiveProject(state));

    const {
        addFile = () => {
            dispatch(setUploadingListAction([]));
            dispatch(openAttachmentFormAction(currentDocument));
        },
        files = defaultFiles,
        onRemove = (file, module) => {
            dispatch(documentsCRUDActions.use.UPDATE_ENTITY({
                source: {
                    id: currentDocument.id,
                    project,
                    type: currentDocument.type,
                },
                form: {
                    file_documents_remove: [file.sid],
                },
                module,
            }));
        },
        module,
    } = props;

    const canAttachFile = useSelector((state) => canAttachFilePredicate(state));
    const canDeleteFile = useSelector((state) => canDeleteFilePredicate(state));

    return (
        <div className="universal-files">
            {canAttachFile && (
                <div className="add-block">
                    <div className="new-file-icon" />
                    <button
                        className="btn-add"
                        onClick={addFile}
                    >
                        Добавить файл
                        <div className="plus" />
                    </button>
                </div>
            )}
            <div className="divider" />
            <div className="file-list">
                {
                    files && files.length
                        ? files.map((file) => (
                            <SectionDocumentListItem
                                key={file.sid}
                                id={file.sid}
                                item={{
                                    title: file.file_name,
                                    description: file.comment,
                                    size: file.size,
                                    link: file.file,
                                    ext: file.file_ext,
                                    sid: file.sid,
                                }}
                                removeFile={canDeleteFile && ((file) => onRemove(file, module))}
                            />
                        ))
                        : (
                            <div className="no-files">
                                <div className="no-files-icon" />
                                Пока ещё никто не успел загрузить документов к этому разделу.
                            </div>
                        )
                }
            </div>
        </div>
    );
};
