import React from "react";
import cx from "classnames";

import "./styles.scss";

export const UniversalStatusFilter = (props) => {
    const {
        name, active, count, onSelect,
    } = props;

    return (
        <div
            onClick={onSelect}
            className={cx("filter", `filter-${name}`, { "filter-active": active })}
        >
            {count}
        </div>
    );
};
