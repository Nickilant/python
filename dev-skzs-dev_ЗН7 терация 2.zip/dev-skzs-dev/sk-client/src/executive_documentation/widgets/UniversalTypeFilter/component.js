import React from "react";
import cx from "classnames";

import "./styles.scss";

export const UniversalTypeFilter = (props) => {
    const {
        name, active, label, onSelect,
    } = props;

    return (
        <div
            onClick={onSelect}
            className={cx("filter", `filter-${name}`, { "filter-active": active })}
        >
            {label}
        </div>
    );
};
