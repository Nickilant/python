import React, { useEffect } from "react";

import "./styles.scss";
import { useDispatch, useSelector } from "react-redux";
import { HistoryItem } from "../../../construction_control/base/components/HistoryItem/component";
import { selectActiveProject } from "../../../projects/selectors/projects";
import { selectedDocumentView } from "../../../documents/selectors/documents";
import { entityEvents } from "../../../event_log/selectors/events";
import { eventsCRUDActions } from "../../../event_log/actions/actions";

export const UniversalHistory = (props) => {
    const dispatch = useDispatch();
    const project = useSelector(selectActiveProject);
    const currentDocument = useSelector(selectedDocumentView);
    const events = useSelector(entityEvents);

    useEffect(() => {
        dispatch(
            eventsCRUDActions.use.LIST_ENTITIES({
                source: {
                    project,
                    entity: currentDocument,
                },
            }),
        );
    }, [currentDocument, dispatch, project]);

    const history = events;

    return (
        <div className="universal-history history-list">
            <div className="divider" />
            {
                history
                    ? history.map((item) => (
                        <div key={item.sid}>
                            <HistoryItem
                                user={item.user}
                                title={item.local_body}
                                date={item.creation_date}
                            />
                        </div>
                    ))
                    : (
                        <div className="no-history">
                            <div className="no-img" />
                            Истории изменений пока нет.
                        </div>
                    )
            }
        </div>
    );
};
