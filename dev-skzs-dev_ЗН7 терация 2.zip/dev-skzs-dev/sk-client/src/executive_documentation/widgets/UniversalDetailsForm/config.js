import React from "react";

import { PREVIEW_MODULES } from "../../../construction_control/base/widgets/DocumentPreviewColumn/previewModules";
import { PrescriptionDetailsFormWidget } from "../../../construction_control/base/widgets/PrescriptionDetailsForm/component";
import { DocumentDetailsForm } from "../../components/DocumentDetailsForm/component";

export const configForms = {
    [PREVIEW_MODULES.CONSTRUCTION_CONTROL]: () => <PrescriptionDetailsFormWidget />,
    [PREVIEW_MODULES.EXECUTIVE_DOCUMENTATION]: () => <DocumentDetailsForm />,
};
