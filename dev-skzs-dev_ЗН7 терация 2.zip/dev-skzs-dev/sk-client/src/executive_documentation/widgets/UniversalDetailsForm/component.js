import { configForms } from "./config";
import { PREVIEW_MODULES } from "../../../construction_control/base/widgets/DocumentPreviewColumn/previewModules";

export const UniversalDetailsForm = (props) => {
    const { module = PREVIEW_MODULES.CONSTRUCTION_CONTROL, ...others } = props;

    return configForms[module](others);
};
