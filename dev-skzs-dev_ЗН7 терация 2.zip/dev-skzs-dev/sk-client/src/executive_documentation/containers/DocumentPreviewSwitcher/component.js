import React from "react";

import { Switcher } from "../../../shared/components/Switcher/component";
import { SWITCHER_TYPES } from "../../../shared/constants/switcherTypes";
import { PreviewView } from "../PreviewView/container";
import { Geotags } from "../../widgets/UniversalGeotags/component";
import { UniversalComments } from "../../widgets/UniversalComments/component";
import { UniversalFiles } from "../../widgets/UniversalFiles/component";
import { UniversalHistory } from "../../widgets/UniversalHistory/component";
import { PREVIEW_MODULES } from "../../../construction_control/base/widgets/DocumentPreviewColumn/previewModules";

import "./styles.scss";

export const DocumentPreviewSwitcher = (props) => {
    const { document } = props;

    const {
        commentsCount,
        filesCount,
        geotagsCount,
    } = document;

    const config = [
        {
            type: SWITCHER_TYPES.VIEW,
            title: "Полный вид АОСР",
            component: () => (
                <PreviewView />
            ),
        },
        {
            type: SWITCHER_TYPES.HISTORY,
            title: "История изменений",
            component: () => (
                <UniversalHistory />
            ),
        },
        {
            type: SWITCHER_TYPES.VERTICAL_DIVIDER,
        },
        {
            type: SWITCHER_TYPES.GEOTAGS,
            title: "Геометки",
            count: geotagsCount,
            component: () => (
                <Geotags />
            ),
        },
        {
            type: SWITCHER_TYPES.COMMENTS,
            title: "Комментарии",
            count: commentsCount,
            component: () => (
                <UniversalComments document={document} />
            ),
        },
        {
            type: SWITCHER_TYPES.FILES,
            title: "Файлы",
            count: filesCount,
            component: () => (
                <UniversalFiles
                    module={PREVIEW_MODULES.EXECUTIVE_DOCUMENTATION}
                />
            ),
        },
    ];

    return (
        <Switcher
            config={config}
        />
    );
};
