import React from "react";

import { UniversalAttrFilters } from "../../widgets/UniversalAttrFilters/component";
import { setAttrAction } from "../../actions/listAttributes/actions";

import "./styles.scss";

export const AttrFilters = () => {
    const attrs = [
        {
            name: "status",
            label: "",
            active: false,
            order: "asc",
        },
        {
            name: "title",
            label: "Имя",
            active: false,
            order: "asc",
        },
        {
            name: "act_date",
            label: "Дата создания",
            active: false,
            order: "asc",
        },
        {
            name: "subscriptionDate",
            label: "Дата подписания",
            active: false,
            order: "asc",
        },
        {
            name: "company",
            label: "Подрядчик",
            active: false,
            order: "asc",
        },
    ];

    return (
        <div className="attr-filters">
            <UniversalAttrFilters
                attrs={attrs}
                setActionReducer={setAttrAction}
            />
        </div>
    );
};
