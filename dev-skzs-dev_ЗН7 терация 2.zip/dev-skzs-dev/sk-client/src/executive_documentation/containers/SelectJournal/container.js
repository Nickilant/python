import React from "react";
import { Select } from "antd";
import { useDispatch, useSelector } from "react-redux";
import { push } from "connected-react-router";

import { getURL } from "../../../shared/helpers/getPath";
import { getSectionsSelector } from "../../selectors/journals";
import { journalLabels } from "../../constants/journalLabels";

import "./styles.scss";

const { Option } = Select;

export const SelectJournal = () => {
    const dispatch = useDispatch();
    const sections = useSelector((state) => getSectionsSelector(state));
    const routerPathParams = useSelector((state) => state.core.router);

    const handleChange = (id) => {
        const path = getURL(routerPathParams, ["projects", "section", "executive_documentation", ["journals", id]]);

        dispatch(push(path));
    };

    return (
        <Select className="journal-selector" value={routerPathParams.journals} onChange={handleChange}>
            {
                sections.map((opt) => (
                    <Option
                        key={opt.sid}
                        value={opt.sid}
                    >
                        {journalLabels[opt.section]}
                    </Option>
                ))
            }
        </Select>
    );
};
