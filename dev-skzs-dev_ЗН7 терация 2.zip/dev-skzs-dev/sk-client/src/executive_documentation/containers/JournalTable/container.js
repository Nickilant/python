import React from "react";
import { useSelector } from "react-redux";

import { UniversalTable } from "../../widgets/UniversalTable/component";
import { columnsConfig } from "./columnsConfig";
import { getSection, sortJournalRowsByNumber } from "../../selectors/journals";

import "./styles.scss";

export const JournalTable = () => {
    const journal = useSelector(sortJournalRowsByNumber);

    const sectionObj = useSelector((state) => getSection(state, state.core.router.journals)) || {};
    const {
        section = "",
    } = sectionObj;

    const columns = columnsConfig[section] || [];

    return (
        <div className="journal-table">
            <UniversalTable
                columns={columns}
                rows={journal}
            />
        </div>
    );
};
