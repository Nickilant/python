import React from "react";

import { useDispatch, useSelector } from "react-redux";

import "./styles.scss";
import { push } from "connected-react-router";
import { closeModalAction, openModalAction } from "../../../shared/actions/Modal/actions";
import { WIDGET_TYPES_MODAL } from "../../../shared/constants/widgetTypesModal";
import { getURL } from "../../../shared/helpers/getPath";

export const TopNavigate = () => {
    const dispatch = useDispatch();
    const routerPathParams = useSelector((state) => state.core.router);

    const journalSelected = (id) => {
        dispatch(closeModalAction());
        const path = getURL(routerPathParams, ["projects", "section", "executive_documentation", "group", ["journals", id]]);

        dispatch(push(path));
    };

    const openJournalSelect = () => {
        dispatch(openModalAction({
            widget: WIDGET_TYPES_MODAL.EXECUTIVE_DOCUMENTATION_JOURNAL,
            context: {
                title: "Выберите раздел общего журнала работ",
                onOk: journalSelected,
            },
        }));
    };

    const returnToDocuments = () => {
        const path = getURL(routerPathParams, ["projects", "section", "executive_documentation"]);

        dispatch(push(path));
    };

    return (
        <div className="top-navigate">
            {
                routerPathParams.journals
                    ? (
                        <button onClick={returnToDocuments} className="navigate-link">
                            Вернуться к исполнительной документации
                            <div className="icon storage-icon" />
                        </button>
                    )
                    : (
                        <button onClick={openJournalSelect} className="navigate-link">
                            Перейти к общему журналу работ
                            <div className="icon list-icon" />
                        </button>
                    )
            }
        </div>
    );
};
