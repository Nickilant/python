import React from "react";

import { connect } from "react-redux";
import { UniversalStatusFilters } from "../../widgets/UniversalStatusFilters/component";
import { setAttrAction } from "../../actions/listAttributes/actions";

import { filterByType, selectDocuments } from "../../selectors/documents";

import "./styles.scss";
import { getAllChildren } from "../../../categories/selectors/treeStructure";
import { filterByGroup } from "../../../documents/selectors/documents";

export const StatusFiltersContainer = (props) => {
    const { documents } = props;

    const statuses = [
        {
            name: "REJECTED",
            active: false,
            count: 10,
        },
        {
            name: "ON_REVIEW",
            active: false,
            count: 10,
        },
        {
            name: "CONFIRMED",
            active: false,
            count: 10,
        },
    ];

    return (
        <UniversalStatusFilters
            title="Всего документов:"
            statuses={statuses}
            setActionReducer={setAttrAction}
            items={documents}
            infoContent={() => (
                <div className="ed-info-block">
                    <div className="info-text-content">
                        <div className="blue">Синим цветом</div>
                        обозначены все документы
                    </div>
                    <div className="info-text-content">
                        <div className="red">Красным цветом</div>
                        обозначены не подтвержденные документы
                    </div>
                    <div className="info-text-content">
                        <div className="yellow">Желтым цветом</div>
                        обозначены документы, собравшие не все подтверждения
                    </div>
                    <div className="info-text-content">
                        <div className="green">Зеленым цветом</div>
                        обозначены подтвержденные документы
                    </div>
                    <div className="info-text-content">
                        При нажатии на какую-либо из категорий, откроются все предписания и замечания
                        <div className="bold">из выбранной категории</div>
                    </div>
                </div>
            )}
        />
    );
};

export const StatusFilters = connect((state) => {
    const selectedGroups = getAllChildren(state, "documents-list");

    return {
        documents: filterByGroup(
            filterByType(selectDocuments(state), state),
            selectedGroups,
        ),
    };
}, {})(StatusFiltersContainer);
