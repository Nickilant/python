import React from "react";
import { useDispatch, useSelector } from "react-redux";
import cx from "classnames";

import { UserInfo } from "../../../construction_control/base/components/UserInfo/component";
import { personsConfig } from "./presonsConfig";
import { getCurrentDocument } from "../../selectors/documents";
import { documentsCRUDActions } from "../../../documents/actions/actions";
import { selectActiveProject } from "../../../projects/selectors/projects";

import "./styles.scss";

const genBtnLabel = (own, accepted) => {
    if (own && !accepted) {
        return "Подтвердить";
    }

    return accepted ? "Подтверждено" : "На рассмотрении";
};

export const PreviewView = () => {
    const dispatch = useDispatch();
    const project = useSelector((state) => selectActiveProject(state));
    const document = useSelector((state) => getCurrentDocument(state));
    const currentUser = useSelector((state) => state.users.currentUser.user);

    const {
        description,
        work_start_date,
        work_end_date,
        subscriptionDate,
        signatures,
        status,
        module,
        act_date,
        work_activity,
    } = document;

    const users = useSelector((state) => Object.entries(signatures).map(([key, value]) => {
        if (personsConfig[key]) {
            return {
                ...personsConfig[key],
                ...state.users.crud.items[document[key]],
                accepted: value,
            };
        }

        const user = state.users.crud.items[key];

        return {
            ...personsConfig.default,
            ...state.users.crud.items[key],
            accepted: value,
            objKey: user.key,
        };
    }));

    const handleAccept = () => {
        dispatch(documentsCRUDActions.use.UPDATE_ENTITY({
            form: {
                signed: true,
            },
            source: {
                ...document,
                project,
            },
            module,
        }));
    };

    return (
        <div className="preview-view">
            <div className="divider" />
            <div className="block">
                <div className="title">
                    Наименование объекта:
                </div>
                {project.name}
            </div>
            <div className="block">
                <div className="title">
                    Описание работ и объёмы:
                </div>
                {description}
            </div>
            {
                work_activity.contractor && (
                    <div className="block">
                        <div className="title">
                            Подрядчик:
                        </div>
                        {work_activity.contractor.name}
                    </div>
                )
            }
            <div className="block">
                <div className="title">
                    Составитель АОСР:
                </div>
                <UserInfo user={document.author} />
            </div>
            <div className="block">
                <div className="title">
                    Даты проведения работ:
                </div>
                {`${work_start_date.format("DD.MM.YYYY")} - ${work_end_date.format("DD.MM.YYYY")}`}
            </div>
            {
                subscriptionDate && status === "CONFIRMED" && (
                    <div className="block">
                        <div className="title">
                            Дата подписания акта:
                        </div>
                        {subscriptionDate}
                    </div>
                )
            }
            <div className="divider" />
            {
                users.map((p) => {
                    if (!p.key) return false;

                    const own = p.key === currentUser.sid;

                    return (
                        <div className="btn-block" key={p.objKey}>
                            <div className="block">
                                <div className="title">
                                    {p.label}
                                </div>
                                <UserInfo user={p} />
                            </div>
                            <button
                                onClick={() => own && !p.accepted && handleAccept()}
                                className={cx(
                                    "accept-button btn-usual",
                                    { "btn-yellow": !own && !p.accepted },
                                    { "btn-green": p.accepted },
                                )}
                            >
                                <div className="btn-icon" />
                                {
                                    genBtnLabel(own, p.accepted)
                                }
                            </button>
                        </div>
                    );
                })
            }
        </div>
    );
};
