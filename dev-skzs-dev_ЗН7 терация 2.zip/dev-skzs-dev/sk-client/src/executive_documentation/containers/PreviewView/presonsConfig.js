export const personsConfig = {
    author: {
        objKey: "development_executor_representative",
        label: "Представитель лица, осуществляющего строительство:",
    },
    development_executor_cc_representative: {
        objKey: "development_executor_cc_representative",
        label: "Представитель лица, осуществляющего строительство, по вопросам строительного контроля (специалист по организации строительства):",
    },
    documentation_preparer_representative: {
        objKey: "documentation_preparer_representative",
        label: "Представитель лица, осуществляющего подготовку проектной документации:",
    },
    work_executor_representative: {
        objKey: "work_executor_representative",
        label: "Представитель лица, выполнившего работы, подлежащие освидетельствованию:",
    },
    main_cc_specialist: {
        objKey: "main_cc_specialist",
        label: "Главный специалист по строительному контролю",
    },
    default: {
        objKey: "default",
        label: "Иное лицо",
    },
};
