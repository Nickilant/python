import React from "react";

import { useDispatch } from "react-redux";
import { Search } from "../../../shared/components/Search/component";
import { setAttrAction } from "../../actions/listAttributes/actions";

import "./styles.scss";

export const SearchBar = () => {
    const dispatch = useDispatch();

    const handleChange = (value) => {
        dispatch(setAttrAction({ searchQuery: value }));
    };

    return (
        <div className="search">
            <Search
                placeholder="Поиск по названию"
                onSearch={handleChange}
            />
        </div>
    );
};
