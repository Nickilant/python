import React from "react";

import { UniversalTypeFilters } from "../../widgets/UniversalTypeFilters/component";
import { setAttrAction } from "../../actions/listAttributes/actions";

import "./styles.scss";

export const TypeFilters = () => {
    const types = [
        {
            name: "ACT",
            active: false,
            label: "Акт",
        },
        {
            name: "aosr",
            active: false,
            label: "АОСР",
        },
        {
            name: "SCHEME",
            active: false,
            label: "Схема",
        },
        {
            name: "PROTOCOL",
            active: false,
            label: "Протокол",
        },
        {
            name: "AOOK",
            active: false,
            label: "АООК",
        },
    ];

    return (
        <UniversalTypeFilters
            types={types}
            setActionReducer={setAttrAction}
        />
    );
};
