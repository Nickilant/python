import React, { useEffect } from "react";
import { connect } from "react-redux";
import { push } from "connected-react-router";

import { DocumentsListItem } from "../../components/DocumentsListItem/component";
import { openRightColumnContainerAction } from "../../../shared/actions/RightColumnContainer/actions";
import {
    filterByStatus, filterByType, search, selectDocuments, sort,
} from "../../selectors/documents";
import { getURL } from "../../../shared/helpers/getPath";
import { filterByGroup, selectedDocumentView } from "../../../documents/selectors/documents";
import { selectActiveProject } from "../../../projects/selectors/projects";
import { documentsCRUDActions } from "../../../documents/actions/actions";
import { commentsCRUDActions } from "../../../comments/actions/actions";
import { PREVIEW_MODULES } from "../../../construction_control/base/widgets/DocumentPreviewColumn/previewModules";

import "./styles.scss";
import { getAllChildren } from "../../../categories/selectors/treeStructure";

export const DocumentsListContainer = (props) => {
    const {
        documents,
        routerPathParams,
        moveToPath,
        selectItem,
        project,
        openDetails,
        loadComments,
        currentDocumentSid,
    } = props;

    const handleSelect = ({ id }) => {
        const path = getURL(routerPathParams, ["projects", "section", "group", ["document", id]]);
        moveToPath(path);
    };

    const openDocument = (item) => {
        selectItem({ ...item, project });
        openDetails({ ...item, module: PREVIEW_MODULES.EXECUTIVE_DOCUMENTATION });
        loadComments({ source: { project, entity: item } });
    };

    useEffect(() => {
        const documentId = routerPathParams.document;
        const item = documents.filter((it) => it.id === documentId)[0];

        if (item) {
            openDocument(item);
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [routerPathParams, documents.length]);

    return (
        <div className="documents-list">
            {
                documents.map((document) => (
                    <DocumentsListItem
                        key={document.id}
                        onSelect={handleSelect}
                        document={document}
                        selected={document.id === currentDocumentSid}
                    />
                ))
            }
        </div>
    );
};

export const DocumentsList = connect((state) => {
    const selectedGroups = getAllChildren(state, "documents-list");

    const documentsByType = filterByType(selectDocuments(state), state);
    const documentsByStatus = filterByStatus(documentsByType, state);
    const documentsByGroup = filterByGroup(documentsByStatus, selectedGroups);
    const documentsBySearch = search(documentsByGroup, state);
    const documents = sort(documentsBySearch, state);

    return {
        documents,
        routerPathParams: state.core.router,
        selectedItem: selectedDocumentView(state),
        project: selectActiveProject(state),
        currentDocumentSid: state.documents.crud.selectedKey,
    };
}, {
    openDetails: documentsCRUDActions.use.ENTITY_PREVIEW,
    selectItem: documentsCRUDActions.use.SELECT_SINGLE_ENTITY,
    openRightColumn: openRightColumnContainerAction,
    moveToPath: push,
    loadComments: commentsCRUDActions.use.LIST_ENTITIES,
})(DocumentsListContainer);
