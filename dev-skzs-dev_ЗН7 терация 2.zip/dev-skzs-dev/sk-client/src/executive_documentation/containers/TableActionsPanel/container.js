import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { DatePicker } from "antd";

import { changeJournalsDate } from "../../actions/journals/actions";
import { dateFormat } from "../../../shared/constants/dateFormats";

import "./styles.scss";

export const TableActionsPanel = () => {
    const dispatch = useDispatch();
    const { journals, projects } = useSelector((state) => state.core.router);
    const [time, setTime] = useState({});

    const handleChange = (name) => (date) => {
        setTime({
            ...time,
            [name]: date,
        });
    };

    useEffect(() => {
        dispatch(changeJournalsDate({
            form: {
                start_date: (time.from && time.from.format("YYYY-MM-DD")) || null,
                end_date: (time.to && time.to.format("YYYY-MM-DD")) || null,
            },
            project: projects,
            section: journals,
        }));
    }, [dispatch, journals, projects, time]);

    return (
        <div className="table-actions-panel">
            <div className="from-text">C</div>
            <DatePicker placeholder="ДД.ММ.ГГГГ" format={dateFormat} className="from" onChange={handleChange("from")} />
            <div className="to-text">По</div>
            <DatePicker placeholder="ДД.ММ.ГГГГ" format={dateFormat} className="to" onChange={handleChange("to")} />
            <div className="actions">
                <button className="action-btn pdf">Выгрузить в PDF</button>
                <button className="action-btn xls">Выгрузить в XLS</button>
                <button className="action-btn print">
                    Версия для печати
                    <div className="print-icon" />
                </button>
            </div>
        </div>
    );
};
