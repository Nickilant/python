import React, { useState } from "react";
import { Button, Select } from "antd";

import "./styles.scss";
import { useSelector } from "react-redux";
import { getSectionsSelector } from "../../selectors/journals";
import { journalLabels } from "../../constants/journalLabels";

const { Option } = Select;

export const SelectJournalModal = (props) => {
    const { onOk } = props;
    const sections = useSelector((state) => getSectionsSelector(state));
    const [section, setSection] = useState(sections[0].sid);

    const handleChange = (e) => {
        setSection(e);
    };

    return (
        <div className="select-journal">
            <div className="selector-block">
                <div className="title">Раздел</div>
                <Select className="selector" value={section} onChange={handleChange}>
                    {
                        sections.map((opt) => (
                            <Option
                                key={opt.sid}
                                value={opt.sid}
                            >
                                {journalLabels[opt.section]}
                            </Option>
                        ))
                    }
                </Select>
            </div>
            <Button onClick={() => onOk(section)} className="move-to">Перейти к выбранному разделу</Button>
        </div>
    );
};
