import React from "react";
import { useSelector } from "react-redux";

import { canDeleteDocument, canEditDocument } from "../../../construction_control/base/selectors/permissions";

import "./styles.scss";
import { getCurrentDocument } from "../../selectors/documents";

export const PreviewBottomPanel = (props) => {
    const { remove, edit } = props;

    const document = useSelector(getCurrentDocument);

    const canEdit = useSelector((state) => canEditDocument(state, document.type));
    const canDelete = useSelector((state) => canDeleteDocument(state, document.type));

    const handleRemove = () => {
        remove();
    };

    const handleEdit = () => {
        edit();
    };

    return (
        <div className="preview-bottom-panel">
            {
                canEdit && (
                    <button onClick={handleEdit} className="edit">
                        Редактировать АКТ
                    </button>
                )
            }
            {
                canDelete && (
                    <button onClick={handleRemove} className="remove">
                        <div className="btn-icon icon-position" />
                        Удалить АКТ
                    </button>
                )
            }
        </div>
    );
};
