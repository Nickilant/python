import React from "react";

import RightColumn from "../../../core/components/RightColumn/component";
import { PreviewTopPanel } from "../PreviewTopPanel/component";
import { DocumentPreviewSwitcher } from "../../containers/DocumentPreviewSwitcher/component";
import { PreviewBottomPanel } from "../PreviewBottomPanel/component";

import "./styles.scss";

export const DocumentPreview = (props) => {
    const { document } = props;

    return (
        <div className="document-preview">
            <RightColumn
                icon={<div className="document-icon" />}
                title={document.title}
                subTitle={document.description}
                TopAction={<PreviewTopPanel />}
                Body={(
                    <DocumentPreviewSwitcher
                        document={document}
                    />
                )}
                BottomAction={<PreviewBottomPanel />}
            />
        </div>
    );
};
