import React from "react";
import { push } from "connected-react-router";
import { useDispatch, useSelector } from "react-redux";
import { getURL } from "../../../shared/helpers/getPath";

import { getCurrentDocument } from "../../selectors/documents";

import "./styles.scss";

export const PreviewTopPanel = () => {
    const dispatch = useDispatch();
    const document = useSelector((state) => getCurrentDocument(state));
    const routerProps = useSelector((state) => state.core.router);

    const print = () => {
    };

    const moveToPosition = () => {
        const path = getURL(routerProps, ["projects", ["section", "activities"], ["activity", document.group], ["activity", document.work_activity.sid]]);
        dispatch(push(path));
    };

    return (
        <div className="preview-top-panel">
            {/* <button onClick={print} className="print"> */}
            {/*    <div className="btn-icon icon-print" /> */}
            {/*    Версия для печати */}
            {/* </button> */}
            {/* <button onClick={moveToPosition} className="position"> */}
            {/*    <div className="btn-icon icon-position" /> */}
            {/*    Перейти к позиции в графике работ */}
            {/* </button> */}
        </div>
    );
};
