import moment from "moment";
import { Modal } from "antd";
import React from "react";
import { formTypes } from "../../../shared/containers/ManagementForm/formTypes";
import { dateFormat } from "../../../shared/constants/dateFormats";
import { getCurrentUser, usersArray, userWithId } from "../../../users/selectors/users";
import { companiesArray } from "../../../organizations/selectors/companies";
import { universalSubmitValueAction } from "../../../shared/actions/managementForm/actions";
import { PREVIEW_MODULES } from "../../../construction_control/base/widgets/DocumentPreviewColumn/previewModules";
import { selectActiveProject } from "../../../projects/selectors/projects";
import { selectActivityById } from "../../../activities/selectors/activities";
import { currentCategory, findNodeById } from "../../../categories/selectors/treeStructure";

const { confirm } = Modal;

export const aosrConfig = [
    {
        name: "divider",
        type: formTypes.HORIZONTAL_DIVIDER,
    },
    {
        name: "contractor_name",
        type: formTypes.INPUT,
        label: "Наименование организации, представляющей работы к освидетельствованию",
        value_source: ({ data }) => data.work_activity.contractor && data.work_activity.contractor.name,
        is_disabled: true,
    },
    {
        name: "name",
        type: formTypes.INPUT,
        label: "Наименование документа",
        default_value: ({ data, state }) => {
            const node = currentCategory(state);
            const additionalInfo = node.set_number || node.revision;
            return `${data.work_activity.number}-${additionalInfo ? `${additionalInfo}-` : ""}АОСР-${data.work_activity.details.next_aosr_number}`;
        },
        is_required: true,
    },
    {
        name: "act_date",
        type: formTypes.TEXT,
        label: "Дата составления документа",
        value_source: ({ data }) => data.act_date || moment().format(dateFormat),
    },
    {
        name: "divider",
        type: formTypes.HORIZONTAL_DIVIDER,
    },
    {
        name: "developer_representative",
        type: formTypes.SELECTOR,
        label: "Представитель застройщика",
        source: ({ config, data, state }) => {
            const project = selectActiveProject(state);
            const { developer_representative } = data;
            const user = state.users.crud.items[developer_representative];

            return {
                ...config,
                options: [...usersArray(state, project.operator)],
                help: user ? `${user.position} ${user.company.name}${user.number_of_order ? ` приказ ${user.number_of_order} от ${user.date_of_order && moment(user.date_of_order).format(dateFormat)}` : ""}` : "",
            };
        },
        is_required: true,
    },
    {
        name: "cc_contractor",
        type: formTypes.SELECTOR,
        label: "Подрядчик по строительному контролю",
        help: "Адрес",
        source: ({ config, state, data }) => {
            const companies = companiesArray(state);
            const company = state.organizations.crud.items[data.cc_contractor];
            const ogrn = company && company.ogrn ? `ОГРН ${company.ogrn} ` : "";
            const inn = company && company.inn ? `ИНН ${company.inn} ` : "";

            return {
                ...config,
                options: [
                    ...companies,
                ],
                help: company ? `${ogrn}${inn}` : "",
            };
        },
        onChangeFieldMiddleware: ({ changeOtherField }) => {
            changeOtherField("main_cc_specialist", null);
        },
        is_required: true,
    },
    {
        name: "main_cc_specialist",
        type: formTypes.SELECTOR,
        label: "Главный специалист по строительному контролю",
        source: ({ config, data, state }) => {
            const { cc_contractor, main_cc_specialist } = data;
            const user = state.users.crud.items[main_cc_specialist];

            return {
                ...config,
                is_disabled: !cc_contractor,
                options: [...usersArray(state, cc_contractor)],
                help: user ? `${user.position} ${user.company.name}${user.number_of_order ? ` приказ ${user.number_of_order} от ${user.date_of_order && moment(user.date_of_order).format(dateFormat)}` : ""}` : "",
            };
        },
        is_required: true,
    },
    {
        name: "divider",
        type: formTypes.HORIZONTAL_DIVIDER,
    },
    {
        name: "general_cc_contractor",
        type: formTypes.SELECTOR,
        label: "Генеральный подрядчик по строительству",
        onChangeFieldMiddleware: ({ changeOtherField }) => {
            changeOtherField("representative_general_contractor", null);
            changeOtherField("representative_сс", null);
        },
        source: ({ config, state, data }) => {
            const companies = companiesArray(state);
            const company = state.organizations.crud.items[data.general_cc_contractor];
            const ogrn = company && company.ogrn ? `ОГРН ${company.ogrn} ` : "";
            const inn = company && company.inn ? `ИНН ${company.inn} ` : "";

            return {
                ...config,
                options: [
                    ...companies,
                ],
                help: company ? `${ogrn}${inn}` : "",
            };
        },
        is_required: true,
    },
    {
        name: "representative_general_contractor",
        type: formTypes.SELECTOR,
        label: "Представитель генерального подрядчика, осуществляющего строительство",
        source: ({ config, data, state }) => {
            const { general_cc_contractor, representative_general_contractor } = data;
            const user = state.users.crud.items[representative_general_contractor];

            return {
                ...config,
                is_disabled: !general_cc_contractor,
                options: [...usersArray(state, general_cc_contractor)],
                help: user ? `${user.position} ${user.company.name}${user.number_of_order ? ` приказ ${user.number_of_order} от ${user.date_of_order && moment(user.date_of_order).format(dateFormat)}` : ""}` : "",
            };
        },
        is_required: true,
    },
    {
        name: "representative_сс",
        type: formTypes.SELECTOR,
        label: "Представитель лица, осуществляющего строительство, по вопросам строительного контроля",
        source: ({ config, data, state }) => {
            const { general_cc_contractor, representative_сс } = data;
            const user = state.users.crud.items[representative_сс];

            return {
                ...config,
                is_disabled: !general_cc_contractor,
                options: [...usersArray(state, general_cc_contractor)],
                help: user ? `${user.position} ${user.company.name}${user.number_of_order ? ` приказ ${user.number_of_order} от ${user.date_of_order && moment(user.date_of_order).format(dateFormat)}` : ""}` : "",
            };
        },
        is_required: true,
    },
    {
        name: "divider",
        type: formTypes.HORIZONTAL_DIVIDER,
    },
    {
        name: "pd_organization",
        type: formTypes.SELECTOR,
        label: "Организация, осуществляющая подготовку подготовку проектной документации",
        onChangeFieldMiddleware: ({ changeOtherField }) => {
            changeOtherField("documentation_preparer_representative", null);
            changeOtherField("main_project_engineer", null);
        },
        source: ({ config, state, data }) => {
            const companies = companiesArray(state);
            const company = state.organizations.crud.items[data.pd_organization];
            const ogrn = company && company.ogrn ? `ОГРН ${company.ogrn} ` : "";
            const inn = company && company.inn ? `ИНН ${company.inn} ` : "";

            return {
                ...config,
                options: [
                    ...companies,
                ],
                help: company ? `${ogrn}${inn}` : "",
            };
        },
        is_required: true,
    },
    {
        name: "documentation_preparer_representative",
        type: formTypes.SELECTOR,
        label: "Представитель лица, осуществляющего подготовку проектной документации",
        source: ({ config, data, state }) => {
            const { pd_organization, documentation_preparer_representative } = data;
            const user = state.users.crud.items[documentation_preparer_representative];

            return {
                ...config,
                is_disabled: !pd_organization,
                options: [...usersArray(state, pd_organization)],
                help: user ? `${user.position} ${user.company.name}${user.number_of_order ? ` приказ ${user.number_of_order} от ${user.date_of_order && moment(user.date_of_order).format(dateFormat)}` : ""}` : "",
            };
        },
        is_required: true,
    },
    {
        name: "divider",
        type: formTypes.HORIZONTAL_DIVIDER,
    },
    {
        name: "certification_organization",
        type: formTypes.INPUT,
        label: "Организация, выполнившая работы, подлежащие освидетельствованию",
        value_source: ({ data }) => data.work_activity.contractor && data.work_activity.contractor.name,
        is_disabled: true,
    },
    {
        name: "representative_organization_certification",
        type: formTypes.INPUT,
        label: "Представитель организации, выполнившей работы, подлежащие освидетельствованию",
        value_source: ({ state }) => getCurrentUser(state).full_name,
        is_disabled: true,
    },
    {
        name: "inspectors",
        type: formTypes.CLONER,
        cloning_limit: 8,
        source: ({ data, config }) => ({
            ...config,
            cloning_count: (data.inspectors && data.inspectors.length) || 1,
        }),
        top_panel: {
            name: "title",
            type: formTypes.TEXT,
            value_source: () => "Иные представители лиц, участвующих в освидетельствовании:",
        },
        body: [
            {
                name: "organization",
                type: formTypes.SELECTOR,
                label: "Организация иного лица, участвующего в освидетельствовании",
                value_source: ({ data, clonerIndex }) => (data.inspectors && data.inspectors[clonerIndex] ? data.inspectors[clonerIndex].organization : ""),
                source: ({ config, state }) => ({
                    ...config,
                    options: [
                        { value: "", label: "Не выбрана" },
                        ...companiesArray(state),
                    ],
                }),
            },
            {
                name: "position",
                type: formTypes.SELECTOR,
                label: "Представитель организации, участвующий в освидетельствовании",
                source: ({
                    config, state, data, clonerIndex, changeValue, type,
                }) => {
                    const organization = data.inspectors && data.inspectors[clonerIndex] && data.inspectors[clonerIndex].organization;
                    const position = data.inspectors && data.inspectors[clonerIndex] && data.inspectors[clonerIndex].position;
                    const user = userWithId(state, position);

                    if (user && user.company.sid !== organization) changeValue(type, "position", "");

                    const userHelp = () => {
                        if (user) return user.position;

                        if (organization) return "Это поле не может быть пустым.";

                        return "";
                    };

                    return {
                        ...config,
                        options: usersArray(state, organization),
                        help: userHelp(),
                        is_required: organization,
                        is_disabled: !organization,
                    };
                },
            },
        ],
        bottom_panel: {
            name: "inc",
            type: formTypes.BUTTON,
            btn_label: "Добавить представителя",
            on_click: ({ addCloningCount }) => addCloningCount(),
            source: ({ config, data, cloningNumber }) => {
                const fieldsFilled = data.inspectors && data.inspectors.every((item) => item.organization && item.position);
                const parentLength = data.inspectors && data.inspectors.length;

                return {
                    ...config,
                    is_disabled: !(fieldsFilled && parentLength === cloningNumber),
                };
            },
        },
    },
    {
        name: "divider",
        type: formTypes.HORIZONTAL_DIVIDER,
    },
    {
        name: "work_activity_contractor",
        type: formTypes.TEXT,
        value_source: ({ data, state }) => {
            const str = data.work_activity.contractor ? data.work_activity.contractor.name : selectActivityById(data.work_activity)(state).contractor.name;
            return `произвели осмотр работ, выполненных ${str} и составили настоящий акт о нижеследующем:`;
        },
    },
    {
        name: "work_activity_title",
        type: formTypes.TEXT,
        value_source: () => "К освидетельствованию представлены следующие работы:",
    },
    {
        name: "work_activity_description",
        type: formTypes.TEXT,
        value_source: ({ data }) => `${data.work_activity.title}\n${data.work_activity.accumulated} ${data.work_activity.unit}`,
    },
    {
        name: "project_documentation",
        type: formTypes.INPUT,
        label: "Работы выполнены по проектной документации",
        default_value: ({ data }) => data.work_activity.number && data.work_activity.number.replace("-ИСП-", "-"),
        is_required: true,
    },
    {
        name: "lists",
        type: formTypes.INPUT,
        label: "Листы",
    },
    {
        name: "pd_organization_clone",
        type: formTypes.SELECTOR,
        label: "Организация, осуществляющая подготовку подготовку проектной документации",
        source: ({ config, state, data }) => {
            const companies = companiesArray(state);
            const company = state.organizations.crud.items[data.pd_organization];
            const ogrn = company && company.ogrn ? `ОГРН ${company.ogrn} ` : "";
            const inn = company && company.inn ? `ИНН ${company.inn} ` : "";

            return {
                ...config,
                options: [
                    ...companies,
                ],
                help: company ? `${ogrn}${inn}` : "",
            };
        },
        value_source: ({ data }) => data.pd_organization,
        is_disabled: true,
    },
    {
        name: "main_project_engineer",
        type: formTypes.SELECTOR,
        label: "Главный инженер проекта",
        source: ({ config, state, data }) => {
            const { pd_organization, main_project_engineer } = data;
            const user = state.users.crud.items[main_project_engineer];

            return {
                ...config,
                is_disabled: !pd_organization,
                options: [...usersArray(state, pd_organization)],
                help: user ? `${user.position} ${user.company.name}${user.number_of_order ? ` приказ ${user.number_of_order} от ${user.date_of_order && moment(user.date_of_order).format(dateFormat)}` : ""}` : "",
            };
        },
        is_required: true,
    },
    {
        name: "applied_at_execution",
        type: formTypes.INPUT,
        label: "При выполнении работ применены",
    },
    {
        name: "correspondence_documents",
        type: formTypes.INPUT,
        label: "Предъявлены документы, подтверждающие соответствие работ предъявляемым к ним требованиям",
    },
    {
        name: "divider",
        type: formTypes.HORIZONTAL_DIVIDER,
    },
    {
        name: "work_start_date",
        type: formTypes.DATE_INPUT,
        format: dateFormat,
        label: "Дата начала работы",
        dateFormat,
        onChangeFieldMiddleware: ({ changeOtherField, data, value }) => {
            const work_end_date = moment(data.work_end_date);

            if (!(work_end_date.isBetween(moment(value), moment().startOf("day"), "day", "[]"))) {
                changeOtherField("work_end_date", value);
            }
        },
        disabled_date: ({ date: curDate }) => curDate.isAfter(moment().startOf("day")),
        default_value: ({ data }) => data.work_start_date || moment().startOf("day").subtract(1, "day"),
        is_required: true,
    },
    {
        name: "work_end_date",
        type: formTypes.DATE_INPUT,
        format: dateFormat,
        label: "Дата окончания работы",
        dateFormat,
        disabled_date: ({ date: curDate, data }) => !(curDate.isBetween(data.work_start_date || moment().startOf("day").subtract(1, "day"), moment().startOf("day"), "day", "[]")),
        default_value: ({ data }) => data.work_end_date || moment().startOf("day"),
        is_required: true,
    },
    {
        name: "work_accordance",
        type: formTypes.INPUT,
        label: "Работы выполнены в соответствии с (НТД)",
    },
    {
        name: "work_permitted",
        type: formTypes.INPUT,
        label: "Разрешается производство последующих работ",
    },
    {
        name: "additional_info",
        type: formTypes.INPUT,
        label: "Дополнительные сведения",
    },
    {
        name: "applications",
        type: formTypes.INPUT,
        label: "Приложения",
    },
    {
        name: "submit",
        type: formTypes.BUTTON,
        on_click: ({
            state, data, isEdited, isValidated, changedFields, dispatch,
        }) => {
            confirm({
                className: "section-executive-documentation-confirm-modal",
                title: "Создать АОСР?",
                content: (
                    <div className="caution">
                        <div className="caution-inner">
                            После заполнения данных в форме акта их нельзя будет отредактировать
                        </div>
                    </div>
                ),
                okText: "Создать",
                cancelText: "Вернуться назад",
                onOk() {
                    dispatch(universalSubmitValueAction("documents", "document", {
                        isEdited,
                        isValidated,
                        changedFields,
                        data: {
                            ...data,
                            project: selectActiveProject(state),
                        },
                        module: PREVIEW_MODULES.EXECUTIVE_DOCUMENTATION,
                    }));
                },
            });
        },
        source: ({ config, isEdited, changedFields }) => ({
            ...config,
            is_disabled: Object.keys(changedFields).length === 0,
            btn_label: isEdited
                ? "Сохранить изменения"
                : "Создать акт",
        }),
    },
];
