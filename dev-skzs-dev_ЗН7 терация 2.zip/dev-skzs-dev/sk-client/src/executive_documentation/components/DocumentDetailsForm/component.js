import React from "react";
import { Form } from "antd";

import { ManagementForm } from "../../../shared/containers/ManagementForm/container";
import { formConfig } from "./form_config";

import "./styles.scss";

export const DocumentDetailsForm = () => (
    <div className="prescription-details-form">
        <Form
            className="details-form"
        >
            <ManagementForm
                formConfig={formConfig}
                reducer="documentForm"
                moduleAction="DOCUMENTS"
                module="documents"
            >
                {
                    () => (
                        <div className="details-form-header">
                            <div className="title">
                                ООО "ПромСтройКонтроль"
                            </div>
                            <div className="sub-title">
                                Контактная информация
                            </div>
                        </div>
                    )
                }
            </ManagementForm>
        </Form>
    </div>
);
