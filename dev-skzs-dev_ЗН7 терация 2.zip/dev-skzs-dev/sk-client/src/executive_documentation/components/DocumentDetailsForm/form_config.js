import { formTypes } from "../../../shared/containers/ManagementForm/formTypes";
import { DOCUMENT_TYPES } from "../../constants/document_types";
import { aosrConfig } from "./aosr_config";
import { selectActiveProject } from "../../../projects/selectors/projects";

export const genMoreCompanyInfo = (company) => {
    const ogrn = company.ogrn ? `ОГРН ${company.ogrn} ` : "";
    const inn = company.inn ? `ИНН ${company.inn} ` : "";
    const phone = company.phone_number ? ` тел. ${company.phone_number}` : "";

    return `${company.full_name} ${ogrn}${inn}${company.legal_address || ""}${phone}`;
};

export const formConfig = [
    {
        name: "object_name",
        type: formTypes.TEXT,
        label: "Объект капитального строительства",
        value_source: ({ data, state }) => data.object_name || selectActiveProject(state).name,
    },
    // {
    //     name: "developer",
    //     type: formTypes.TEXT,
    //     label: "Застройщик",
    //     value_source: ({ state, data }) => {
    //         const company = state.organizations.crud.items[data.developer || selectActiveProject(state).operator];
    //         return genMoreCompanyInfo(company);
    //     },
    // },
    // {
    //     name: "development_executor",
    //     type: formTypes.TEXT,
    //     label: "Лицо, осуществляющее строительство",
    //     value_source: ({ state, data }) => {
    //         const company = state.organizations.crud.items[data.development_executor || selectActiveProject(state).contractor_of_construction];
    //         return genMoreCompanyInfo(company);
    //     },
    // },
    // {
    //     name: "documentation_preparer",
    //     type: formTypes.TEXT,
    //     label: "Лицо, осуществляющее подготовку проектной документации",
    //     value_source: ({ state, data }) => {
    //         const company = state.organizations.crud.items[data.documentation_preparer || selectActiveProject(state).contractor_of_design];
    //         return genMoreCompanyInfo(company);
    //     },
    // },
    {
        name: "type",
        type: formTypes.SELECTOR,
        source: ({ config }) => ({
            ...config,
            options: [
                { label: "АОСР", value: DOCUMENT_TYPES.AOSR },
            ],
        }),
        label: "Тип документа",
    },
    {
        name: "type_switch",
        type: formTypes.SWITCH,
        switchMap: (data) => (data.type ? ({
            aosr: {
                type: formTypes.FORM,
                formConfig: aosrConfig,
                reducer: "documentForm",
                module: "documents",
                moduleAction: "DOCUMENTS",
            },
        }[data.type]) : {
            name: "none",
            type: formTypes.DIVIDER,
        }),
    },
];
