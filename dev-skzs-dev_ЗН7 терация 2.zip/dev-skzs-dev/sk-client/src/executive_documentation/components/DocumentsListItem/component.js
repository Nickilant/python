import React from "react";
import cx from "classnames";

import "./styles.scss";

export const DocumentsListItem = (props) => {
    const { document, onSelect, selected } = props;

    const {
        title,
        status,
        company,
        description,
        subscriptionDate,
        geotagsCount = null,
        commentsCount = null,
        filesCount = null,
    } = document;

    const handleClick = () => {
        onSelect(document);
    };

    return (
        <div onClick={handleClick} className={cx("documents-list-item", `status-${status}`, { selected })}>
            <div className="icon-document" />
            <div className="info">
                <div className="title">
                    {title}
                </div>
                <div className="sub-title">
                    {company}
                </div>
                <div className="desc">
                    {description}
                </div>
            </div>
            {
                subscriptionDate && (
                    <div className="subscription-date">
                        дата подписания акта
                        <div className="date">{subscriptionDate}</div>
                    </div>
                )
            }
            <div className="info-icons">
                {geotagsCount !== null
                && <div className="icon bg-img geotag"><span className="counter">{geotagsCount}</span></div>}
                {commentsCount !== null
                && <div className="icon bg-img comments"><span className="counter">{commentsCount}</span></div>}
                {filesCount !== null
                && <div className="icon bg-img files"><span className="counter">{filesCount}</span></div>}
            </div>
        </div>
    );
};
