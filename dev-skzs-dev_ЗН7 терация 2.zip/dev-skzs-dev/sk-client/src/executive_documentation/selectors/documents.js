import { filterBy, searchBy, sortBy } from "../../shared/helpers/filterHelpers";

const excludedTypes = ["file", "map", "remark", "prescription", "act"];

export const getCurrentDocument = (state) => {
    const key = state.documents.crud.selectedKey;
    return state.documents.crud.items[key];
};

export const selectDocuments = (state) => Object.values(state.documents.crud.items).filter((it) => !excludedTypes.includes(it.type));

export const search = (documents, state) => searchBy(documents, state.executiveDocumentation.listAttributes.searchQuery, "title");

export const filterByStatus = (documents, state) => filterBy(documents, state.executiveDocumentation.listAttributes.statusFilters, "status");

export const filterByType = (documents, state) => filterBy(documents, state.executiveDocumentation.listAttributes.typeFilters, "type");

export const sort = (documents, state) => {
    const params = state.executiveDocumentation.listAttributes.attribute;
    const dict = {
        CONFIRMED: 1,
        PARTIAL_CONFIRMED: 2,
        NOT_CONFIRMED: 3,
    };

    return sortBy(documents, params, dict);
};
