export const getSectionsSelector = (state) => state.executiveDocumentation.journals.sections;

export const getSection = (state, sid) => state.executiveDocumentation.journals.sections.find((it) => it.sid === sid);

export const sortJournalRowsByNumber = (state) => {
    const journal = state.executiveDocumentation.journals.journal.slice();
    return journal.sort((a, b) => a.number - b.number);
};
