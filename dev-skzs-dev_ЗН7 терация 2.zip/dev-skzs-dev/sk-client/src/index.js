import React from "react";
import ReactDOM from "react-dom";
import { Provider } from "react-redux";
import { Route } from "react-router-dom";
import { ConnectedRouter } from "connected-react-router";
import { message } from "antd";
import App from "./core/App";
import * as serviceWorker from "./serviceWorker";
import rootStore, { connectedHistory } from "./core/store";

import "./index.scss";

ReactDOM.render(
    <Provider store={rootStore}>
        <ConnectedRouter history={connectedHistory}>
            <Route path="/" component={App} />
        </ConnectedRouter>
    </Provider>,
    document.getElementById("root"),
);

serviceWorker.register({
    onUpdate: (registration) => {
        message.info("Приложение обновлено! Изменения вступят в силу через 5 секунд...", 5, () => {
            if (registration && registration.waiting) {
                registration.waiting.postMessage({ type: "SKIP_WAITING" });
            }
            window.location.reload();
        });
    },
});
