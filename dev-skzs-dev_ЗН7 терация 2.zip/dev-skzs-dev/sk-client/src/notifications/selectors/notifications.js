export const selectNotifications = (state) => Object.values(state.notifications.crud.items).sort((it) => it.creation_date);
export const selectDropdownState = (state) => state.notifications.notifications.isDropdownOpen;
export const isNotificationsLoaded = (state) => state.notifications.notifications.isLoaded;
