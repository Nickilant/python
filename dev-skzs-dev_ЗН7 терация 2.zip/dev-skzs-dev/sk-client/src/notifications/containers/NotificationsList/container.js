import React from "react";
import { connect } from "react-redux";

import { NotificationsListHeaderComponent } from "../../widgets/NotificationsListHeader/component";

import "./styles.scss";
import { selectNotifications } from "../../selectors/notifications";

export const NotificationsListContainer = (props) => {
    const { headerNotifications } = props;
    return (
        <NotificationsListHeaderComponent notifications={headerNotifications} />
    );
};

const mapStateToProps = (state) => ({
    headerNotifications: selectNotifications(state),
});

export const NotificationsList = connect(mapStateToProps, {})(NotificationsListContainer);
