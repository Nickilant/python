export const notifications = [
    {
        type: "responsible",
        name: "Вася",
        prescription_name: "Предписание 1",
        prescription_date: 1569599900,
        term: 1569599900,
    },
    {
        type: "remove_from_project",
        project_name: "Проект 1",
    },
    {
        type: "responsible",
        name: "Вася",
        prescription_name: "Предписание 1",
        prescription_date: 1569599900,
        term: 1569599900,
    },
];
