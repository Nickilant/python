import React from "react";

import "./styles.scss";
import { useSelector } from "react-redux";
import { notificationComponents } from "./notificationComponents";
import { isNotificationsLoaded } from "../../selectors/notifications";

export const NotificationsListHeaderComponent = (props) => {
    const { notifications } = props;
    const isLoaded = useSelector(isNotificationsLoaded);

    return (
        notifications.length ? (
            <div className="notifications-block-main">
                {
                    notifications.map((notification) => (
                        <div
                            className="header-notification"
                            key={notification.sid}
                        >
                            {notificationComponents[notification.type].component({ ...notification.body, document_id: notification.body.sid, sid: notification.sid })}
                        </div>
                    ))
                }
            </div>
        )
            : isLoaded
                ? (
                    <div className="notifications-block-main loader">
                        Новых уведомлений нет
                    </div>
                )
                : (
                    <div className="notifications-block-main loader">
                        Загрузка уведомлений...
                    </div>
                )
    );
};
