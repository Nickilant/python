import React from "react";
import moment from "moment";

import { UniversalNotification } from "../UniversalNotification/component";
import { dotTypes } from "../UniversalNotification/dotTypes";
import { borderTypes } from "../UniversalNotification/borderTypes";
import { getDaysTitle } from "../../../shared/helpers/getDaysTitle";

import responsibleIcon from "./assets/responsible.svg";
import removeUserIcon from "./assets/remove_user.svg";
import addUserIcon from "./assets/add_user.svg";
import setUserPositionIcon from "./assets/set_user_position.svg";
import predictionIcon from "./assets/prediction.svg";
import returnedIcon from "./assets/returned.svg";
import addCommentIcon from "./assets/add_comment.svg";
import addFileIcon from "./assets/add_file.svg";
import addGeotagIcon from "./assets/add_geotag.svg";
import delayedIcon from "./assets/delayed.svg";
import checkedIcon from "./assets/checked.svg";
import createActIcon from "./assets/create_act.svg";
import { NOTIFICATION_TYPES } from "../../constants/types";

export const notificationComponents = {
    [NOTIFICATION_TYPES.USER.RESPONSIBLE]: {
        type: NOTIFICATION_TYPES.USER.RESPONSIBLE,
        component: ({
            sid, document_id, name, prescription_name, prescription_date, term,
        }) => {
            // const own = name === "current_user";
            const own = true;

            return (
                <UniversalNotification
                    sid={sid}
                    document_id={document_id}
                    dot={dotTypes.USUAL}
                    border={borderTypes.IMPORTANT}
                    icon={responsibleIcon}
                    body={(
                        <>
                            <div className="notification-text-bold">
                                {own ? "вы " : `${name} `}
                            </div>
                            {own
                                ? "назначены ответственным за "
                                : "был назначен ответственным за "}
                            <div className="notification-text-bold">
                                {`${prescription_name} `}
                            </div>
                            от
                            <div className="notification-text-bold">
                                {` ${moment(prescription_date).format("DD.MM.YYYY")}`}
                            </div>
                        </>
                    )}
                    footer={(
                        <>
                            Срок исполнения:
                            <div className="notification-text-bold">
                                {`${term} ${getDaysTitle(term)}`}
                            </div>
                        </>
                    )}
                />
            );
        },
    },
    [NOTIFICATION_TYPES.USER.COMPANY_RESPONSIBLE]: {
        type: NOTIFICATION_TYPES.USER.COMPANY_RESPONSIBLE,
        component: ({
            sid, document_id, document_name, document_date, term,
        }) => (
            <UniversalNotification
                sid={sid}
                document_id={document_id}
                dot={dotTypes.USUAL}
                border={borderTypes.IMPORTANT}
                icon={responsibleIcon}
                body={(
                    <>
                        <div className="notification-text-bold">
                            Вы были упомянуты в связи с составлением нового документа
                            {" "}
                            {`"${document_name}" `}
                        </div>
                        от
                        <div className="notification-text-bold">
                            {` ${moment(document_date).format("DD.MM.YYYY")}`}
                        </div>
                    </>
                )}
                footer={(
                    <>
                        Срок исполнения:
                        <div className="notification-text-bold">
                            {`${term} ${getDaysTitle(term)}`}
                        </div>
                    </>
                )}
            />
        ),
    },
    [NOTIFICATION_TYPES.USER.REMOVE_FROM_PROJECT]: {
        type: NOTIFICATION_TYPES.USER.REMOVE_FROM_PROJECT,
        component: ({ sid, document_id, project_name }) => (
            <UniversalNotification
                sid={sid}
                document_id={document_id}
                dot={dotTypes.INACTIVE}
                icon={removeUserIcon}
                body={(
                    <>
                        <div className="notification-text-bold">
                            Вы были удалены
                            {" "}
                        </div>
                        из проекта
                        {" "}
                        <div className="notification-text-bold">
                            {`${project_name}`}
                        </div>
                    </>
                )}
            />
        ),
    },
    [NOTIFICATION_TYPES.USER.ADD_TO_PROJECT]: {
        type: NOTIFICATION_TYPES.USER.ADD_TO_PROJECT,
        component: ({ sid, document_id, project_name }) => (
            <UniversalNotification
                sid={sid}
                document_id={document_id}
                dot={dotTypes.IMPORTANT_LIGHT}
                icon={addUserIcon}
                body={(
                    <>
                        <div className="notification-text-bold">
                            Вы были добавлены
                            {" "}
                        </div>
                        в проект
                        {" "}
                        <div className="notification-text-bold">
                            {`${project_name}`}
                        </div>
                    </>
                )}
            />
        ),
    },
    [NOTIFICATION_TYPES.USER.SET_POSITION_IN_PROJECT]: {
        type: NOTIFICATION_TYPES.USER.SET_POSITION_IN_PROJECT,
        component: ({
            sid, document_id, project_name, position,
        }) => (
            <UniversalNotification
                sid={sid}
                document_id={document_id}
                dot={dotTypes.INACTIVE}
                icon={setUserPositionIcon}
                body={(
                    <>
                        <div className="notification-text-bold">
                            Вы были назначены
                            {" "}
                        </div>
                        на должность
                        {" "}
                        <div className="notification-text-bold">
                            {`${position} `}
                        </div>
                        на проекте
                        {" "}
                        <div className="notification-text-bold">
                            {`${project_name}`}
                        </div>
                    </>
                )}
            />
        ),
    },
    [NOTIFICATION_TYPES.USER.RESET_PASSWORD_REQUEST]: {
        type: NOTIFICATION_TYPES.USER.RESET_PASSWORD_REQUEST,
        component: ({
            sid, document_id, user_full_name, user_email,
        }) => (
            <UniversalNotification
                sid={sid}
                document_id={document_id}
                dot={dotTypes.INACTIVE}
                icon={setUserPositionIcon}
                body={(
                    <>
                        <div className="notification-text-bold">
                            {user_full_name}
                        </div>
                        {" "}
                        с почтовым адресом
                        {" "}
                        <div className="notification-text-bold">
                            {`${user_email} `}
                        </div>
                        запросил восстановление пароля
                        {" "}
                    </>
                )}
            />
        ),
    },
    [NOTIFICATION_TYPES.DOCUMENT.EXPIRED]: {
        type: NOTIFICATION_TYPES.EXPIRED,
        component: ({
            sid, document_id, prescription_name, prescription_date, term,
        }) => (
            <UniversalNotification
                sid={sid}
                document_id={document_id}
                dot={dotTypes.IMPORTANT}
                border={borderTypes.IMPORTANT}
                icon={predictionIcon}
                body={(
                    <>
                        <div className="notification-text-bold">
                            {`${prescription_name} `}
                        </div>
                        от
                        <div className="notification-text-bold">
                            {` ${moment(prescription_date).format("DD.MM.YYYY")}`}
                        </div>
                    </>
                )}
                footer={(
                    <>
                        Срок исполнения:
                        {" "}
                        <div className="notification-text-bold notification-text-red">
                            просрочено на
                            {" "}
                            {`${term} ${getDaysTitle(term)}`}
                        </div>
                    </>
                )}
            />
        ),
    },
    [NOTIFICATION_TYPES.DOCUMENT.EXPIRES]: {
        type: NOTIFICATION_TYPES.DOCUMENT.EXPIRES,
        component: ({
            sid, document_id, prescription_name, prescription_date, term,
        }) => (
            <UniversalNotification
                sid={sid}
                document_id={document_id}
                dot={dotTypes.IMPORTANT}
                border={borderTypes.IMPORTANT}
                icon={predictionIcon}
                body={(
                    <>
                        <div className="notification-text-bold">
                            {`${prescription_name} `}
                        </div>
                        от
                        <div className="notification-text-bold">
                            {` ${moment(prescription_date).format("DD.MM.YYYY")}`}
                        </div>
                    </>
                )}
                footer={(
                    <>
                        <div className="notification-text-bold notification-text-red">
                            Срок исполнения истекает через
                            {" "}
                            {`${term} ${getDaysTitle(term)}`}
                        </div>
                    </>
                )}
            />
        ),
    },
    [NOTIFICATION_TYPES.DOCUMENT.RETURNED]: {
        type: NOTIFICATION_TYPES.DOCUMENT.RETURNED,
        component: ({
            sid, document_id, prescription_name, prescription_date, term,
        }) => (
            <UniversalNotification
                sid={sid}
                document_id={document_id}
                border={borderTypes.IMPORTANT}
                dot={dotTypes.USUAL}
                icon={returnedIcon}
                body={(
                    <>
                        <div className="notification-text-bold">
                            {`${prescription_name} `}
                        </div>
                        от
                        <div className="notification-text-bold">
                            {` ${moment(prescription_date).format("DD.MM.YYYY")} возвращено `}
                        </div>
                        на доработку
                    </>
                )}
                footer={(
                    <>
                        Срок исполнения:
                        <div className="notification-text-bold">
                            {`${term} ${getDaysTitle(term)}`}
                        </div>
                    </>
                )}
            />
        ),
    },
    [NOTIFICATION_TYPES.COMMENTS.ADD_NEW_COMMENT]: {
        type: NOTIFICATION_TYPES.COMMENTS.ADD_NEW_COMMENT,
        component: ({
            sid, document_id, prescription_name, prescription_date, term,
        }) => (
            <UniversalNotification
                sid={sid}
                document_id={document_id}
                border={borderTypes.IMPORTANT}
                dot={dotTypes.USUAL}
                icon={addCommentIcon}
                body={(
                    <>
                        К
                        <div className="notification-text-bold">
                            {` ${prescription_name} `}
                        </div>
                        от
                        <div className="notification-text-bold">
                            {` ${moment(prescription_date).format("DD.MM.YYYY")} `}
                        </div>
                        добавлен
                        <div className="notification-text-bold">
                            новый комментарий
                        </div>
                    </>
                )}
                footer={(
                    <>
                        Срок исполнения:
                        <div className="notification-text-bold">
                            {`${term} ${getDaysTitle(term)}`}
                        </div>
                    </>
                )}
            />
        ),
    },
    [NOTIFICATION_TYPES.COMMENTS.ADD_NEW_COMMENTS]: {
        type: NOTIFICATION_TYPES.COMMENTS.ADD_NEW_COMMENTS,
        component: ({
            sid, document_id, prescription_name, prescription_date, term, commentsCount,
        }) => (
            <UniversalNotification
                sid={sid}
                document_id={document_id}
                border={borderTypes.IMPORTANT}
                dot={dotTypes.USUAL}
                icon={addCommentIcon}
                body={(
                    <>
                        К
                        <div className="notification-text-bold">
                            {` ${prescription_name} `}
                        </div>
                        от
                        <div className="notification-text-bold">
                            {` ${moment(prescription_date).format("DD.MM.YYYY")} `}
                        </div>
                        добавлено
                        <div className="notification-text-bold notification-text-active notification-text-dotted">
                            {` ${commentsCount} новых комментариев`}
                        </div>
                    </>
                )}
                footer={(
                    <>
                        Срок исполнения:
                        <div className="notification-text-bold">
                            {`${term} ${getDaysTitle(term)}`}
                        </div>
                    </>
                )}
            />
        ),
    },
    [NOTIFICATION_TYPES.ATTACHMENTS.ADD_NEW_FILE]: {
        type: NOTIFICATION_TYPES.ATTACHMENTS.ADD_NEW_FILE,
        component: ({
            sid, document_id, prescription_name, prescription_date, term, fileName,
        }) => (
            <UniversalNotification
                sid={sid}
                document_id={document_id}
                border={borderTypes.IMPORTANT}
                dot={dotTypes.USUAL}
                icon={addFileIcon}
                body={(
                    <>
                        К
                        <div className="notification-text-bold">
                            {` ${prescription_name} `}
                        </div>
                        от
                        <div className="notification-text-bold">
                            {` ${moment(prescription_date).format("DD.MM.YYYY")} `}
                        </div>
                        добавлен файл
                        <div className="notification-text-bold">
                            {` ${fileName}`}
                        </div>
                    </>
                )}
                footer={(
                    <>
                        Срок исполнения:
                        <div className="notification-text-bold">
                            {`${term} ${getDaysTitle(term)}`}
                        </div>
                    </>
                )}
            />
        ),
    },
    [NOTIFICATION_TYPES.ATTACHMENTS.ADD_NEW_GEOTAG]: {
        type: NOTIFICATION_TYPES.ATTACHMENTS.ADD_NEW_GEOTAG,
        component: ({
            sid, document_id, prescription_name, prescription_date, term, geotagName,
        }) => (
            <UniversalNotification
                sid={sid}
                document_id={document_id}
                border={borderTypes.IMPORTANT}
                dot={dotTypes.USUAL}
                icon={addGeotagIcon}
                body={(
                    <>
                        К
                        <div className="notification-text-bold">
                            {` ${prescription_name} `}
                        </div>
                        от
                        <div className="notification-text-bold">
                            {` ${moment(prescription_date).format("DD.MM.YYYY")} `}
                        </div>
                        добавлена геометка
                        <div className="notification-text-bold">
                            {` ${geotagName}`}
                        </div>
                    </>
                )}
                footer={(
                    <>
                        Срок исполнения:
                        <div className="notification-text-bold">
                            {`${term} ${getDaysTitle(term)}`}
                        </div>
                    </>
                )}
            />
        ),
    },
    [NOTIFICATION_TYPES.DOCUMENT.POSTPONED]: {
        type: NOTIFICATION_TYPES.DOCUMENT.POSTPONED,
        component: ({
            sid, document_id, prescription_name, prescription_date, term, delayedTerm,
        }) => (
            <UniversalNotification
                sid={sid}
                document_id={document_id}
                border={borderTypes.INACTIVE}
                dot={dotTypes.USUAL}
                icon={delayedIcon}
                body={(
                    <>
                        <div className="notification-text-bold">
                            {`${prescription_name} `}
                        </div>
                        от
                        <div className="notification-text-bold">
                            {` ${moment(prescription_date).format("DD.MM.YYYY")} перенесено `}
                        </div>
                        на
                        <div className="notification-text-bold">
                            {`${delayedTerm} ${getDaysTitle(delayedTerm)}`}
                        </div>
                    </>
                )}
                footer={(
                    <>
                        Срок исполнения:
                        <div className="notification-text-bold">
                            {`${term} ${getDaysTitle(term)}`}
                        </div>
                    </>
                )}
            />
        ),
    },
    [NOTIFICATION_TYPES.DOCUMENT.RESOLVED]: {
        type: NOTIFICATION_TYPES.DOCUMENT.RESOLVED,
        component: ({
            sid, document_id, prescription_name, document_date, term,
        }) => (
            <UniversalNotification
                sid={sid}
                document_id={document_id}
                border={borderTypes.WARNING}
                dot={dotTypes.USUAL}
                icon={createActIcon}
                body={(
                    <>
                        <div className="notification-text-bold">
                            {`${prescription_name} `}
                        </div>
                        от
                        <div className="notification-text-bold">
                            {` ${moment(document_date).format("DD.MM.YYYY")} выполнено `}
                        </div>
                    </>
                )}
                footer={(
                    <>
                        Дата сдачи:
                        <div className="notification-text-bold">
                            {` ${moment(term).format("DD.MM.YYYY")}`}
                        </div>
                    </>
                )}
            />
        ),
    },
    [NOTIFICATION_TYPES.DOCUMENT.CHECKED]: {
        type: NOTIFICATION_TYPES.DOCUMENT.CHECKED,
        component: ({
            sid, document_id, prescription_name, prescription_date, term,
        }) => (
            <UniversalNotification
                sid={sid}
                document_id={document_id}
                border={borderTypes.SUCCESS}
                dot={dotTypes.USUAL}
                icon={checkedIcon}
                body={(
                    <>
                        <div className="notification-text-bold">
                            {`${prescription_name} `}
                        </div>
                        от
                        <div className="notification-text-bold">
                            {` ${moment(prescription_date).format("DD.MM.YYYY")} проверено `}
                        </div>
                        и
                        {" "}
                        <div className="notification-text-bold">
                            закрыто как исполненное
                        </div>
                    </>
                )}
                footer={(
                    <>
                        Дата сдачи:
                        <div className="notification-text-bold">
                            {` ${moment(term).format("DD.MM.YYYY")}`}
                        </div>
                    </>
                )}
            />
        ),
    },
    [NOTIFICATION_TYPES.DOCUMENT.CREATE_ACT]: {
        type: NOTIFICATION_TYPES.DOCUMENT.CREATE_ACT,
        component: ({
            sid, document_id, prescription_name, prescription_date, term, act_name, act_date,
        }) => (
            <UniversalNotification
                sid={sid}
                document_id={document_id}
                border={borderTypes.WARNING}
                dot={dotTypes.USUAL}
                icon={createActIcon}
                body={(
                    <>
                        К
                        <div className="notification-text-bold">
                            {` ${prescription_name} `}
                        </div>
                        от
                        <div className="notification-text-bold">
                            {` ${moment(prescription_date).format("DD.MM.YYYY")} `}
                        </div>
                        создан акт-уведомление
                        <div className="notification-text-bold">
                            {` ${act_name} `}
                        </div>
                        <div className="notification-text-bold">
                            {` от ${moment(act_date).format("DD.MM.YYYY")}`}
                        </div>
                    </>
                )}
                footer={(
                    <>
                        Дата сдачи:
                        <div className="notification-text-bold">
                            {` ${moment(term).format("DD.MM.YYYY")}`}
                        </div>
                    </>
                )}
            />
        ),
    },
};
