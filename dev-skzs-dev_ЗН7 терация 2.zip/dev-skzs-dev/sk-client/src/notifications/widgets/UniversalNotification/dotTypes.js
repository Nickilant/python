export const dotTypes = {
    USUAL: "usual",
    INACTIVE: "inactive",
    IMPORTANT: "important",
    IMPORTANT_LIGHT: "important-light",
};
