export const borderTypes = {
    IMPORTANT: "important",
    INACTIVE: "inactive",
    SUCCESS: "success",
    WARNING: "warning",
};
