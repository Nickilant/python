import React from "react";

import "./styles.scss";
import { useDispatch, useSelector } from "react-redux";
import { push } from "connected-react-router";
import { NotificationDropdown } from "../../components/NotificationDropdown/component";
import { notificationsCRUDActions, toggleNotificationsDropdown } from "../../actions/notifications/actions";
import { getURL } from "../../../shared/helpers/getPath";
import { dotTypes } from "./dotTypes";

export const UniversalNotification = (props) => {
    const {
        border, icon, body, footer, document_id, sid,
    } = props;

    const dispatch = useDispatch();
    const notification = useSelector((state) => state.notifications.crud.items[sid]);

    const indicator = notification.acknowledged ? dotTypes.INACTIVE : dotTypes.USUAL;

    const routerPathParams = useSelector((state) => state.core.router);

    const document = useSelector((state) => state.documents.crud.items[document_id]);

    const handleHide = () => {
        dispatch(notificationsCRUDActions.use.UPDATE_ENTITY({
            source: notification,
            form: {
                hidden: true,
            },
        }));
    };

    const handleMarkAsUnread = () => {
        dispatch(notificationsCRUDActions.use.UPDATE_ENTITY({
            source: notification,
            form: {
                acknowledged: false,
            },
        }));
    };

    const markAsRead = () => {
        dispatch(notificationsCRUDActions.use.UPDATE_ENTITY({
            source: notification,
            form: {
                acknowledged: true,
            },
        }));
    };

    const handleOpenDocument = () => {
        if (!document) {
            return null;
        }
        const { id } = document;
        const section = "construction-control";
        const { group } = document;

        const path = getURL(routerPathParams, ["projects", ["section", section], ["group", group], ["document", id]]);
        dispatch(push(path));
        dispatch(toggleNotificationsDropdown(false));
        markAsRead();
    };

    return (
        <div className="notification">
            <div className={`border border-${border}`} />
            <div className={`dot dot-${indicator}`} />
            <div className="notification-main">
                <img className="notification-icon" src={icon} alt="Оповещение" />
                <div className="desc">
                    <div className="notification-body" onClick={handleOpenDocument}>
                        {body}
                    </div>
                    <div className="notification-footer">
                        {footer}
                    </div>
                </div>
                <NotificationDropdown
                    onHide={handleHide}
                    onMarkAsUnread={handleMarkAsUnread}
                />
            </div>
        </div>
    );
};
