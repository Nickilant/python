import { combineReducers } from "redux";
import { crudReducerFactory } from "../../shared/reducers/crudFactory";
import { TOGGLE_NOTIFICATIONS_DROPDOWN } from "../actions/notifications/actionTypes";
import { notificationsCRUDActions } from "../actions/notifications/actions";

const initialState = {
    isDropdownOpen: false,
    isLoaded: false,
};

export const notificationsReducer = combineReducers({
    crud: crudReducerFactory("notifications", "notification", "sid"),
    notifications: (state = initialState, action) => {
        switch (action.type) {
            case TOGGLE_NOTIFICATIONS_DROPDOWN: {
                return {
                    ...state,
                    isDropdownOpen: action.payload,
                };
            }
            case notificationsCRUDActions.LIST_ENTITIES_COMPLETE: {
                return {
                    ...state,
                    isLoaded: true,
                };
            }
            default: {
                return state;
            }
        }
    },
});
