export const NOTIFICATION_TYPES = {
    USER: {
        RESPONSIBLE: "responsible", // назначен ответственным за предписание
        COMPANY_RESPONSIBLE: "company_responsible", // назначен ответственным за замечание
        REMOVE_FROM_PROJECT: "remove_from_project", // вы удалены из проекта
        ADD_TO_PROJECT: "add_to_project", // вы добавлены в проект
        SET_POSITION_IN_PROJECT: "set_position_in_project", // вы назначены на новую должность в проекте
        RESET_PASSWORD_REQUEST: "user_reset_password_request", // запрос на изменение пароля
    },
    DOCUMENT: {
        EXPIRED: "expired", // предписание просрочено на
        EXPIRES: "expires", // срок исполнения истекает
        RETURNED: "returned", // возвращено на доработку
        POSTPONED: "postponed", // предписание перенесено
        RESOLVED: "resolved", // предписание/замечание выполнено
        CHECKED: "checked", // предписание закрыто
        CREATE_ACT: "create_act", // создан акт
    },
    COMMENTS: {
        ADD_NEW_COMMENT: "add_new_comment", // добавлен новый комментарий
        ADD_NEW_COMMENTS: "add_new_comments", // добавлены новые комментарии
    },
    ATTACHMENTS: {
        ADD_NEW_FILE: "add_new_file", // добавлен новый файл
        ADD_NEW_GEOTAG: "add_new_geotag", // добавлена новая геометка
    },
};
