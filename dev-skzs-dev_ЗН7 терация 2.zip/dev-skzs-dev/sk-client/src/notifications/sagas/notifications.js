import {
    all, delay, put, takeEvery,
} from "redux-saga/effects";
import { select } from "@redux-saga/core/effects";
import { createCRUDSaga } from "../../shared/sagas/entityCrudFactory";
import { notificationsCRUDActions } from "../actions/notifications/actions";
import { documentsCRUDActions } from "../../documents/actions/actions";
import { selectNotifications } from "../selectors/notifications";
import { selectActiveProject } from "../../projects/selectors/projects";

const notificationsCrudSaga = createCRUDSaga({
    moduleName: "notifications",
    entityName: "notification",
    getPrefixPath: () => "/notifications",
    idField: "sid",
});

let notificationIds = [];

function* notificationsManagementSaga() {
    while (true) {
        notificationIds = (yield select(selectNotifications)).map((it) => it.sid);
        yield delay(10000);
        yield put(notificationsCRUDActions.use.LIST_ENTITIES());
    }
}

function* notificationsRefreshSaga() {
    yield put(notificationsCRUDActions.use.LIST_ENTITIES());
}

function* listEntitiesComplete() {
    const newNotificationIds = (yield select(selectNotifications)).map((it) => it.sid);
    if (newNotificationIds.some((it) => !notificationIds.includes(it))) {
        const project = yield select(selectActiveProject);
        yield put(documentsCRUDActions.use.LIST_ENTITIES({ source: { project } }));
    }
}

export function* notificationsCombinedSaga() {
    yield all([
        notificationsCrudSaga(),
        notificationsManagementSaga(),
        // TODO: this is not very efficient
        yield takeEvery(notificationsCRUDActions.UPDATE_ENTITY_COMPLETE, notificationsRefreshSaga),
        yield takeEvery(notificationsCRUDActions.LIST_ENTITIES_COMPLETE, listEntitiesComplete),
    ]);
}
