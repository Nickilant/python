import { all } from "redux-saga/effects";
import { notificationsCombinedSaga } from "./notifications";

export function* notificationsRootSaga() {
    yield all([
        notificationsCombinedSaga(),
    ]);
}
