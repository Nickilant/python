import { getCRUDEntityActions } from "../../../shared/actions/entityCrudActions";
import { TOGGLE_NOTIFICATIONS_DROPDOWN } from "./actionTypes";

export const notificationsCRUDActions = getCRUDEntityActions("notifications", "notification");

export const toggleNotificationsDropdown = (value) => ({
    type: TOGGLE_NOTIFICATIONS_DROPDOWN,
    payload: value,
});
