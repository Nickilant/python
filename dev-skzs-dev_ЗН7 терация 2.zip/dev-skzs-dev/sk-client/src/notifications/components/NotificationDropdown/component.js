import React, { useState } from "react";
import cx from "classnames";
import "./styles.scss";
import { OutsideClickHandler } from "../../../shared/components/OutsideClickHandler/component";

export function NotificationDropdown({ onHide, onMarkAsUnread }) {
    const [optionsOpened, toggleOptions] = useState(false);

    const handleHide = () => {
        onHide();
        toggleOptions(false);
    };

    const handleMarkAsUnread = () => {
        onMarkAsUnread();
        toggleOptions(false);
    };

    return (
        <div className={cx(
            [
                "notification-dropdown",
                {
                    opened: optionsOpened,
                },
            ],
        )}
        >

            <OutsideClickHandler onBlur={() => toggleOptions(false)}>
                <button onClick={() => toggleOptions(!optionsOpened)}>
                    <span className="bg-img icon-arrow" />
                </button>
                <div className="options">
                    <div className="option" onClick={handleHide}>Скрыть</div>
                    <div className="option" onClick={handleMarkAsUnread}>Пометить как непрочитанное</div>
                </div>
            </OutsideClickHandler>
        </div>
    );
}
