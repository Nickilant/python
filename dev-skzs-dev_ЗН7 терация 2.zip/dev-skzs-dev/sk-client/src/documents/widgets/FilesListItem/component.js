import React from "react";
import cx from "classnames";

import { calcFileSize } from "../../../shared/helpers/calcFileSize";

import "./styles.scss";
import removeIcon from "./assets/remove.svg";

export default function FilesListItem(props) {
    const {
        file, removeFile,
    } = props;

    const handleRemoveFile = () => {
        removeFile(file);
    };

    return (
        <li className="documents-files-list-item">
            <div className={`img type-${file.file_ext}`} />
            <div className="file-content">
                <div className="title">
                    {file.file_name}
                    {file.local && (// TODO: implement from server
                        <span className="computer" />
                    )}
                    <span className={cx("star", file.favorite && "star-active")} />
                    {/* // TODO: implement from server */}
                    <div className="actions">
                        {/* <div className="edit" /> */}
                        <img onClick={handleRemoveFile} src={removeIcon} alt="Удаление" />
                    </div>
                    <span className="size">
                        {calcFileSize(file.size)}
                    </span>
                </div>
                <p className="desc">{file.desc}</p>
                {/* // TODO: implement from server */}
            </div>
        </li>
    );
}
