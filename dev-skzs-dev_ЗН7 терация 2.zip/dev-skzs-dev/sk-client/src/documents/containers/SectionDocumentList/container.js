import React, { useEffect } from "react";
import { connect, useDispatch } from "react-redux";
import { push } from "connected-react-router";

import { orderByAction } from "../../actions/SectionDocumentList/actions";
import {
    filterByGroup,
    search,
    selectActiveEntity,
    selectCurrentProjectFiles,
    sort,
} from "../../selectors/documents";
import { SectionDocumentSort } from "../../components/SectionDocumentSort/component";
import { SectionDocumentListItem } from "../../components/SectionDocumentsListItem/component";
import { getAllChildren } from "../../../categories/selectors/treeStructure";
import { WIDGET_TYPES } from "../../../shared/constants/widgetTypes";
import { openRightColumnContainerAction } from "../../../shared/actions/RightColumnContainer/actions";
import { commentsCRUDActions } from "../../../comments/actions/actions";
import { selectActiveProject } from "../../../projects/selectors/projects";
import { getURL } from "../../../shared/helpers/getPath";

import "./styles.scss";

const SectionDocumentList = (props) => {
    const {
        documents,
        documentsCount,
        sortParams,
        orderBy,
        openRightColumnContainer,
        loadComments,
        project,
        selectedFile,
        routerPathParams,
    } = props;

    const openDetails = (entity) => {
        openRightColumnContainer(
            WIDGET_TYPES.FILE_PREVIEW,
            entity,
        );
        loadComments({
            source: {
                project,
                entity,
            },
        });
    };

    const dispatch = useDispatch();

    const handleOpenDetails = (id) => {
        const path = getURL(routerPathParams, ["projects", "section", "group", ["document", id]]);
        dispatch(push(path));
    };

    useEffect(() => {
        const documentId = routerPathParams.document;
        const entity = documents.filter((it) => it.id === documentId)[0];

        if (entity) {
            openDetails(entity);
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [
        routerPathParams,
        documentsCount,
    ]);

    return (
        <div className="section-document-list">
            <div className="head">
                <SectionDocumentSort
                    sortParams={sortParams}
                    orderBy={orderBy}
                />
            </div>
            <div className="list">
                { documents.map((item) => (
                    <SectionDocumentListItem
                        key={item.id}
                        item={item}
                        showActions={false}
                        currentItem={item.id === (selectedFile && selectedFile.id)}
                        onSelect={handleOpenDetails}
                    />
                ))}
            </div>
        </div>
    );
};

const mapStateToProps = (state) => {
    const {
        documentsList,
    } = state.documents;

    const {
        searchQuery, sortParams, attributes, showAll, page, pageSize,
    } = documentsList;

    const selectedGroups = getAllChildren(state);
    const filteredByGroup = filterByGroup(selectCurrentProjectFiles(state), selectedGroups);
    const filteredBySearch = search(filteredByGroup, searchQuery, attributes, showAll);

    const documentsCount = filteredBySearch.length;

    return {
        ...state.documents.documentsList,
        pageSize,
        documentsCount,
        project: selectActiveProject(state),
        documents: sort(filteredBySearch, sortParams),
        documentsPage: page,
        selectedFile: selectActiveEntity(state),
        routerPathParams: state.core.router,
    };
};

export const SectionDocumentListContainer = connect(
    mapStateToProps,
    {
        orderBy: orderByAction,
        openRightColumnContainer: openRightColumnContainerAction,
        loadComments: commentsCRUDActions.use.LIST_ENTITIES,
    },
)(SectionDocumentList);
