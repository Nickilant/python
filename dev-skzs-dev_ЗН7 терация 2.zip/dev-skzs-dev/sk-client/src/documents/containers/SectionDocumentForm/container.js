/* eslint react/jsx-props-no-spreading:0 */
import React, { useState } from "react";
import cx from "classnames";
import { connect, useDispatch, useSelector } from "react-redux";
import { useDropzone } from "react-dropzone";
import { uniqueId } from "lodash";
import { Select } from "antd";
import {
    closeFormAction,
    setDescriptionAction,
    setUploadingListAction,
    setUsersAction,
    uploadFormAction,
} from "../../actions/SectionDocumentList/actions";

import { SectionDocumentListItem } from "../../components/SectionDocumentsListItem/component";
import { Modal } from "../../../shared/ConfirmModal/component";

import "./styles.scss";
import { uploadActivityFormAction } from "../../../activities/actions/actions";
import { usersArray } from "../../../users/selectors/users";
import { companiesArray } from "../../../organizations/selectors/companies";
import { selectCurrentLeafCategoryActivity } from "../../../activities/selectors/activities";

const UserSelector = ({ onChange }) => {
    const companies = useSelector(companiesArray);
    // const [companiesList, setCompaniesList] = useState([]);
    const [currentSelectedCompany, setCurrentSelectedCompany] = useState(null);
    const [currentSelectedUser, setCurrentSelectedUser] = useState([]);
    const users = useSelector((state) => usersArray(state, currentSelectedCompany));

    const handleAddUser = (id) => {
        setCurrentSelectedUser(id);
        onChange(id);
    };

    const handleSetCompany = (id) => {
        setCurrentSelectedCompany(id);
        handleAddUser(null);
    };

    return (
        <div className="user-selector">

            <Select
                className="selector"
                showSearch
                // optionFilterProp="children"
                placeholder="Организация"
                // disabled={config.is_disabled}
                onChange={handleSetCompany}
                // value={value}
            >
                {
                    companies.map((item, id) => (
                        <Select.Option key={id} value={item.value}>{item.label}</Select.Option>
                    ))
                }
            </Select>

            <Select
                className="selector"
                showSearch
                // optionFilterProp="children"
                placeholder="Ответственное лицо"
                disabled={!currentSelectedCompany}
                onChange={handleAddUser}
                value={currentSelectedUser}
            >
                {
                    users.map((item, id) => (
                        <Select.Option key={id} value={item.value}>{item.label}</Select.Option>
                    ))
                }
            </Select>
        </div>
    );
};

const UserMultiSelector = ({ handleChangeUser, userList }) => (
    <div>
        <div className="label">Ответственное лицо:</div>

        {
            [1, ...Object.values(userList)].map((item, index) => (
                <UserSelector key={item} onChange={(v) => handleChangeUser(v, index)} />
            ))
        }
    </div>
);

const SectionDocumentFormContainer = (props) => {
    const {
        uploadForm,
        uploadActivityForm,
        selectedGroup,
        selectedSection,
        files,
        setDescription,
        setUploadingList,
        active_project,
        activity,
        shortVersion,
    } = props;

    const onDrop = (acceptedFiles) => {
        const newFiles = acceptedFiles.map((raw_file) => {
            const ext = raw_file.name.split(".").pop();
            const title = raw_file.name;
            const { size } = raw_file;
            const group = selectedGroup;
            const section = selectedSection.split("-").join("_");
            const description = "";
            const id = uniqueId();
            return {
                ext, title, size, group, section, description, raw_file, id,
            };
        });
        setUploadingList(newFiles);
    };

    const {
        getRootProps, getInputProps, isDragActive, open,
    } = useDropzone({ noClick: true, onDrop });

    const state = useSelector((s) => s);

    const handleUpload = () => {
        const category = selectCurrentLeafCategoryActivity(activity.activityCategory)(state).projectCategory.sid;

        if (!activity) {
            uploadForm(active_project, selectedGroup, files);
        } else {
            uploadActivityForm(active_project, category, activity.sid, files);
        }
    };

    const validateUpload = () => !!selectedGroup && files.length > 0;

    const [modal, showModal] = useState(false);
    const [modal_users, showModalUsers] = useState(false);

    const [descriptionText, setDescriptionText] = useState("");
    const [idEditedFile, setIdEditedFile] = useState(null);

    const handleSetDescription = () => {
        setDescription({ id: idEditedFile, text: descriptionText });
        showModal(false);
    };

    const handleOpenModal = (id) => {
        showModal(true);
        setIdEditedFile(id);
    };

    const handleOpenModalUsers = (id) => {
        showModalUsers(true);
        setIdEditedFile(id);
    };

    const dispatch = useDispatch();

    const [userList, setUserList] = useState({});

    const handleChangeUser = (id, index) => {
        setUserList({ ...userList, [index]: id });
    };

    const handleSubmitUsers = () => {
        dispatch(setUsersAction({ id: idEditedFile, users: Object.values(userList) }));
        showModalUsers(false);
    };

    const handleClearList = () => {
        dispatch(setUploadingListAction([]));
    };

    const handleRemoveItem = (file) => {
        dispatch(setUploadingListAction(files.filter((f) => f.id !== file.id)));
    };

    return (
        <div className="section-document-form">
            <Modal
                className="section-document-form-modal"
                title="Введите комментарий к файлу"
                onOk={handleSetDescription}
                onCancel={() => showModal(false)}
                visible={modal}
                buttonText="Сохранить комментарий"

            >
                <div className="textarea-wrapper">
                    <div className="label">Комментарий:</div>
                    <textarea className="description-input" onChange={(e) => setDescriptionText(e.target.value)} />
                </div>
            </Modal>
            <Modal
                className="section-document-form-modal"
                title="Укажите список ответственных лиц"
                onCancel={() => showModalUsers(false)}
                visible={modal_users}
                onOk={handleSubmitUsers}
                buttonText="Сохранить"

            >
                <UserMultiSelector
                    handleChangeUser={handleChangeUser}
                    userList={userList}
                />
            </Modal>
            {
                (!shortVersion || files.length === 0) && (
                    <div className="head">
                        <div className="title">Загрузить файлы</div>
                        <div className="close-button" />
                    </div>
                )
            }
            {
                (!shortVersion || files.length === 0) && (
                    <div {...getRootProps({ className: cx("upload-space", { active: isDragActive }) })}>
                        <input {...getInputProps()} />
                        <div className="description">
                            <div className="bg-img icon icon-upload" />
                            <div className="text">Перетащите нужные файлы прямо сюда</div>
                            <div className="or">или</div>
                            <button className="upload-button" onClick={open}>
                                Выберите их в проводнике
                            </button>
                        </div>
                    </div>
                )
            }
            {
                files.length > 0 && (
                    <div className="uploaded">
                        <div className="head">
                            <div className="title">Выбранные файлы</div>
                            <span className="clear" onClick={handleClearList}>
                                <span className="icon bg-img remove" />
                                {" "}
                                Очистить список
                            </span>
                        </div>
                        <ul className="files-list">
                            {
                                files.map((item) => (
                                    <SectionDocumentListItem
                                        key={item.id}
                                        removeFile={handleRemoveItem}
                                        item={{
                                            title: (
                                                <>
                                                    {item.title}
                                                    <span
                                                        className="icon-set-description bg-img"
                                                        onClick={() => handleOpenModal(item.id)}
                                                    />
                                                    {
                                                        activity && (
                                                            <span
                                                                className="icon-set-users bg-img"
                                                                onClick={() => handleOpenModalUsers(item.id)}
                                                            />
                                                        )
                                                    }
                                                </>
                                            ),
                                            description: item.description,
                                            size: item.size,
                                            ext: item.ext,
                                            id: item.id,
                                        }}

                                    />
                                ))
                            }
                        </ul>
                    </div>
                )
            }
            <button
                className="add-files"
                onClick={handleUpload}
                disabled={!validateUpload()}
            >
                Загрузить файлы
            </button>
        </div>
    );
};

const mapStateToProps = (state, ownProps) => ({
    active_project: state.projects.list.active,
    selectedGroup: state.categories.treeStructure[ownProps.useTree ? ownProps.useTree : "documents-list"].selectedNode,
    selectedSection: state.categories.treeStructure[ownProps.useTree ? ownProps.useTree : "documents-list"].section,
    formOpened: state.documents.documentsList.formOpened,
    files: state.documents.documentsList.uploadingList,
    activity: state.activities.activities.openedActivity,
    shortVersion: !!ownProps.useTree,
});

export const SectionDocumentForm = connect(
    mapStateToProps,
    {
        setUploadingList: setUploadingListAction,
        uploadForm: uploadFormAction,
        uploadActivityForm: uploadActivityFormAction,
        closeForm: closeFormAction,
        setDescription: setDescriptionAction,
    },
)(SectionDocumentFormContainer);
