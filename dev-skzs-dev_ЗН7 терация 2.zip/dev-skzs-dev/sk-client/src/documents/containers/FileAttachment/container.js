import React from "react";
import cx from "classnames";
import { connect, useSelector } from "react-redux";
import { Input } from "antd";

import { TreeStructureContainer } from "../../../categories/containers/TreeStructure/container";
import {
    attachDocumentAction,
    closeAttachmentFormAction,
    detachDocumentAction,
    orderByAction,
    searchDocumentsAction,
    selectSectionAction,
} from "../../actions/FileAttachment/actions";
import { SectionDocumentListItem } from "../../components/SectionDocumentsListItem/component";

import { getAllChildren } from "../../../categories/selectors/treeStructure";
import {
    filterByGroup,
    search,
    selectCurrentProjectFiles,
    selectedDocumentView,
    sort,
} from "../../selectors/documents";
import { SectionDocumentSort } from "../../components/SectionDocumentSort/component";

import "./styles.scss";
import { selectNodeAction } from "../../../categories/actions/actions";
import { documentsCRUDActions } from "../../actions/actions";
import { selectActiveProject } from "../../../projects/selectors/projects";
import { SectionDocumentForm } from "../SectionDocumentForm/container";

const { Search } = Input;

const FileAttachmentContainer = (props) => {
    const {
        currentSection,
        closeAttachmentForm,
        selectSection,
        sections,
        documents,
        sortParams,
        orderBy,
        // selectNode,
        searchDocuments,
        attachDocument,
        detachDocument,
        attachments,
        activeProject,
        selectedDocument,
        submitAttachments,
    } = props;

    const handleSelectSection = (sid) => {
        selectSection(sid);
    };

    const handleAttachDocument = (id) => (e) => {
        const { checked } = e.target;
        (checked ? attachDocument : detachDocument)(id);
    };

    const handleSubmitAttachments = () => {
        const source = {
            id: selectedDocument.id,
            project: activeProject,
            type: selectedDocument.type,
        };
        const form = {
            file_documents: attachments,
        };

        submitAttachments({
            source,
            form,
            module: selectedDocument.module,
        });
        closeAttachmentForm();
    };

    const title = {
        prescription: "предписанию",
        act: "акту",
        remark: "замечанию",
    }[selectedDocument.type];

    const categories = {
        "Проектная документация": "project-docs",
        "Строительный контроль": "construction-control",
        "Нормативная документация": "normative-docs",
    };

    const searchValue = useSelector((state) => state.documents.attachmentForm.searchQuery);

    return (
        <div className="file-attachment-form-wrapper">
            <div className="file-attachment-form">
                <div className="head">
                    <div className="block-title">
                        Прикрепить файлы к
                        {" "}
                        {title}
                    </div>
                    <div className="close-icon bg-img" onClick={closeAttachmentForm} />
                </div>
                <div className="select-section">
                    <div className="sections-list">
                        <div className="block-title">Выберите раздел с нужными файлами</div>
                        <div className="sections">
                            {
                                sections.map(({ sid, name }) => (
                                    <div
                                        className={cx("section", { active: currentSection === sid })}
                                        onClick={() => handleSelectSection(sid)}
                                        key={sid}
                                    >
                                        <div className={`icon icon-${categories[name]}`} />
                                        {name}
                                    </div>
                                ))
                            }
                        </div>
                    </div>
                    <div className="groups-list">
                        <div className="block-title">
                            Выберите их месторасположение
                        </div>
                        <div className="tree-wrapper">
                            <TreeStructureContainer treeName="file-attachment" />
                        </div>
                    </div>

                </div>
                <div className="files-list">
                    <div className="filters-wrapper">
                        <div className="block-title">Выберите файлы, которые нужно прикрепить</div>
                        <div className="filters">
                            <div className="search-bar">
                                <Search defaultValue={searchValue} allowClear placeholder="Поиск по названию" onSearch={searchDocuments} />
                            </div>
                        </div>
                    </div>

                    <div className="files-wrapper ">
                        <div className="files">
                            <div className="head">
                                <SectionDocumentSort
                                    sortParams={sortParams}
                                    orderBy={orderBy}
                                />
                            </div>

                            <div className="list">

                                { documents.map((item) => (
                                    <div
                                        className="list-item"
                                        key={item.id}
                                    >
                                        <input type="checkbox" className="checkbox" checked={attachments.includes(item.id)} onChange={handleAttachDocument(item.id)} />
                                        <SectionDocumentListItem
                                            id={item.id}
                                            item={item}
                                            showActions={false}
                                        />
                                    </div>
                                ))}
                            </div>
                        </div>
                        <button className="attach-files attachment" onClick={handleSubmitAttachments}>
                            Добавить файлы к
                            {" "}
                            {title}
                        </button>
                    </div>

                    <div className="upload">
                        <SectionDocumentForm useTree="file-attachment" />
                    </div>
                </div>
            </div>
        </div>
    );
};

const mapStateToProps = (state) => {
    const {
        attachmentForm,
    } = state.documents;

    const documents = selectCurrentProjectFiles(state);
    const {
        searchQuery, sortParams, page, pageSize,
    } = attachmentForm;

    const selectedGroups = getAllChildren(state, "file-attachment");

    const filteredByGroup = filterByGroup(documents, selectedGroups);
    const filteredBySearch = search(filteredByGroup, searchQuery, [], true);
    const documentsCount = filteredBySearch.length;
    const sections = state.categories.treeStructure.nested_tree
        ? Object.values(state.categories.treeStructure.nested_tree).filter((it) => !["Исполнительная документация"].includes(it.name))
        : [];

    return {
        ...state.documents.attachmentForm,
        pageSize,
        documentsPage: page,
        documentsCount,
        sections,

        // sections: state.categories.treeStructure.nested_tree
        //     ? Object.values(state.categories.treeStructure.nested_tree)
        //         .filter((it) => (it.name !== "Исполнительная документация")) // TODO: restore in future
        //     : [],
        attachments: state.documents.attachmentForm.attachments,
        activeProject: selectActiveProject(state),
        selectedDocument: selectedDocumentView(state),
        currentSection: state.categories.treeStructure["file-attachment"].section,
        documents: sort(filteredBySearch, sortParams),
    };
};

export const FileAttachment = connect(
    mapStateToProps,
    {
        orderBy: orderByAction,
        closeAttachmentForm: closeAttachmentFormAction,
        selectSection: selectSectionAction,
        selectNode: selectNodeAction,
        searchDocuments: searchDocumentsAction,
        attachDocument: attachDocumentAction,
        detachDocument: detachDocumentAction,
        submitAttachments: documentsCRUDActions.use.UPDATE_ENTITY,
    },
)(FileAttachmentContainer);
