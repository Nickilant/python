import React from "react";
import cx from "classnames";
import { connect, useSelector } from "react-redux";

import { Input } from "antd";
import {
    searchDocumentsAction,
    toggleAllAction,
    toggleAttributeAction,
} from "../../actions/SectionDocumentList/actions";

import "./styles.scss";
import { getAllChildren } from "../../../categories/selectors/treeStructure";
import { filterByGroup, selectCurrentProjectFiles } from "../../selectors/documents";

const { Search } = Input;

const SectionDocumentSearch = (props) => {
    const {
        attributes,
        searchDocuments,
        toggleAttribute,
        showAll,
        toggleAll,
    } = props;
    const handleToggleAttribute = (ext) => () => {
        toggleAttribute(ext);
    };

    const searchValue = useSelector((state) => state.documents.documentsList.searchQuery);

    return (
        <div className="document-search">
            <div className="search-bar">
                <Search defaultValue={searchValue} allowClear placeholder="Поиск по названию" onChange={(e) => searchDocuments(e.target.value)} />
            </div>

            { Object.keys(attributes).length > 1 && (
                <div className="attributes">
                    <button
                        onClick={toggleAll}
                        className={cx("attribute", "toggle-all-button", { active: showAll })}
                    >
                        Все
                    </button>
                    {
                        Object.entries(attributes).map(([key, value]) => (
                            <button
                                onClick={handleToggleAttribute(key)}
                                className={cx("attribute", { active: value })}
                                key={key}
                            >
                                {key}
                            </button>
                        ))
                    }
                </div>
            )}
        </div>
    );
};

const mapStateToProps = (state) => {
    const {
        attributes,
        searchDocuments,
        toggleAttribute,
        showAll,
        toggleAll,
    } = state.documents.documentsList;

    const selectedGroups = getAllChildren(state);

    const filteredByGroup = filterByGroup(selectCurrentProjectFiles(state), selectedGroups);

    const filteredAttributes = {};

    filteredByGroup.forEach((item) => {
        filteredAttributes[item.ext] = attributes[item.ext];
    });

    return {
        attributes: filteredAttributes,
        searchDocuments,
        toggleAttribute,
        showAll,
        toggleAll,
    };
};

export const SectionDocumentSearchContainer = connect(mapStateToProps, {
    searchDocuments: searchDocumentsAction,
    toggleAttribute: toggleAttributeAction,
    toggleAll: toggleAllAction,
})(SectionDocumentSearch);
