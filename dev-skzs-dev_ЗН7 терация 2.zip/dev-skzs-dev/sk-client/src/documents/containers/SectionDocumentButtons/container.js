import React from "react";
import { connect, useSelector } from "react-redux";

import "./styles.scss";
import { openRightColumnContainerAction } from "../../../shared/actions/RightColumnContainer/actions";
import { WIDGET_TYPES } from "../../../shared/constants/widgetTypes";
import { canCreateDocument } from "../../../construction_control/base/selectors/permissions";
import { DOCUMENT_TYPES } from "../../constants/types";

const SectionDocumentButtons = (props) => {
    const { openRightColumnContainer } = props;

    const canAddDocument = useSelector((state) => canCreateDocument(state, DOCUMENT_TYPES.FILE));

    const handleOpenForm = () => {
        if (canAddDocument) {
            openRightColumnContainer(
                WIDGET_TYPES.FILE_UPLOAD_FORM,
            );
        }
    };
    return (
        <div className="document-buttons">
            <button
                className="usual"
                onClick={handleOpenForm}
                disabled={!canAddDocument}
            >
                {canAddDocument}
                Добавить документ
            </button>
        </div>
    );
};

const mapStateToProps = (state) => ({
    ...state.documents.documentsList,
});

const actions = {
    openRightColumnContainer: openRightColumnContainerAction,
};

export const SectionDocumentButtonsContainer = connect(
    mapStateToProps,
    actions,
)(SectionDocumentButtons);
