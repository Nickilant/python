/* eslint react/jsx-props-no-spreading:0 */
import React, { useState } from "react";
import { connect, useSelector } from "react-redux";

import { Input } from "antd";
import { commentsCRUDActions } from "../../../comments/actions/actions";
import { selectActiveProject } from "../../../projects/selectors/projects";
import { selectActiveEntity } from "../../selectors/documents";
import RightColumn from "../../../core/components/RightColumn/component";
import { FileIcon } from "../../components/FileIcon/component";
import { documentsCRUDActions } from "../../actions/actions";
import { confirm, Modal } from "../../../shared/ConfirmModal/component";

import { CommentInput } from "../../../shared/components/CommentInput/component";
import { Comment } from "../../../shared/Comment/component";

import "./styles.scss";
import noCommentIcon from "./assets/no_comments.svg";
import { canDeleteDocument, canEditDocument } from "../../../construction_control/base/selectors/permissions";
import { DOCUMENT_TYPES } from "../../constants/types";

const { TextArea } = Input;

const FileDetails = ({
    user, handleAddComment, comments, entity, handleUpdateComment, handleDeleteComment,
}) => (
    <div>
        <div className="comments">
            <div className="comment-add">
                <CommentInput
                    name={`${user.lastName} ${user.firstName}`}
                    avatar={user.avatar}
                    commentsLength={comments.length}
                    onSubmit={handleAddComment}
                />
            </div>
            <div className="divider" />
            <div className="comments-list">
                {
                    comments.length
                        ? comments.map((item) => (
                            <Comment
                                id={item.sid}
                                key={item.sid}
                                comment={item}
                                text={item.body}
                                avatar={item.user.avatar}
                                name={item.user.full_name}
                                date={item.creation_date}
                                own={item.user.sid === user.sid}
                                currentDocument={entity}
                                onEdit={
                                    ({ comment }) => (
                                        handleUpdateComment(comment.id,
                                            comment.inputValue)
                                    )
                                }
                                onRemove={() => handleDeleteComment(item.sid)}
                            />
                        ))
                        : (
                            <div className="no-comments">
                                <img src={noCommentIcon} alt="Нет комментариев" />
                                Пока ещё никто не оставил свой комментарий.
                            </div>
                        )
                }
            </div>
        </div>
    </div>
);

const SectionDocumentDetailsContainer = (props) => {
    const {
        comments,
        user,
        createComment,
        deleteComment,
        project,
        entity,
        deleteFile,
        updateDescription,
        updateComment,
        routerParams,
        download,
    } = props;

    const handleAddComment = (text) => {
        createComment({
            source: {
                project,
                entity,
            },
            form: {
                body: text,
            },
        });
    };

    const handleUpdateComment = (sid, text) => {
        updateComment({ source: { project, entity, sid }, form: { body: text } });
    };

    const handleDeleteComment = (sid) => {
        deleteComment({
            source: {
                project,
                entity,
                sid,
            },
        });
    };

    const handleRemoveFile = () => {
        deleteFile({
            source: {
                project,
                id: entity.id,
                type: entity.type,
            },
        });
    };

    const [modal, showModal] = useState(false);
    const [descriptionText, setDescriptionText] = useState("");
    const canDeleteFile = useSelector((state) => canDeleteDocument(state, DOCUMENT_TYPES.FILE));
    const canEditFile = useSelector((state) => canEditDocument(state, DOCUMENT_TYPES.FILE));

    const handleSetDescription = () => {
        updateDescription({
            source: {
                project,
                id: entity.id,
                type: entity.type,
            },
            form: {
                description: descriptionText,
            },
        });
        showModal(false);
    };

    const handleOpenModal = () => {
        showModal(true);
    };

    return (
        <div className="section-document-details">
            <Modal
                title="Отредактируйте комментарий к файлу"
                onOk={handleSetDescription}
                onCancel={() => showModal(false)}
                visible={modal}
                buttonText="Сохранить комментарий"

            >
                <div className="textarea-wrapper">
                    <div className="label">Комментарий:</div>
                    <TextArea
                        className="description-input"
                        defaultValue={entity.description}
                        onChange={(e) => setDescriptionText(e.target.value)}
                        autoFocus
                    />
                </div>
            </Modal>
            <RightColumn
                icon={<FileIcon ext={entity.ext} />}
                title={entity.title}
                subTitle={(
                    <div className="subtitle">
                        <span>{entity.description}</span>
                        {
                            canEditFile
                            && (
                                <button onClick={handleOpenModal} className="edit-description bg-img edit-icon" title="Редактировать описание" />
                            )
                        }
                        <div className="info">
                            <div className="author">{entity.author}</div>
                            <div className="date">{entity.date.format("DD.MM.YY HH:mm")}</div>
                        </div>
                    </div>
                )}
                otherActions={[]}
                TopAction={null}
                Body={(
                    routerParams.section !== "project-documents"
                    && (
                        <FileDetails
                            user={user}
                            handleAddComment={handleAddComment}
                            comments={comments}
                            entity={entity}
                            handleUpdateComment={handleUpdateComment}
                            handleDeleteComment={handleDeleteComment}
                        />
                    )
                )}
                BottomAction={(
                    <div className="bottom-panel">
                        <a
                            href={entity.link}
                            className="btn-usual btn-download"
                            onClick={download}
                            download
                        >
                            Скачать документ
                        </a>
                        {
                            canDeleteFile
                            && (
                                <button
                                    className="btn-remove"
                                    onClick={() => confirm({
                                        onOk() {
                                            handleRemoveFile();
                                        },
                                        content: "Удалить документ? Это действие невозможно отменить.",
                                    })}
                                >
                                    Удалить
                                </button>
                            )
                        }
                    </div>
                )}
            />
        </div>
    );
};

const mapStateToProps = (state) => ({
    comments: Object.values(state.comments.crud.items),
    routerParams: state.core.router,
    user: state.users.currentUser.user,
    project: selectActiveProject(state),
    entity: selectActiveEntity(state),
});

export const SectionDocumentDetails = connect(
    mapStateToProps,
    {
        createComment: commentsCRUDActions.use.CREATE_ENTITY,
        updateComment: commentsCRUDActions.use.UPDATE_ENTITY,
        deleteComment: commentsCRUDActions.use.DELETE_ENTITY,
        deleteFile: documentsCRUDActions.use.DELETE_ENTITY,
        updateDescription: documentsCRUDActions.use.UPDATE_ENTITY,
    },
)(SectionDocumentDetailsContainer);
