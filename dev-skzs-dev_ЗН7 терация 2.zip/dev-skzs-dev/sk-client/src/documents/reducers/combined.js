import { combineReducers } from "redux";
import { documentsReducer } from "./documents";
import { attachmentFormReducer } from "./fileAttachment";
import { crudReducerFactory } from "../../shared/reducers/crudFactory";
import { managementFormReducerFactory } from "../../shared/reducers/formFactory";

// TODO: move this to a separate reducer
const initialState = {
    type: "document",
    data: {
        location: "",
        code: "",
        date: new Date(),
        type: "prescription",
    },
};

export default combineReducers({
    crud: crudReducerFactory("documents", "document", "id"),
    documentForm: managementFormReducerFactory(initialState, "document", "documents"),
    documentsList: documentsReducer,
    attachmentForm: attachmentFormReducer,
});
