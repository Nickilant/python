import { documentsCRUDActions } from "../actions/actions";

import {
    SECTION_DOCUMENT_FILE_SET_DESCRIPTION, SECTION_DOCUMENT_FILE_SET_USERS,
    SECTION_DOCUMENT_FORM_CLOSE,
    SECTION_DOCUMENT_FORM_OPEN,
    SECTION_DOCUMENT_LIST_ADD_NEW,
    SECTION_DOCUMENT_LIST_ORDER_BY,
    SECTION_DOCUMENT_LIST_SEARCH,
    SECTION_DOCUMENT_LIST_SELECT_DOCUMENT,
    SECTION_DOCUMENT_LIST_TOGGLE_ALL,
    SECTION_DOCUMENT_LIST_TOGGLE_ATTRIBUTE,
    SECTION_DOCUMENT_SET_UPLOADING_LIST,
} from "../actions/SectionDocumentList/actionTypes";
import { TREE_STRUCTURE_SELECT_NODE } from "../../categories/actions/actionTypes";
import { CONSTRUCTION_CONTROL_EXTRA2D } from "../../construction_control/extra_2d/actions/actionTypes";

const initialState = {
    searchQuery: "",
    sortParams: {
        attribute: "",
        order: "asc",
    },
    selectedItem: null,
    page: 0,
    pageSize: 10,
    attributes: {},
    documents: [

    ],
    showAll: true,
    documentsCount: 23,
    formOpened: false,
    uploadingList: [

    ],
    marker_creating: false,
};
export const documentsReducer = (state = initialState, action) => {
    switch (action.type) {
        case CONSTRUCTION_CONTROL_EXTRA2D.MARKER_CREATING:
            return {
                ...state,
                marker_creating: action.payload,
            };

        case SECTION_DOCUMENT_LIST_ORDER_BY: {
            return {
                ...state,
                sortParams: { ...action.payload },
            };
        }
        case SECTION_DOCUMENT_LIST_SELECT_DOCUMENT: {
            return {
                ...state,
                selectedItem: state.selectedItem === action.payload.id ? null : action.payload.id,
            };
        }
        case SECTION_DOCUMENT_LIST_SEARCH: {
            return {
                ...state,
                searchQuery: action.payload.query,
            };
        }
        case SECTION_DOCUMENT_LIST_TOGGLE_ATTRIBUTE: {
            const { ext } = action.payload;

            return {
                ...state,
                showAll: false,
                attributes: {
                    ...state.attributes,
                    [ext]: !state.attributes[ext],
                },
            };
        }
        case SECTION_DOCUMENT_LIST_TOGGLE_ALL: {
            const attributes = {

            };

            Object.keys(state.attributes).forEach((item) => {
                attributes[item] = false;
            });

            return {
                ...state,
                showAll: !state.showAll,
                attributes,
            };
        }
        case SECTION_DOCUMENT_LIST_ADD_NEW: {
            const selectedSection = state.uploadingList[0] && state.uploadingList[0].section;
            return {
                ...state,
                [selectedSection]: [...state[selectedSection], ...state.uploadingList],
                uploadingList: [],
            };
        }
        case SECTION_DOCUMENT_FORM_OPEN: {
            return {
                ...state,
                formOpened: true,
            };
        }
        case SECTION_DOCUMENT_FORM_CLOSE: {
            return {
                ...state,
                formOpened: false,
            };
        }
        case SECTION_DOCUMENT_SET_UPLOADING_LIST: {
            return {
                ...state,
                uploadingList: action.payload.files,
            };
        }
        case SECTION_DOCUMENT_FILE_SET_DESCRIPTION: {
            const { id, text } = action.payload;
            return {
                ...state,
                uploadingList: state.uploadingList.map((item) => {
                    const result = { ...item };
                    if (item.id === id) {
                        result.description = text;
                    }
                    return result;
                }),
            };
        }
        case SECTION_DOCUMENT_FILE_SET_USERS: {
            const { id, users } = action.payload;
            return {
                ...state,
                uploadingList: state.uploadingList.map((item) => {
                    const result = { ...item };
                    if (item.id === id) {
                        result.users = users;
                    }
                    return result;
                }),
            };
        }
        case documentsCRUDActions.LIST_ENTITIES_COMPLETE: {
            const fileTypes = action.payload.list.map((item) => item.ext).filter(Boolean);

            const attributes = {

            };

            fileTypes.forEach((item) => {
                attributes[item] = false;
            });

            return {
                ...state,
                attributes,
            };
        }
        case documentsCRUDActions.CREATE_ENTITY_COMPLETE: {
            const fileType = action.payload.item.ext;

            return {
                ...state,
                attributes: {
                    [fileType]: false,
                    ...state.attributes,
                },
            };
        }
        case TREE_STRUCTURE_SELECT_NODE: {
            const { treeName } = action.payload;

            if (treeName !== "documents-list") return state;

            return {
                ...state,
                page: 0,
            };
        }
        default:
            return state;
    }
};
