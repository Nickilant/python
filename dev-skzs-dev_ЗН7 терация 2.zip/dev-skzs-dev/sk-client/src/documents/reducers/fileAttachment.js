import {
    FILE_ATTACHMENT_DOCUMENT_LIST_ATTACH,
    FILE_ATTACHMENT_DOCUMENT_LIST_DETACH,
    FILE_ATTACHMENT_DOCUMENT_LIST_ORDER_BY,
    FILE_ATTACHMENT_DOCUMENT_LIST_SEARCH,
    FILE_ATTACHMENT_FORM_CLOSE,
    FILE_ATTACHMENT_FORM_OPEN,
} from "../actions/FileAttachment/actionTypes";
import { TREE_STRUCTURE_SELECT_NODE } from "../../categories/actions/actionTypes";
import { documentsCRUDActions } from "../actions/actions";
import { DOCUMENT_TYPES } from "../constants/types";

const initialState = {
    attachmentFormOpened: false, // TODO: switch to true
    selectedSection: null,
    searchQuery: "",
    sortParams: {
        attribute: "",
        order: "asc",
    },
    attachments: [],
};

export const attachmentFormReducer = (state = initialState, action) => {
    switch (action.type) {
        case FILE_ATTACHMENT_FORM_OPEN: {
            return {
                ...state,
                attachmentFormOpened: true,
            };
        }
        case FILE_ATTACHMENT_FORM_CLOSE: {
            return {
                ...state,
                attachmentFormOpened: false,
                attachments: [],
            };
        }
        case FILE_ATTACHMENT_DOCUMENT_LIST_ORDER_BY: {
            return {
                ...state,
                sortParams: { ...action.payload },
            };
        }
        case FILE_ATTACHMENT_DOCUMENT_LIST_SEARCH: {
            return {
                ...state,
                searchQuery: action.payload.query,
            };
        }
        case FILE_ATTACHMENT_DOCUMENT_LIST_ATTACH: {
            const { id } = action.payload;
            return {
                ...state,
                attachments: [...state.attachments, id],
            };
        }

        case documentsCRUDActions.CREATE_ENTITY_COMPLETE: {
            const { item } = action.payload;
            if (item.type === DOCUMENT_TYPES.FILE) {
                return {
                    ...state,
                    attachments: [...state.attachments, item.id],
                };
            }
            return state;
        }

        case FILE_ATTACHMENT_DOCUMENT_LIST_DETACH: {
            const { id } = action.payload;
            return {
                ...state,
                attachments: state.attachments.filter((item) => item !== id),
            };
        }
        case TREE_STRUCTURE_SELECT_NODE: {
            const { treeName } = action.payload;

            if (treeName !== "file-attachment") return state;

            return {
                ...state,
                page: 0,
            };
        }
        default:
            return state;
    }
};
