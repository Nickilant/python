export const DOCUMENT_TYPES = {
    FILE: "file",
    PRESCRIPTION: "prescription",
    ACT: "act",
    REMARK: "remark",
    AOSR: "aosr",
    MAP: "map",
};
