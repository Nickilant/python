import React from "react";

import { TreeStructureContainer } from "../../../categories/containers/TreeStructure/container";
import { SectionDocumentListContainer } from "../../containers/SectionDocumentList/container";
import { SectionDocumentSearchContainer } from "../../containers/SectionDocumentSearch/container";
import { SectionDocumentButtonsContainer } from "../../containers/SectionDocumentButtons/container";

import "./styles.scss";

export const DocumentsPage = () => (
    <div className="documents-module documents-page columns">
        <TreeStructureContainer treeName="documents-list" />

        <div className="content">
            <SectionDocumentButtonsContainer />
            <SectionDocumentSearchContainer />
            <SectionDocumentListContainer />
        </div>

    </div>
);
