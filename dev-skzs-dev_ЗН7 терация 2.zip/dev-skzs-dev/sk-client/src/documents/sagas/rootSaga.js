import { all } from "redux-saga/effects";
import { documentsUploadFormCombinedSaga } from "./uploadForm";
import { documentsSaga } from "./documents";
import { createCRUDSaga } from "../../shared/sagas/entityCrudFactory";
import { entityManagementSaga } from "../../shared/sagas/formFactory";
import { documentsCRUDActions } from "../actions/actions";
import { WIDGET_TYPES } from "../../shared/constants/widgetTypes";
import {
    errorEntityInConverters,
    getEntityInConverters,
    listEntityInConverters,
    postEntityOutConverters,
} from "./converters";

const moduleName = "documents";

// TODO: move to appropriate places

const documentCrudSaga = createCRUDSaga({
    moduleName,
    entityName: "document",
    idField: "id",

    getPrefixPath: ({ payload }) => {
        if (payload.source.project) {
            return `/projects/${payload.source.project.key}/${moduleName}`;
        }
        return "";
    },

    entityPath: ({ payload }) => {
        const listType = `${payload.source.type}s`; // TODO: mapping would be more appropriate?
        return `/projects/${payload.source.project.key}/${listType}/${payload.source.id}/`;
    },

    postPath: ({ payload }) => {
        const listType = `${payload.form.type}s`; // TODO: mapping would be more appropriate?
        return `/projects/${payload.form.project.key}/${listType}/`;
    },

    listEntityIn: (item) => {
        if (!item.type) {
            return listEntityInConverters[item.project_document.type.toUpperCase()](item.project_document, item);
        }
        return listEntityInConverters[item.type.toUpperCase()](item);
    },

    // TODO: proper mapping
    detailsEntityIn: (item) => getEntityInConverters[item.project_document.type.toUpperCase()](item),
    listEntityAfterSubmit: (item) => listEntityInConverters[item.project_document.type](item.project_document, item),

    errorsEntityIn: (item, source) => errorEntityInConverters[source.type.toUpperCase()](item),

    detailsEntityOut: (item, source) => postEntityOutConverters[source.type.toUpperCase()](item),
});

const documentEntityManagementSaga = entityManagementSaga({
    keyField: "id",
    actions: documentsCRUDActions,
    moduleName,
    entityName: "document",
    viewWidget: WIDGET_TYPES.DOCUMENT_PREVIEW,
    editWidget: WIDGET_TYPES.DOCUMENT_MANAGEMENT_FORM,
    viewWidgetOverride: (item) => (item.type === "file" ? WIDGET_TYPES.FILE_PREVIEW : WIDGET_TYPES.DOCUMENT_PREVIEW),
});

export function* documentsRootSaga() {
    yield all([
        documentCrudSaga(),
        documentEntityManagementSaga,
        documentsUploadFormCombinedSaga(),
        documentsSaga(),
    ]);
}
