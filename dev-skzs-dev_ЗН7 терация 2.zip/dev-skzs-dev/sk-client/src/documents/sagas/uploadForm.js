import axios from "axios";
import {
    all, call, put, takeEvery,
} from "redux-saga/effects";

import {
    closeFormAction,
    setUploadingListAction,
    uploadFormFailedAction,
} from "../actions/SectionDocumentList/actions";

import {
    SECTION_DOCUMENT_FORM_UPLOAD,
    SECTION_DOCUMENT_FORM_UPLOAD_COMPLETE,
} from "../actions/SectionDocumentList/actionTypes";
import { getEntityInConverters } from "./converters";
import { documentsCRUDActions } from "../actions/actions";

function* formUpload({ payload }) {
    const { project, section, files } = payload;

    // eslint-disable-next-line no-restricted-syntax
    for (const it of files) {
        try {
            const formData = new FormData();

            formData.append("related_category", section);

            formData.append("file", it.raw_file);
            formData.append("comment", it.description);

            const response = yield call(axios.post, `/projects/${project}/files/`, formData);

            const item = response.data;
            yield put(documentsCRUDActions.use.CREATE_ENTITY_COMPLETE({
                source: it,
                item: getEntityInConverters[item.project_document.type.toUpperCase()](item),
                detail: getEntityInConverters[item.project_document.type.toUpperCase()](item),
                noForm: true,
            }));
        } catch (e) {
            yield put(uploadFormFailedAction(project, section, it));
        }
    }

    yield put(closeFormAction());
    yield put(setUploadingListAction([]));
}

function* afterUploadFormComplete() {
    // yield put(fetchDocumentsAction(payload.project.project));
}

function* watchUploadFormAction() {
    yield takeEvery(SECTION_DOCUMENT_FORM_UPLOAD, formUpload);
}

function* watchUploadFormCompleteAction() {
    yield takeEvery(SECTION_DOCUMENT_FORM_UPLOAD_COMPLETE, afterUploadFormComplete);
}

export function* documentsUploadFormCombinedSaga() {
    yield all([
        watchUploadFormAction(),
        watchUploadFormCompleteAction(),
    ]);
}
