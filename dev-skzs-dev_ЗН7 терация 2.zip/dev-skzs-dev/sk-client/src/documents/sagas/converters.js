import moment from "moment";
import {
    inActDocument,
    inActDocumentErrors,
    inAOSRDocument, inAOSRDocumentError,
    inFileDocument,
    inPrescriptionDocument,
    inPrescriptionDocumentErrors,
    inRemarkDocument,
    inRemarkDocumentErrors,
    outActDocument,
    outAOSRDocument,
    outFileDocument,
    outFileDocumentErrors,
    outPrescriptionDocument,
    outRemarkDocument,
} from "./base_converters";

export const listEntityInConverters = {
    FILE: (item, source) => {
        const document = source || item.file;
        return {
            ...inFileDocument(document),
            type: item.type.toLowerCase(),
            group: item.related_category,
        };
    },
    PRESCRIPTION: (item, source) => {
        const document = source || item.prescription;
        const date = moment(item.creation_date);
        return {
            ...inPrescriptionDocument(document, date),
            type: item.type.toLowerCase(),
            group: item.related_category,
            date,
        };
    },
    ACT: (item, source) => {
        const document = source || item.act;
        const date = moment(item.creation_date);
        return {
            ...inActDocument(document, date),
            type: item.type.toLowerCase(),
            group: item.related_category,
        };
    },
    REMARK: (item, source) => {
        const document = source || item.remark;
        const date = moment(item.creation_date);
        return ({
            ...inRemarkDocument(document, date),
            type: item.type.toLowerCase(),
            group: item.related_category,
        });
    },
    MAP: (item) => ({
        ...item.map,
        id: item.map.sid,
        type: item.type.toLowerCase(),
        group: item.related_category,
    }),

    AOSR: (item, source) => {
        const document = source || item.aosr;

        return {
            ...inAOSRDocument(document, item.creation_date),
            type: item.type.toLowerCase(),
            group: item.related_category,
        };
    },
};

// TODO: add keys for forms etc
export const getEntityInConverters = {
    FILE: (document) => {
        const item = document.project_document;
        return {
            ...inFileDocument(document),
            type: item.type.toLowerCase(),
            group: item.related_category,
        };
    },
    PRESCRIPTION: (document) => {
        const item = document.project_document;
        const date = moment(item.creation_date);
        return {
            ...inPrescriptionDocument(document, date),
            type: item.type.toLowerCase(),
            group: item.related_category,
            issued_with_company: document.representative_company && document.representative_company.sid,
            issued_with: document.representative_user && document.representative_user.full_name,
            issued_to: document.accepted_by.company.sid,
            // issued_with_role: document., // not implemented yet
            assignee: document.accepted_by.sid,
            date,
        };
    },
    ACT: (document) => {
        const item = document.project_document;
        const date = moment(item.creation_date);
        return {
            ...inActDocument(document, date),
            type: item.type.toLowerCase(),
            group: item.related_category,
            as_prescribed: document.prescription && document.prescription.sid,
        };
    },
    REMARK: (document) => {
        const item = document.project_document;
        const date = moment(item.creation_date);
        return ({
            ...inRemarkDocument(document, date),
            type: item.type.toLowerCase(),
            issued_to: document.assigned_company.sid,

            issued_with_company: document.representative_user && document.representative_user.company.sid,
            issued_with: document.representative_user && document.representative_user.full_name,

            group: item.related_category,
        });
    },
    AOSR: (document) => {
        const item = document.project_document;

        return {
            ...inAOSRDocument(document),
            type: item.type.toLowerCase(),
            group: item.related_category,
        };
    },
};

// TODO: add keys for forms etc
export const postEntityOutConverters = {
    PRESCRIPTION: (document) => outPrescriptionDocument(document),
    ACT: (document) => outActDocument(document),
    REMARK: (document) => outRemarkDocument(document),
    FILE: (document) => outFileDocument(document),
    AOSR: (document) => outAOSRDocument(document),
};

export const errorEntityInConverters = {
    PRESCRIPTION: (document) => inPrescriptionDocumentErrors(document),
    ACT: (document) => inActDocumentErrors(document),
    REMARK: (document) => inRemarkDocumentErrors(document),
    FILE: (document) => outFileDocumentErrors(document),
    AOSR: (document) => inAOSRDocumentError(document),
};
