import moment from "moment";
import { last } from "lodash";

import { PREVIEW_MODULES } from "../../construction_control/base/widgets/DocumentPreviewColumn/previewModules";
import { DOCUMENT_STATUS } from "../../construction_control/base/constants/statuses";
import { dateFormat, dateFormatServer } from "../../shared/constants/dateFormats";

const genStatus = (status, deadline) => {
    if (status === DOCUMENT_STATUS.NEW && moment(deadline).isBefore(moment(), "day")) {
        return "expired";
    }

    return status;
};

export const inFileDocument = (document) => ({
    id: document.sid,
    title: document.file_name,
    ext: document.file_ext,
    description: document.comment,
    size: document.size,
    link: document.file,
    isDownloaded: false,
    isFavorite: false,
    date: moment(document.upload_date),
    author: document.author.full_name,
});

export const inActDocument = (document, date, prescription) => {
    if (prescription) {
        // eslint-disable-next-line no-param-reassign
        document.prescription = prescription;
    }
    const prescription_date = moment(document.prescription.project_document.creation_date);

    return {
        id: document.sid,
        number: document.act_number,
        location: document.prescription.object_name,
        date_text: date.format("DD.MM.YYYY"),
        code: document.prescription.object_cipher,
        title: `Акт-уведомление об устранении ${document.act_number} от ${date.format("DD.MM.YYYY")}`,
        description: `На предписание ${document.prescription.prescription_number} от ${prescription_date.format("DD.MM.YYYY")}.\n ${document.description}`,
        work_description: document.description,
        date,
        deadline: moment(document.deadline_date),
        geotagsCount: document.project_document && document.project_document.geo_markers && document.project_document.geo_markers.length,
        commentsCount: document.comments_count,
        filesCount: document.file_documents && document.file_documents.length,
        dateOfCompletion: moment(document.deadline_date), // TODO: fix on the backend!!!
        isFavorite: false, // TODO: implement
        isDownloaded: true, // TODO: implement,
        as_prescribed: prescription || document.prescription,
        prescription: prescription || (document.prescription && {
            // eslint-disable-next-line no-use-before-define
            ...inPrescriptionDocument(document.prescription, prescription_date),
            type: "prescription",
        }),
        issued_by_full: document.author,
        markers: document.project_document.geo_markers,
        file_documents: document.file_documents,

        // TODO: some fields are probably missing
    };
};

export const inPrescriptionDocument = (document, date) => {
    const acts = document.acts.map((it) => (
        {
            ...inActDocument(it, moment(it.project_document.creation_date), document),
            type: "act",
        }
    ));

    const copies = document.receivers.map((ppl) => ({
        organization: ppl.company.sid,
        position: ppl.sid,
    }));

    const dateOfCompletion = document.resolved_at;

    // if (acts.length > 0) {
    //     const latestAct = last(acts);
    //     dateOfCompletion = latestAct.dateOfCompletion;
    // }

    return {
        id: document.sid,
        number: document.prescription_number,
        location: document.object_name,
        code: document.object_cipher,
        date_text: date.format("DD.MM.YYYY"),
        date,
        issued_by_full: document.author,

        issued_to_full: document.accepted_by.company,
        issued_to: document.accepted_by.company.name,

        issued_with_company: document.representative_company,
        issued_with_company_full: document.representative_company,

        issued_with_full: document.representative_user,
        issued_with: document.representative_user && document.representative_user.full_name,

        title: `Предписание ${document.prescription_number} от ${date.format(`${dateFormat} HH:mm`)}`,
        cause: document.cause && document.cause.toLowerCase(),
        since: document.period_from,
        by: document.period_to,
        description: document.summary,
        criticality: document.criticality,
        by_order: document.by_order,
        specific_item: document.claim_item,
        assignee_full: document.accepted_by,
        assignee: document.accepted_by && document.accepted_by.full_name,
        acts,
        file_documents: document.file_documents,
        informed: "", // TODO: implement
        status: document.status && genStatus(document.status.toLowerCase(), document.deadline_date),
        suggested_solution: document.proposed_measures,
        issue_categories: document.violation_category,
        issue_categories_other: document.other_violation_category,
        icon: "?", // TODO: implement
        deadline: moment(document.deadline_date).toDate(),
        dateOfCompletion,
        geotagsCount: document.project_document && document.project_document.geo_markers && document.project_document.geo_markers.length,
        commentsCount: document.comments_count,
        // TODO: possibly make a short version
        filesCount: document.file_documents && document.file_documents.length,
        isFavorite: false, // TODO: implement
        isDownloaded: true, // TODO: implement,
        checked_status_author: document.checked_status_author,
        rescheduled_times: document.rescheduled_times,
        copies,
        markers: document.project_document.geo_markers,
    };
};

export const inRemarkDocument = (document, date) => ({
    id: document.sid,
    number: document.remark_number,
    location: document.object_name,
    code: document.object_cipher,
    date_text: date.format("DD.MM.YYYY"),

    issued_by_full: document.author,
    issued_to_full: document.assigned_company,
    issued_to: document.assigned_company && document.assigned_company.name,

    issued_with: document.representative_user,
    issued_with_full: document.representative_user,

    issued_with_company: document.representative_user && document.representative_user.company,
    issued_with_company_full: document.representative_user && document.representative_user.company,

    title: `Замечание ${document.remark_number} от ${date.format("DD.MM.YYYY")}`,
    status: document.status && genStatus(document.status.toLowerCase(), document.deadline_date),
    suggested_solution: document.proposed_measures,
    description: document.description,
    date,
    deadline: moment(document.deadline_date),
    dateOfCompletion: moment(document.deadline_date), // TODO: fix on the backend!!!
    geotagsCount: document.project_document && document.project_document.geo_markers && document.project_document.geo_markers.length,
    commentsCount: document.comments_count,
    filesCount: document.file_documents && document.file_documents.length,
    isFavorite: false, // TODO: implement
    isDownloaded: true, // TODO: implement,
    checked_status_author: document.checked_status_author,
    markers: document.project_document.geo_markers,
    person_full: document.responsible_user,
    person: document.responsible_user && document.responsible_user.sid,
    file_documents: document.file_documents,

});

export const inAOSRDocument = (document) => {
    const { responsible, inspectors } = document.signatures;
    const signatures = {
        ...responsible,
        ...inspectors,
    };

    return {
        // list
        id: document.sid,
        title: `АОСР ${document.act_number} от ${moment(document.act_date).format(dateFormat)}`,
        status: document.status,
        company: document.work_activity && document.work_activity.contractor.name,
        description: document.job_description_and_scope, // Описание работ и объёмы
        subscriptionDate: document.complete_signed_date && moment(document.complete_signed_date).format(dateFormat),
        commentsCount: document.comments_count,
        filesCount: document.file_documents && document.file_documents.length,
        geotagsCount: document.project_document && document.project_document.geo_markers && document.project_document.geo_markers.length,
        // view
        author: document.author,
        development_executor: document.development_executor && document.development_executor.sid,
        markers: document.project_document && document.project_document.geo_markers,
        file_documents: document.file_documents,
        module: PREVIEW_MODULES.EXECUTIVE_DOCUMENTATION,
        development_executor_representative: document.development_executor_representative && document.development_executor_representative.sid, // Представитель лица, осуществляющего строительство
        development_executor_cc_representative: document.development_executor_cc_representative && document.development_executor_cc_representative.sid, // Представитель лица осуществляющего строительство, по вопросам строительного контроля
        documentation_preparer_representative: document.documentation_preparer_representative && document.documentation_preparer_representative.sid, // Представитель лица осуществляющего подготовку проектной документации
        work_executor_representative: document.work_executor_representative && document.work_executor_representative.sid, // Представитель лица, выполнившего работы, подлежащие освидетельствованию
        signatures,
        // form
        developer: document.developer && document.developer.sid, // застройщик
        documentation_preparer: document.documentation_preparer && document.documentation_preparer.sid, // Лицо осуществляющее подготовку проектной документации
        act_date: moment(document.act_date).format(dateFormat), // дата создания акта
        main_cc_specialist: document.main_cc_specialist && document.main_cc_specialist.sid, // главный специалист по строительному контролю
        cc_contractor: document.cc_contractor && document.cc_contractor.sid, // подрядчик по строительному контролю
        inspectors: document.inspectors && document.inspectors.map((ppl) => ({
            organization: ppl.company.sid,
            position: ppl.sid,
        })), // Иные представители лиц учавствующих в освидетельствовании
        project_documentation: document.project_documentation, // Проектная документация работ
        main_project_engineer: document.main_project_engineer && document.main_project_engineer.sid, // Главный инженер проектов
        applied_at_execution: document.applied_at_execution, // При выполнении работ применены
        correspondence_documents: document.correspondence_documents, // Предъявлены документы, подтверджающие соответствие работ предъявляемым к ним требованиям
        work_start_date: moment(document.work_start_date), // Дата начала работ
        work_end_date: moment(document.work_end_date), // Дата окончания работ
        work_permitted: document.work_permitted, // Разрешается производство последующих работ
        additional_info: document.additional_info, // Дополнительные сведения
        applications: document.applications, // Приложения
        work_activity: document.work_activity, // Строка таблицы КСГ
    };
};

// ------------ out

export const outPrescriptionDocument = (document) => {
    const copies = document.copies && document.copies.filter((it) => it.organization || it.position);

    return {
        sid: document.id,
        prescription_number: document.number,
        related_category: document.related_category,
        object_name: document.location,
        object_cipher: document.code,
        representative_company: document.issued_with_company,
        representative_user: document.issued_with,
        cause: document.cause && document.cause.toUpperCase(),
        period_from: document.since ? (moment(document.since).format("YYYY-MM-DD")) : undefined,
        period_to: document.by ? (moment(document.by).format("YYYY-MM-DD")) : undefined,
        summary: document.description,
        criticality: document.criticality,
        by_order: document.by_order,
        claim_item: document.specific_item,
        accepted_by: document.assignee,
        status: document.status && (document.status === "expired" ? "NEW" : document.status.toUpperCase()),
        proposed_measures: document.suggested_solution,
        violation_category: document.issue_categories,
        other_violation_category: document.issue_categories_other,
        deadline_date: document.deadline ? (moment(document.deadline).format("YYYY-MM-DD")) : undefined,
        // isFavorite: false, // TODO: implement
        file_documents: document.file_documents,
        file_documents_remove: document.file_documents_remove,
        receivers: copies && copies.map((item) => item.position),
    };
};

export const outActDocument = (document) => ({
    sid: document.id,
    related_category: document.related_category,
    act_number: document.number,
    description: document.work_description,
    act_date: document.act_date ? (moment(document.act_date).format("YYYY-MM-DD")) : undefined,
    prescription: document.as_prescribed,
    // isFavorite: false, // TODO: implement
    file_documents: document.file_documents,
    file_documents_remove: document.file_documents_remove,
    isDownloaded: true, // TODO: implement,
});

export const outRemarkDocument = (document) => ({
    sid: document.id,
    related_category: document.related_category,
    assigned_company: document.issued_to,
    // representative_company: document.issued_with_company,
    representative_user: document.issued_with,
    object_name: document.location,
    object_cipher: document.code,
    remark_number: document.number,
    status: document.status && (document.status === "expired" ? "NEW" : document.status.toUpperCase()),
    description: document.description,
    proposed_measures: document.suggested_solution,
    responsible_user: document.person,
    deadline_date: document.deadline ? (moment(document.deadline).format("YYYY-MM-DD")) : undefined,
    // isFavorite: false, // TODO: implement
    file_documents: document.file_documents,
    file_documents_remove: document.file_documents_remove,
    isDownloaded: true, // TODO: implement,
});

export const outFileDocument = (document) => ({
    comment: document.description,
});

export const outAOSRDocument = (document) => {
    const copies = document.inspectors && document.inspectors.filter((it) => it.organization || it.position);

    return {
        sid: document.id,
        status: document.status,
        author: document.author,
        file_documents: document.file_documents,
        related_category: document.related_category,
        file_documents_remove: document.file_documents_remove,
        applications: document.applications,
        main_cc_specialist: document.main_cc_specialist,
        cc_contractor: document.cc_contractor,
        inspectors: copies && copies.map((item) => item.position),
        project_documentation: document.project_documentation,
        main_project_engineer: document.main_project_engineer,
        applied_at_execution: document.applied_at_execution,
        correspondence_documents: document.correspondence_documents,
        work_start_date: document.work_start_date ? (moment(document.work_start_date).format(dateFormatServer)) : undefined,
        work_end_date: document.work_end_date ? (moment(document.work_end_date).format(dateFormatServer)) : undefined,
        work_permitted: document.work_permitted,
        additional_info: document.additional_info,
        act_number: document.name,
        representative_general_contractor: document.representative_general_contractor,
        lists: document.lists,
        work_completed_according_ntd: document.work_accordance,
        development_executor_cc_representative: document.representative_сс,
        documentation_preparer_representative: document.documentation_preparer_representative,
        job_description_and_scope: `${document.work_activity.title} ${document.work_activity.accumulated} ${document.work_activity.unit}`,
        signed: document.signed,
        work_activity: document.work_activity.sid,
        developer_representative: document.developer_representative,
    };
};

// ---- errors

export const inPrescriptionDocumentErrors = (document) => ({
    id: document.sid,
    number: document.prescription_number,
    location: document.object_name,
    code: document.object_cipher,

    issued_to: document.accepted_by,
    assignee: document.accepted_by,

    issued_with_company: document.representative_company,
    issued_with: document.representative_user,

    cause: document.cause,
    since: document.period_from,
    by: document.period_to,
    description: document.summary,
    criticality: document.criticality,
    by_order: document.by_order,
    specific_item: document.claim_item,
    informed: "", // TODO: implement
    document: "", // TODO: what is this?
    status: document.status,
    suggested_solution: document.proposed_measures,
    icon: "?", // TODO: implement
    deadline: document.deadline_date,
    dateOfCompletion: document.deadline_date, // TODO: fix on the backend!!!
    copies: document.receivers,
    // isFavorite: false, // TODO: implement
    // isDownloaded: true // TODO: implement,
});

export const inActDocumentErrors = (document) => ({
    id: document.sid,
    number: document.act_number,
    // work_description: document.description,
    description: document.description,
    act_date: document.act_date,
    as_prescribed: document.prescription,
});

export const inRemarkDocumentErrors = (document) => ({
    id: document.sid,
    number: document.remark_number,
    location: document.object_name,
    code: document.object_cipher,
    status: document.status,

    issued_to: document.assigned_company,

    issued_with_company: document.representative_company,
    issued_with: document.representative_user,
    suggested_solution: document.proposed_measures,
    description: document.description,
    deadline: document.deadline_date,
    person: document.responsible_user,
});

export const outFileDocumentErrors = (document) => ({
    comment: document.description,
});

export const inAOSRDocumentError = (document) => ({
    ...document,
    name: document.act_number,
});
