import { put, takeEvery } from "@redux-saga/core/effects";
import { documentsCRUDActions } from "../actions/actions";

export function* documentsSaga() {
    function* watchDocumentCreated({ payload }) {
        if (payload.item.type === "act") {
            // TODO: maybe just emulate prescription entity update complete
            yield put(documentsCRUDActions.use.GET_ENTITY_DETAILS({
                source: {
                    ...payload.item.prescription,
                    project: payload.source.project,
                },
            }));
        }
    }

    yield takeEvery(documentsCRUDActions.CREATE_ENTITY_COMPLETE, watchDocumentCreated);
}
