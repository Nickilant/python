import React from "react";
import cx from "classnames";

import "./styles.scss";

export const SectionDocumentSort = (props) => {
    const {
        sortParams,
        orderBy,
    } = props;

    const getClassNameForSorting = (attribute) => {
        const isActive = sortParams.attribute === attribute;
        const { order } = sortParams;
        return cx(attribute, order, isActive ? "active" : null);
    };

    const handleOrderBy = (attribute) => () => {
        const order = (sortParams.order === "asc" && attribute === sortParams.attribute) ? "desc" : "asc";
        orderBy(attribute, order);
    };

    return (
        <div className="sort">
            <div className={getClassNameForSorting("type")} onClick={handleOrderBy("type")} />
            <div className={getClassNameForSorting("title")} onClick={handleOrderBy("title")}>Имя</div>
            <div className={getClassNameForSorting("date")} onClick={handleOrderBy("date")}>Дата</div>
            <div className={getClassNameForSorting("size")} onClick={handleOrderBy("size")}>Размер</div>
        </div>
    );
};
