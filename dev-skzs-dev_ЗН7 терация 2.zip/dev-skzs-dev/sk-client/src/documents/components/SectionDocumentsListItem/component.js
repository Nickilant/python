import React from "react";
import cx from "classnames";
import "./styles.scss";
import { calcFileSize } from "../../../shared/helpers/calcFileSize";
import { FileIcon } from "../FileIcon/component";

export const SectionDocumentListItem = ({
    item, onSelect = () => null, currentItem, removeFile, showActions = true,
}) => {
    const {
        title = "",
        description = "",
        // isFavorite = false,
        // isDownloaded = false,
        size = null,
        disabled = null,
        link = "#",
        ext = null,
        date,
    } = item;

    const handleRemoveFile = () => {
        removeFile(item);
    };

    return (
        <div className={cx("section-document-list-item", { disabled, active: currentItem })}>
            { ext && <a href={link} target="_blank" rel="noopener noreferrer"><FileIcon ext={ext} /></a> }
            <div className="info" onClick={() => onSelect(item.id)}>
                <div className="title">
                    {title}
                    {/* <div className="icons"> */}
                    {/*   <span */}
                    {/*       title={`Файл ${isDownloaded */}
                    {/*           ? "находится на устройстве" */}
                    {/*           : "не скачан. Нажмите чтобы скачать"}`} */}
                    {/*       className={cx("icon", "bg-img", isDownloaded */}
                    {/*           ? "downloaded" */}
                    {/*           : "notDownloaded")} */}
                    {/*   /> */}
                    {/*   <span */}
                    {/*       className={cx("icon", "bg-img", isFavorite */}
                    {/*           ? "favorite" */}
                    {/*           : "notFavorite")} */}
                    {/*   /> */}
                    {/* </div> */}
                </div>
                <div className="description">{description}</div>
            </div>
            <div className="date">{date && date.format("DD.MM.YYYY HH:mm")}</div>
            {
                showActions && removeFile && (
                    <div className="actions">
                        <div onClick={handleRemoveFile} className={cx("icon", "bg-img", "remove")} />
                    </div>
                )
            }
            { size && <div className="size-badge">{calcFileSize(size)}</div> }
        </div>
    );
};
