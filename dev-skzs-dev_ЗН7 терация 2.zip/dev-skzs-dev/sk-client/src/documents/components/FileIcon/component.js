import React from "react";
import "./styles.scss";

export const FileIcon = ({ ext }) => <div className="bg-img icon file">{ext.toUpperCase()}</div>;
