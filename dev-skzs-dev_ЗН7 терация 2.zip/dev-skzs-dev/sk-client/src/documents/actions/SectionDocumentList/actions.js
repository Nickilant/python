import {
    SECTION_DOCUMENT_FILE_SET_DESCRIPTION, SECTION_DOCUMENT_FILE_SET_USERS,
    SECTION_DOCUMENT_FORM_CLOSE,
    SECTION_DOCUMENT_FORM_UPLOAD,
    SECTION_DOCUMENT_FORM_UPLOAD_FAILED,
    SECTION_DOCUMENT_LIST_ORDER_BY,
    SECTION_DOCUMENT_LIST_SEARCH,
    SECTION_DOCUMENT_LIST_TOGGLE_ALL,
    SECTION_DOCUMENT_LIST_TOGGLE_ATTRIBUTE,
    SECTION_DOCUMENT_SET_UPLOADING_LIST,
} from "./actionTypes";

export const orderByAction = (attribute, order) => ({
    type: SECTION_DOCUMENT_LIST_ORDER_BY,
    payload: {
        attribute, order,
    },
});

export const searchDocumentsAction = (query) => ({
    type: SECTION_DOCUMENT_LIST_SEARCH,
    payload: {
        query,
    },
});

export const toggleAttributeAction = (ext) => ({
    type: SECTION_DOCUMENT_LIST_TOGGLE_ATTRIBUTE,
    payload: {
        ext,
    },
});

export const toggleAllAction = () => ({
    type: SECTION_DOCUMENT_LIST_TOGGLE_ALL,
});

export const setDescriptionAction = ({ id, text }) => ({
    type: SECTION_DOCUMENT_FILE_SET_DESCRIPTION,
    payload: {
        id,
        text,
    },
});

export const setUsersAction = ({ id, users }) => ({
    type: SECTION_DOCUMENT_FILE_SET_USERS,
    payload: {
        id,
        users,
    },
});

export const setUploadingListAction = (files) => ({
    type: SECTION_DOCUMENT_SET_UPLOADING_LIST,
    payload: { files },
});

export const uploadFormAction = (project, section, files) => ({
    type: SECTION_DOCUMENT_FORM_UPLOAD,
    payload: { project, section, files },
});

export const uploadFormFailedAction = (project, section, file) => ({
    type: SECTION_DOCUMENT_FORM_UPLOAD_FAILED,
    payload: { project, section, file },
});

export const closeFormAction = () => ({
    type: SECTION_DOCUMENT_FORM_CLOSE,
});
