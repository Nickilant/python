import { getCRUDEntityActions } from "../../shared/actions/entityCrudActions";

export const documentsCRUDActions = getCRUDEntityActions("documents", "document");
