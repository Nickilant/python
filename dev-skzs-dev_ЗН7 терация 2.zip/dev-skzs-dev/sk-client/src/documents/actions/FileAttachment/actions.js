import {
    FILE_ATTACHMENT_DOCUMENT_LIST_ATTACH,
    FILE_ATTACHMENT_DOCUMENT_LIST_DETACH,
    FILE_ATTACHMENT_DOCUMENT_LIST_ORDER_BY,
    FILE_ATTACHMENT_DOCUMENT_LIST_SEARCH,
    FILE_ATTACHMENT_FORM_CLOSE,
    FILE_ATTACHMENT_FORM_OPEN,
    FILE_ATTACHMENT_FORM_SELECT_SECTION,
} from "./actionTypes";

export const openAttachmentFormAction = (entity) => ({
    type: FILE_ATTACHMENT_FORM_OPEN,
    payload: {
        entity,
    },
});

export const closeAttachmentFormAction = () => ({
    type: FILE_ATTACHMENT_FORM_CLOSE,
});

export const selectSectionAction = (sid) => ({
    type: FILE_ATTACHMENT_FORM_SELECT_SECTION,
    payload: {
        sid,
    },
});

export const orderByAction = (attribute, order) => ({
    type: FILE_ATTACHMENT_DOCUMENT_LIST_ORDER_BY,
    payload: {
        attribute, order,
    },
});

export const searchDocumentsAction = (query) => ({
    type: FILE_ATTACHMENT_DOCUMENT_LIST_SEARCH,
    payload: {
        query,
    },
});

export const attachDocumentAction = (id) => ({
    type: FILE_ATTACHMENT_DOCUMENT_LIST_ATTACH,
    payload: {
        id,
    },
});

export const detachDocumentAction = (id) => ({
    type: FILE_ATTACHMENT_DOCUMENT_LIST_DETACH,
    payload: {
        id,
    },
});
