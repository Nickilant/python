export const selectCurrentProjectFiles = (state) => Object.values(state.documents.crud.items).filter((it) => it.type === "file");

export const selectCurrentProjectDocuments = (state) => Object.values(state.documents.crud.items).filter((it) => !["file", "map"].includes(it.type));

export const selectedDocumentView = (state) => state.documents.crud.items[state.documents.crud.selectedKey];

export const search = (array, query, attributes = {}, showAll = false) => {
    const searchResultByQuery = array.filter((item) => {
        const searchStr = query.toLowerCase();
        const searchItem = item.title.toLowerCase();

        return 1 + searchItem.indexOf(searchStr);
    });

    if (!showAll) {
        const selectedAttributes = Object.keys(attributes).filter((key) => attributes[key]);
        return searchResultByQuery.filter(
            (item) => selectedAttributes.includes(item.ext),
        );
    }

    return searchResultByQuery;
};

export const sort = (array, sortParams) => {
    const result = array.slice();
    const { attribute, order } = sortParams;
    const orderNum = order === "asc" ? 1 : -1;

    result.sort((a, b) => {
        let aVal;
        let bVal;

        if (typeof a[attribute] === "string") {
            aVal = (a[attribute] || "").toLowerCase();
        } else {
            aVal = a[attribute];
        }
        if (typeof b[attribute] === "string") {
            bVal = (b[attribute] || "").toLowerCase();
        } else {
            bVal = b[attribute];
        }

        if (aVal > bVal) {
            return orderNum;
        } if (aVal < bVal) {
            return -1 * orderNum;
        }
        return 0;
    });
    return result;
};
export const filterByGroup = (array, groups) => array.filter((item) => groups.includes(item.group));

export const selectActiveEntity = (state) => state.shared.rightColumn.context;
