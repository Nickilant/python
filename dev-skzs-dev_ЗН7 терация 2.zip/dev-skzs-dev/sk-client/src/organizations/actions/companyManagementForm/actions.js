import {
    CHANGE_INPUT_VALUE_IN_FORM,
    CLOSE_DIVIDER,
    CLOSE_MANAGEMENT_FORM,
    OPEN_DIVIDER,
    OPEN_MANAGEMENT_FORM,
    SET_COMPANY_FORM,
} from "./actionTypes";

export const changeInputAction = (input) => ({
    type: CHANGE_INPUT_VALUE_IN_FORM,
    payload: input,
});

export const openDividerAction = (dividerId) => ({
    type: OPEN_DIVIDER,
    payload: dividerId,
});

export const closeDividerAction = (dividerId) => ({
    type: CLOSE_DIVIDER,
    payload: dividerId,
});

export const openFormAction = () => ({
    type: OPEN_MANAGEMENT_FORM,
});

export const closeFormAction = () => ({
    type: CLOSE_MANAGEMENT_FORM,
});

export const setCompanyFormAction = (companyInfo) => ({
    type: SET_COMPANY_FORM,
    payload: companyInfo,
});
