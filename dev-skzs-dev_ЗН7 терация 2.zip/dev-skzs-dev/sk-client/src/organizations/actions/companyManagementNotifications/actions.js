import {
    CHANGE_NOTIFICATION_VALUE,
    CLOSE_NOTIFICATION_BLOCK,
    DISABLED_COMPANY_NOTIFICATIONS_EDIT,
    ENEBALED_COMPANY_NOTIFICATIONS_EDIT,
    OPEN_NOTIFICATION_BLOCK,
    SET_COMPANY_NOTIFICATIONS,
} from "./actionTypes";

export const changeNotificationValueAction = (options) => ({
    type: CHANGE_NOTIFICATION_VALUE,
    payload: options,
});

export const openNotificationBlockAction = () => ({
    type: OPEN_NOTIFICATION_BLOCK,
});

export const closeNotificationBlockAction = () => ({
    type: CLOSE_NOTIFICATION_BLOCK,
});

export const setCompanyNotificationsAction = (companyInfo) => ({
    type: SET_COMPANY_NOTIFICATIONS,
    payload: companyInfo,
});

export const enableEditAction = () => ({
    type: ENEBALED_COMPANY_NOTIFICATIONS_EDIT,
});

export const disableEditAction = () => ({
    type: DISABLED_COMPANY_NOTIFICATIONS_EDIT,
});
