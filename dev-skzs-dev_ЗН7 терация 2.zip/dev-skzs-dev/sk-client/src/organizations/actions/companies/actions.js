import {
    ORGANIZATIONS_CHANGE_SEARCH_VALUE,
} from "./actionTypes";

export const changeSearchAction = (val) => ({
    type: ORGANIZATIONS_CHANGE_SEARCH_VALUE,
    payload: val,
});
