// TODO: just move to actions man
import { getCRUDEntityActions } from "../../shared/actions/entityCrudActions";

export const organizationsCRUDActions = getCRUDEntityActions("organizations", "company");
