export const MODULE_NAME = "events";
export const ENTITY_NAME = "event";
export const PROJECT_ENTITY_NAME = "project_event";
