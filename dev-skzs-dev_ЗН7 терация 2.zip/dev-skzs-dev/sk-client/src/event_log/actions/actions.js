import { getCRUDEntityActions } from "../../shared/actions/entityCrudActions";
import { ENTITY_NAME, MODULE_NAME, PROJECT_ENTITY_NAME } from "../constants/events";

export const projectEventsCRUDActions = getCRUDEntityActions(MODULE_NAME, PROJECT_ENTITY_NAME);
export const eventsCRUDActions = getCRUDEntityActions(MODULE_NAME, ENTITY_NAME);
