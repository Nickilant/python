import React from "react";

import "./styles.scss";
import moment from "moment";
import { timeFormat, dateFormat } from "../../../shared/constants/dateFormats";

export const EventListItem = (props) => {
    const {
        body,
        creation_date,
        user,
    } = props;

    return (
        <div className="event">
            {/* <div className="title"> */}
            {/*    <div className="icon"> */}
            {/*        <img src={icon} alt="Документ" /> */}
            {/*    </div> */}
            {/*    /!*{body}*!/ */}
            {/*    /!*{favorite && <div className="favorite" />}*!/ */}
            {/* </div> */}
            <div className="timestamp">
                {moment(creation_date).format(`${dateFormat} ${timeFormat}`)}
            </div>
            <div className="desc">
                {body}
            </div>
            {
                user && (
                    <div className="author">
                        <div className="avatar">
                            <img src={user.avatar} alt="Аватар" />
                        </div>
                        <div className="author-info">
                            {user.position}
                            {" "}
                            {user.company.name}
                            ,
                            {" "}
                            <b>{user.full_name}</b>
                        </div>
                    </div>
                )
            }
        </div>
    );
};
