import React, { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { DatePicker, TimePicker } from "antd";
import moment from "moment";
import { pickBy } from "lodash";
import cx from "classnames";

import { Search } from "../../../shared/components/Search/component";
import { projectEventsCRUDActions } from "../../actions/actions";
import {
    dateFormat, dateFormatServer, timeFormat, timeFormatServer,
} from "../../../shared/constants/dateFormats";

import "./styles.scss";

const queryMapping = (opt) => ({
    start_date: opt.start_date && moment(opt.start_date).format(dateFormatServer),
    start_time: opt.start_time && moment(opt.start_time).format(timeFormatServer),
    end_date: opt.end_date && moment(opt.end_date).format(dateFormatServer),
    end_time: opt.end_time && moment(opt.end_time).format(timeFormatServer),
    search: opt.search || null,
});

export const TopPanel = ({ project }) => {
    const dispatch = useDispatch();
    const [options, setOptions] = useState({});

    const changeOptions = (el) => (e) => {
        setOptions((prev) => ({
            ...prev,
            [el]: e,
        }));
    };

    const handleChangeTemplate = (toVal) => {
        changeOptions("end_date")(moment());
        changeOptions("start_date")(toVal);
    };

    useEffect(() => {
        const derivedOptions = pickBy(queryMapping(options), (v) => v !== undefined && v !== null);

        dispatch(projectEventsCRUDActions.use.LIST_ENTITIES({
            source: {
                project: { key: project },
            },
            query: {
                ...derivedOptions,
            },
        }));
    }, [options, dispatch, project]);

    return (
        <div className="top-panel">
            <div className="main-title">
                Журнал действий
            </div>
            <div className="basic-date-filters">
                <div
                    onClick={() => handleChangeTemplate(moment())}
                    className={cx("template", {
                        active: moment(options.end_date).diff(moment(options.start_date), "days") === 0,
                    })}
                >
                    За сегодня
                </div>
                <div
                    onClick={() => handleChangeTemplate(moment().subtract(3, "days"))}
                    className={cx("template", {
                        active: moment(options.end_date).diff(moment(options.start_date), "days") === 3,
                    })}
                >
                    За последние три дня
                </div>
                <div
                    onClick={() => handleChangeTemplate(moment().subtract(7, "days"))}
                    className={cx("template", {
                        active: moment(options.end_date).diff(moment(options.start_date), "days") === 7,
                    })}
                >
                    За неделю
                </div>
            </div>
            <div className="date-filters">
                <div className="filter-block">
                    <div className="title">
                        Показать от
                    </div>
                    <DatePicker
                        placeholder="ДД.ММ.ГГГГ"
                        className="date"
                        format={dateFormat}
                        onChange={changeOptions("start_date")}
                        value={options.start_date}
                    />
                    <TimePicker
                        className="time"
                        suffixIcon={<div />}
                        onChange={changeOptions("start_time")}
                        format={timeFormat}
                        placeholder="ЧЧ:ММ"
                        value={options.start_time}
                    />
                </div>
                <div className="filter-block">
                    <div className="title">
                        До
                    </div>
                    <DatePicker
                        placeholder="ДД.ММ.ГГГГ"
                        className="date"
                        format={dateFormat}
                        onChange={changeOptions("end_date")}
                        value={options.end_date}
                    />
                    <TimePicker
                        className="time"
                        suffixIcon={<div />}
                        onChange={changeOptions("end_time")}
                        format={timeFormat}
                        placeholder="ЧЧ:ММ"
                        value={options.end_time}
                    />
                </div>
            </div>
            <Search placeholder="Что ищем?" allowClear onSearch={changeOptions("search")} />
        </div>
    );
};
