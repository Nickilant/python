import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";

import { projectEventsCRUDActions } from "../../actions/actions";
import { EventList } from "../../containers/EventList/container";
import { projectEvents } from "../../selectors/events";
import { TopPanel } from "../../components/TopPanel/component";

import "./styles.scss";

export const EventLogPage = (props) => {
    const dispatch = useDispatch();

    const { project_sid } = props.match.params;

    useEffect(() => {
        dispatch(projectEventsCRUDActions.use.LIST_ENTITIES({
            source: {
                project: { key: project_sid },
            },
        }));
    }, [project_sid, dispatch]);

    const events = useSelector(projectEvents);

    return (
        <div className="event-log-module event-log-page">
            <TopPanel project={project_sid} />
            <EventList events={events} />
        </div>
    );
};
