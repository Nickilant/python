import { all } from "@redux-saga/core/effects";
import { createCRUDSaga } from "../../shared/sagas/entityCrudFactory";
import { ENTITY_NAME, MODULE_NAME, PROJECT_ENTITY_NAME } from "../constants/events";

const projectEventsCrudSaga = createCRUDSaga({
    moduleName: MODULE_NAME,
    entityName: PROJECT_ENTITY_NAME,
    idField: "sid",

    getPrefixPath: ({ payload }) => `/projects/${payload.source.project.key}/events`,
});

const eventsCrudSaga = createCRUDSaga({
    moduleName: MODULE_NAME,
    entityName: ENTITY_NAME,
    idField: "sid",

    getPrefixPath: ({ payload }) => `/projects/${payload.source.project.key}/${payload.source.entity.type}s/${payload.source.entity.id}/${MODULE_NAME}`,
});

export function* eventsRootSaga() {
    yield all([
        projectEventsCrudSaga(),
        eventsCrudSaga(),
    ]);
}
