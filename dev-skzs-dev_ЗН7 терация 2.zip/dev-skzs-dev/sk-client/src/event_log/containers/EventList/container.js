import React from "react";

import { EventListItem } from "../../components/EventListItem/component";

import "./styles.scss";

export const EventList = ({ events }) => (
    <div className="event-list">
        {
            events.map((event) => (<EventListItem key={event.sid} {...event} />))
        }
    </div>
);
