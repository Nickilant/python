import { combineReducers } from "redux";
import { crudReducerFactory } from "../../shared/reducers/crudFactory";
import { ENTITY_NAME, MODULE_NAME, PROJECT_ENTITY_NAME } from "../constants/events";

export const eventsReducers = combineReducers({
    project: crudReducerFactory(MODULE_NAME, PROJECT_ENTITY_NAME, "sid"),
    document: crudReducerFactory(MODULE_NAME, ENTITY_NAME, "sid"),
});
