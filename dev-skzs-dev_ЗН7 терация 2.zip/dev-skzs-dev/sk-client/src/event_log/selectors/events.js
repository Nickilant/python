export const projectEvents = (state) => Object.values(state.events.project.items);
export const entityEvents = (state) => Object.values(state.events.document.items);
