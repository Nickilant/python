# Activities

> КСГ - календарно-сетевой график, динамическая модель производственного процесса, отражающая технологическую зависимость и последовательность выполнения комплекса работ, связывающая их свершение во времени с учётом затрат ресурсов и стоимости работ с выделением при этом узких (критических) мест. 


## Component structure
```
Activities
├── TreeStructure
├── TableActions
└── Table
    ├── Header 
    ├── SubHeader
    │   ├── InfoActions
    │   └── CalendarHeader
    │
    ├── Activity
    │   ├── BasicInfo
    │   ├── GeneralInfo
    │   └── Calendar
    │
    ├── ActivityCategory
    │   ├── BasicInfo
    │   ├── GeneralInfo
    │   └── Calendar
    │
    └── ActivityMarker   
``` 
