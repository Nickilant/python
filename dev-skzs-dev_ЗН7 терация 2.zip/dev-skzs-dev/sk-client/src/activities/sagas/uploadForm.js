import axios from "axios";
import {
    all, call, put, takeEvery,
} from "redux-saga/effects";
import { ACTIVITIES_FILES } from "../actions/actionTypes";
import { setUploadingListAction } from "../../documents/actions/SectionDocumentList/actions";
import { uploadActivityFormCompleteAction } from "../actions/actions";
import { removeFromStackInRightColumnContainerAction } from "../../shared/actions/RightColumnContainer/actions";

function* formUpload({ payload }) {
    const {
        project, category, activity, files,
    } = payload;

    // eslint-disable-next-line no-restricted-syntax
    for (const it of files) {
        try {
            const formData = new FormData();

            formData.append("related_category", category);
            formData.append("related_activity", activity);

            formData.append("file", it.raw_file);
            formData.append("comment", it.description);
            formData.append("users", it.users);

            // TODO: api for file upload to?
            yield call(axios.post, `/projects/${project}/files/`, formData);
        } catch (e) {
            // TODO: handle failures properly
            // yield put(uploadFormFailedAction(project, section, it));
        }
    }

    yield put(setUploadingListAction([]));
    yield put(removeFromStackInRightColumnContainerAction());
    yield put(uploadActivityFormCompleteAction(project, category, activity, files));
}

function* afterUploadFormComplete() {
    // yield put(fetchDocumentsAction(payload.project.project));
}

function* watchUploadFormAction() {
    yield takeEvery(ACTIVITIES_FILES.UPLOAD_FORM, formUpload);
}

function* watchUploadFormCompleteAction() {
    yield takeEvery(ACTIVITIES_FILES.UPLOAD_FORM_COMPLETE, afterUploadFormComplete);
}

export function* activitiesUploadFormCombinedSaga() {
    yield all([
        watchUploadFormAction(),
        watchUploadFormCompleteAction(),
    ]);
}
