import moment from "moment";
import { range } from "lodash";
import { TYPE } from "../constants/activities";
import store from "../../core/store";
import { dateFormat, dateFormatServer } from "../../shared/constants/dateFormats";

const convertPlan = (days, item) => {
    const { startDate } = store.getState().activities.activities;
    const period_plan_start = item.plan_work_period_start && moment(item.plan_work_period_start).startOf("day");
    const period_plan_end = item.plan_work_period_end && moment(item.plan_work_period_end).startOf("day");

    const today = moment().startOf("day");

    return range(31).map((i) => {
        const iterDate = moment(startDate).add(i, "day").startOf("day");

        const day = days.find((d) => moment(d.date).startOf("day").isSame(iterDate));

        const plan = (day && day.plan) || 0;
        const fact = (day && day.fact) || 0;

        const permissionPlanAdditionalCondition = process.env.REACT_APP_BRANCH === "dev" || iterDate.isAfter(today, "day");

        return {
            date: iterDate,
            plan,
            fact,
            sid: (day && day.sid) || `empty-${iterDate.format(dateFormatServer)}`,
            permission: {
                plan: permissionPlanAdditionalCondition && !fact && iterDate.isBetween(period_plan_start, period_plan_end, "day", "[]"),
                fact: iterDate.isSameOrBefore(today, "day") && !fact && plan,
            },
        };
    });
};

const convertActivityItem = (item) => ({
    title: item.name, // наименование
    contractor: item.contractor,
    orderingIndex: item.ordering_index,
    unit: item.measurement_units, // Ед. изм.
    workType: item.work_activity_type,
    plan: convertPlan(item.work_activity_days, item),
});

const convertActivityCategory = (item) => {
    const isLeaf = item.subcategories && item.subcategories.length === 0;

    return {
        isLeaf,
        number: item.project_category.cipher, // шифр
        title: item.project_category.name, // наименование
        projectCategory: item.project_category,
        plan: convertPlan(item.work_activity_category_days, item),
    };
};

const convertActivity = (item, level, type) => {
    let otherActivityFields;

    // eslint-disable-next-line default-case
    switch (type) {
        case TYPE.ACTIVITY:
            otherActivityFields = convertActivityItem(item);
            break;
        case TYPE.ACTIVITY_CATEGORY:
            otherActivityFields = convertActivityCategory(item, level);
            break;
    }

    return {
        sid: item.sid,
        type,
        level,
        activityCategory: item.activity_category,
        documents: item.documents,
        status: {
            all: item.itd_status_all,
            rejected: item.itd_status_rejected,
            on_review: item.itd_status_on_review,
            done: item.itd_status_done,
        }, // Статус ИТД
        registered: item.acted_physical_volume, // Заактировано ФО
        accumulated: item.accumulated_physical_volume, // Накоплено ФО
        total: item.overall_physical_volume, // Всего ФО
        in_fact: item.fact_physical_volume, // Факт ФО (сумма всех ячеек факта)
        remainder: item.rest_pv, // Остаток ФО
        period_plan_start: item.plan_work_period_start && moment(item.plan_work_period_start).format(dateFormat),
        period_plan_end: item.plan_work_period_end && moment(item.plan_work_period_end).format(dateFormat), // Период работ План
        period_in_fact: {
            start: item.fact_work_period_start && moment(item.fact_work_period_start).format(dateFormat),
            end: item.fact_work_period_end && moment(item.fact_work_period_end).format(dateFormat),
        }, // Период работ Факт
        deviation: item.deviation, // Отклонение
        distributed: item.distributed_pv_by_days, // Распределено ФО по суткам (сумма всех ячеек плана)
        notDistributed: item.not_distributed_pv_by_days, // Не распределено ФО по суткам
        ...otherActivityFields,
    };
};

export const convertOut = (item) => {
    const orderingIndex = Math.round(item.orderingIndex);

    return {
        activity_category: item.activityCategory,
        cipher: item.number,
        measurement_units: item.unit,
        name: item.title,
        overall_physical_volume: parseInt(item.total * 100, 10) / 100 || undefined,
        plan_work_period_start: item.period_plan_start && item.period_plan_start.format(dateFormatServer),
        plan_work_period_end: item.period_plan_end && item.period_plan_end.format(dateFormatServer),
        contractor: item.contractor,
        ordering_index: isNaN(orderingIndex) ? undefined : orderingIndex,
        work_activity_type: item.workType,
    };
};

const convertMarkActivity = (item, level, position) => ({
    title: `${position} работ по марке ${item.project_category.name}`,
    level,
    position,
    number: item.project_category.cipher,
    sid: `${item.sid}-${moment().valueOf()}`,
    type: TYPE.ACTIVITY_MARKER,
});

export const listActivitiesInConverters = {
    ACTIVITY: convertActivity,
    RAW: (item) => item,
};

export const convertTree = (root) => {
    const iter = (item, level) => {
        const type = (item.work_activities ? TYPE.ACTIVITY_CATEGORY : TYPE.ACTIVITY);

        // eslint-disable-next-line prefer-const
        let newItem = convertActivity(item, level, type);

        if (item.subcategories && item.subcategories.length) {
            newItem.subcategories = item.subcategories.map((i) => iter(i, level + 1));
        } else if (item.work_activities) {
            newItem.work_activities = [];
            newItem.work_activities.push(convertMarkActivity(item, level, "Начало"));
            item.work_activities.forEach((it) => newItem.work_activities.push(iter(it, level)));
            newItem.work_activities.push(convertMarkActivity(item, level, "Окончание"));
        }

        return newItem;
    };

    return { sid: "tree", list: [iter(root, 1)] };
};

export const convertPlanOut = ({ update, create }) => ({
    days_update: JSON.stringify(update),
    days_create: JSON.stringify(create),
});

export const convertWorkActivityTypes = (items) => items.map((workType) => {
    const convertedWorkType = {
        label: workType.name,
        value: workType.sid,
    };

    if (workType.work_activity_types && workType.work_activity_types.length === 1 && workType.work_activity_types[0].name === "Не определен") {
        const item = workType.work_activity_types[0];
        convertedWorkType.label = item.name;
        convertedWorkType.value = item.sid;
    } else if (workType.work_activity_types) {
        convertedWorkType.children = workType.work_activity_types.map((wtc) => ({
            label: wtc.name,
            value: wtc.sid,
        }));
    }

    return convertedWorkType;
});
