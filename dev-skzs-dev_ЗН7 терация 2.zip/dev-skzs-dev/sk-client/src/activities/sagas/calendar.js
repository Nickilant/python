import { createCRUDSaga } from "../../shared/sagas/entityCrudFactory";
import { convertPlanOut } from "./converters";

export const calendarCrudSaga = createCRUDSaga({
    moduleName: "calendar",
    entityName: "day",
    idField: "sid",

    getPrefixPath: ({ payload }) => `/projects/${payload.source.project.key}/categories/${payload.source.category.sid}/work-activity-categories/${payload.source.activity.activityCategory}/work-activities/${payload.source.activity.sid}/`,
    entityPath: ({ payload }) => `/projects/${payload.source.project.key}/categories/${payload.source.category.sid}/work-activity-categories/${payload.source.activity.activityCategory}/work-activities/${payload.source.activity.sid}/`,
    postPath: ({ payload }) => `/projects/${payload.source.project.key}/categories/${payload.source.category.sid}/work-activity-categories/${payload.source.activity.activityCategory}/work-activities/${payload.source.activity.sid}/`,

    detailsEntityOut: convertPlanOut,
});
