import {
    all, call, put, select, takeEvery,
} from "@redux-saga/core/effects";
import axios from "axios";
import { delay } from "redux-saga/effects";
import { createCRUDSaga } from "../../shared/sagas/entityCrudFactory";
import { ENTITY_NAME, MODULE_NAME } from "../constants/activities";
import { TREE_STRUCTURE_SELECT_NODE_MSG } from "../../categories/actions/actionTypes";
import {
    activitiesCRUDActions,
    calendarCRUDActions,
    selectEditableItem,
    setActivityTypesList,
} from "../actions/actions";
import { selectActiveProject } from "../../projects/selectors/projects";
import { convertOut, convertTree, convertWorkActivityTypes } from "./converters";
import { selectedCategory } from "../../categories/selectors/treeStructure";
import { calendarCrudSaga } from "./calendar";
import { ACTIVITIES_CALENDAR, ACTIVITIES_FILES, ACTIVITIES_TABLE } from "../actions/actionTypes";
import { activitiesUploadFormCombinedSaga } from "./uploadForm";

import { documentsCRUDActions } from "../../documents/actions/actions";
import { dateFormatServer } from "../../shared/constants/dateFormats";
import { selectCurrentLeafCategoryActivity } from "../selectors/activities";

const activitiesCrudSaga = createCRUDSaga({
    moduleName: MODULE_NAME,
    entityName: ENTITY_NAME,
    idField: "sid",

    getPrefixPath: ({ payload }) => `/projects/${payload.source.project.key}/categories/${payload.source.category.sid}/work-activity-categories`,
    entityPath: ({ payload }) => `/projects/${payload.source.project.key}/categories/${payload.source.category.sid}/work-activity-categories/${payload.source.entity.activityCategory}/work-activities/${payload.source.entity.activity.sid}/`,
    postPath: ({ payload }) => `/projects/${payload.source.project.key}/categories/${payload.source.category.sid}/work-activity-categories/${payload.source.entity.activityCategory}/work-activities/`,
    listEntityIn: (item) => convertTree(item),
    detailsEntityOut: convertOut,
});

function* fetchActivities(payload) {
    const project = yield select(selectActiveProject);
    const category_id = yield select(selectedCategory);
    const { startDate } = yield select((state) => state.activities.activities);

    yield put(selectEditableItem());

    yield put(activitiesCRUDActions.use.LIST_ENTITIES({
        source: {
            project,
            category: {
                sid: category_id,
            },
        },
        query: {
            date: startDate.format(dateFormatServer),
        },
    }));
}

function* fetchActivity({ payload }) {
    const { activity } = payload;

    if (!activity) {
        return;
    }

    const project = yield select(selectActiveProject);
    const category = yield select(selectCurrentLeafCategoryActivity(activity.activityCategory));

    yield put(activitiesCRUDActions.use.GET_ENTITY_DETAILS({
        source: {
            project,
            category,
            entity: {
                // tODO: hmmm, think something weird in mapping
                ...activity,
                activity,
            },
        },
    }));
}

function* watchUpdateActivities() {
    yield takeEvery(TREE_STRUCTURE_SELECT_NODE_MSG, fetchActivities);
    yield takeEvery(activitiesCRUDActions.CREATE_ENTITY_COMPLETE, fetchActivities);
    yield takeEvery(activitiesCRUDActions.UPDATE_ENTITY_COMPLETE, fetchActivities);
    yield takeEvery(activitiesCRUDActions.DELETE_ENTITY_COMPLETE, fetchActivities);
    yield takeEvery(ACTIVITIES_TABLE.OPEN_ACTIVITY, fetchActivity);
    yield takeEvery(ACTIVITIES_CALENDAR.SET_DATE, fetchActivities);
    yield takeEvery(ACTIVITIES_FILES.UPLOAD_FORM_COMPLETE, fetchActivities);
    yield takeEvery(calendarCRUDActions.CREATE_ENTITY_COMPLETE, fetchActivities);
    yield takeEvery(calendarCRUDActions.UPDATE_ENTITY_COMPLETE, fetchActivities);
    yield takeEvery(documentsCRUDActions.CREATE_ENTITY_COMPLETE, fetchActivities);
}

function* fetchWorkActivityTypeGroups() {
    yield delay(1000);
    const activityTypeGroups = yield call(axios.get, "/work-activity-type-groups/");
    yield put(setActivityTypesList(convertWorkActivityTypes(activityTypeGroups.data.results)));
}

export function* activitiesRootSaga() {
    yield all([
        calendarCrudSaga(),
        activitiesCrudSaga(),
        activitiesUploadFormCombinedSaga(),
        watchUpdateActivities(),
        fetchWorkActivityTypeGroups(),
    ]);
}
