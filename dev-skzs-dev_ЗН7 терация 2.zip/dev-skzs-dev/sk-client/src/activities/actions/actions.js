import {
    ACTIVITIES_AOSR,
    ACTIVITIES_CALENDAR,
    ACTIVITIES_FILES,
    ACTIVITIES_FORM,
    ACTIVITIES_TABLE,
    ACTIVITIES_WORK_TYPES,
} from "./actionTypes";
import { getCRUDEntityActions } from "../../shared/actions/entityCrudActions";
import { ENTITY_NAME, MODULE_NAME } from "../constants/activities";

export const activitiesCRUDActions = getCRUDEntityActions(MODULE_NAME, ENTITY_NAME);
export const calendarCRUDActions = getCRUDEntityActions("calendar", "day");

export const selectEditableItem = (activity) => ({
    type: ACTIVITIES_FORM.SELECT_EDITABLE_ITEM,
    payload: {
        activity,
    },
});

export const setInputValueAction = (name, value) => ({
    type: ACTIVITIES_FORM.SET_VALUE,
    payload: {
        name,
        value,
    },
});

export const setInputValueDate = (start, end) => ({
    type: ACTIVITIES_FORM.SET_VALUE_DATE,
    payload: {
        start,
        end,
    },
});

export const selectEditableCalendarActivityAction = (activitySid) => ({
    type: ACTIVITIES_CALENDAR.SELECT_EDITABLE_ACTIVITY,
    payload: {
        activitySid,
    },
});

export const setDirtyActivityFormAction = (value) => ({
    type: ACTIVITIES_FORM.SET_DIRTY_FORM,
    payload: {
        value,
    },
});

export const setValidActivityFormAction = (value) => ({
    type: ACTIVITIES_FORM.SET_VALID_FORM,
    payload: {
        value,
    },
});

export const toggleExecutiveDocumentationInfo = () => ({
    type: ACTIVITIES_TABLE.TOGGLE_EXECUTIVE_DOCUMENTATION_INFO,
});

export const toggleCommonDataInfo = () => ({
    type: ACTIVITIES_TABLE.TOGGLE_COMMON_DATA_INFO,
});

export const toggleDistributionInfo = () => ({
    type: ACTIVITIES_TABLE.TOGGLE_DISTRIBUTION_INFO,
});

export const showAllInfo = () => ({
    type: ACTIVITIES_TABLE.SHOW_ALL_INFO,
});

export const hideAllInfo = () => ({
    type: ACTIVITIES_TABLE.HIDE_ALL_INFO,
});

export const search = (query, tree) => ({
    type: ACTIVITIES_TABLE.SEARCH,
    payload: {
        searchQuery: query,
        tree,
    },
});

export const changeCurrentFoundIndex = (value) => ({
    type: ACTIVITIES_TABLE.CHANGE_CURRENT_FOUND_INDEX,
    payload: {
        indexCoef: value,
    },
});

export const incrementDate = () => ({
    type: ACTIVITIES_CALENDAR.DATE_INCREMENT,
});

export const decrementDate = () => ({
    type: ACTIVITIES_CALENDAR.DATE_DECREMENT,
});

export const createNewActivity = (activity) => ({
    type: ACTIVITIES_FORM.SELECT_EDITABLE_ITEM,
    payload: {
        activity,
    },
});

export const openActivity = (activity) => ({
    type: ACTIVITIES_TABLE.OPEN_ACTIVITY,
    payload: {
        activity,
    },
});

export const setDate = (date) => ({
    type: ACTIVITIES_CALENDAR.SET_DATE,
    payload: {
        date,
    },
});

export const setDateInfo = (maxDays) => ({
    type: ACTIVITIES_CALENDAR.SET_DATE_INFO,
    payload: {
        maxDays,
    },
});

export const setValidCalendarInputsAction = (value) => ({
    type: ACTIVITIES_CALENDAR.SET_VALID_INPUTS,
    payload: {
        value,
    },
});

export const uploadActivityFormAction = (project, category, activity, files) => ({
    type: ACTIVITIES_FILES.UPLOAD_FORM,
    payload: {
        project, category, activity, files,
    },
});

export const uploadActivityFormCompleteAction = (project, category, activity, files) => ({
    type: ACTIVITIES_FILES.UPLOAD_FORM_COMPLETE,
    payload: {
        project, category, activity, files,
    },
});

export const setActivityTypesList = (list) => ({
    type: ACTIVITIES_WORK_TYPES.SET_LIST,
    payload: {
        list,
    },
});
