import React, { useEffect, useState } from "react";
import "./styles.scss";
import { useDispatch, useSelector } from "react-redux";
import { DatePicker } from "antd";
import moment from "moment";
import cx from "classnames";
import { FormInput } from "../FormInput/component";
import { FormActions } from "../FormActions/component";
import { validateActivityField } from "../../constants/activities";
import { setInputValueAction } from "../../actions/actions";
import DocumentIcon from "./assets/document.svg";
import { dateFormat } from "../../../shared/constants/dateFormats";

export const GeneralInfo = (props) => {
    const {
        isEditable,
        period_plan_start,
        period_plan_end,
        period_in_fact,
        deviation,
        distributed,
        notDistributed,
        status,
        type,
        in_fact,
        validationFormConfig,
    } = props;

    const dispatch = useDispatch();

    const showExecutiveDocumentationInfo = useSelector((state) => state.activities.activities.showExecutiveDocumentationInfo);
    const showCommonDataInfo = useSelector((state) => state.activities.activities.showCommonDataInfo);
    const showDistributionInfo = useSelector((state) => state.activities.activities.showDistributionInfo);
    const editableActivity = useSelector((state) => state.activities.activities.editableActivity);
    const editableActivityFields = useSelector((state) => state.activities.activities.editableActivityFields);
    const dirtyActivityForm = useSelector((state) => state.activities.activities.dirtyActivityForm);

    const [configuration, updateConfiguration] = useState(() => ({
        registered: {
            editable: false,
            type: "number",
        },
        accumulated: {
            editable: false,
            type: "number",
        },
        unit: {
            editable: true,
            type: "text",
            placeholder: "Ед. изм.",
        },
        total: {
            editable: true,
            type: "number",
            placeholder: "Всего ФО",
        },
        in_fact: {
            editable: false,
            type: "number",
        },
        remainder: {
            editable: false,
            type: "number",
        },
    }));

    useEffect(() => {
        configuration.registered.visible = showExecutiveDocumentationInfo;
        configuration.accumulated.visible = showExecutiveDocumentationInfo;

        configuration.unit.visible = showCommonDataInfo;
        configuration.total.visible = showCommonDataInfo;
        configuration.in_fact.visible = showCommonDataInfo;
        configuration.remainder.visible = showCommonDataInfo;

        updateConfiguration({ ...configuration });
    }, [showExecutiveDocumentationInfo, showCommonDataInfo]); // eslint-disable-line react-hooks/exhaustive-deps

    useEffect(() => {
        configuration.unit.editable = !in_fact;
        configuration.total.editable = !in_fact;

        updateConfiguration({ ...configuration });
    }, [in_fact]); // eslint-disable-line react-hooks/exhaustive-deps

    const renderErrorClass = (fieldName) => {
        const fieldValue = editableActivityFields[fieldName] === undefined ? editableActivity[fieldName] : editableActivityFields[fieldName];

        if (validateActivityField(validationFormConfig[fieldName], fieldValue) && dirtyActivityForm) {
            return "error-validation-field";
        }
    };

    const handleOnChangePlan = (key) => (date) => {
        const value = (moment(date).startOf("day"));
        dispatch(setInputValueAction(key, value));
    };

    const periodPlanStartDisabledDate = (date) => {
        const currentDate = moment(date).startOf("day");
        const periodPlanEnd = (editableActivityFields && editableActivityFields.period_plan_end)
            || (editableActivity && moment(editableActivity.period_plan_end, dateFormat).startOf("day"));

        if (currentDate.isAfter(periodPlanEnd)) {
            return true;
        }

        if (process.env.REACT_APP_BRANCH !== "dev" && currentDate.isBefore(moment().startOf("day").add(1, "d"))) {
            return true;
        }

        return false;
    };

    const periodPlanEndDisabledDate = (date) => {
        const currentDate = moment(date).startOf("day");
        const periodPlanStart = (editableActivityFields && editableActivityFields.period_plan_start)
            || (editableActivity && moment(editableActivity.period_plan_start, dateFormat).startOf("day"));

        if (currentDate.isBefore(periodPlanStart)) {
            return true;
        }

        if (currentDate.isBefore(moment(period_in_fact && period_in_fact.end, dateFormat).startOf("day"))) {
            return true;
        }

        return false;
    };

    return (
        <div className={`component-form-general-info ${isEditable ? "is-editable" : ""}`}>
            {
                showExecutiveDocumentationInfo && !isEditable && (
                    <div className={`table-item status ${type}`}>
                        {
                            status && Object.entries(status).filter(([key, value]) => key !== "all" && value).map(([key, value]) => (
                                <div key={key} className={cx(["status-item", key])}>
                                    <img src={DocumentIcon} alt="Документ" />
                                    {value}
                                    /
                                    {status.all}
                                </div>
                            ))
                        }
                    </div>
                )
            }
            {Object.entries(configuration).map(([key, value]) => value.visible !== false && (
                <div className={`table-item ${key.split("_").join("-")}`} key={key}>
                    {
                        (props[key] !== undefined) && (
                            isEditable && configuration[key].editable
                                ? (
                                    <FormInput
                                        placeholder={value.placeholder}
                                        name={key}
                                        defaultValue={props[key]}
                                        className={renderErrorClass(key)}
                                        type={value.type}
                                    />
                                )
                                : (
                                    <span className="text">{props[key]}</span>
                                )
                        )
                    }
                </div>
            ))}
            {
                showCommonDataInfo && (
                    <>
                        <div className="table-item period-plan">
                            {
                                isEditable && !distributed
                                    ? (
                                        <>
                                            <DatePicker
                                                format="DD/MM/YYYY"
                                                className={renderErrorClass("period_plan_start")}
                                                defaultValue={period_plan_start ? moment(period_plan_start, dateFormat) : null}
                                                placeholder="Дата начала"
                                                disabledDate={periodPlanStartDisabledDate}
                                                onChange={handleOnChangePlan("period_plan_start")}
                                                allowClear={false}
                                            />
                                            <DatePicker
                                                format="DD/MM/YYYY"
                                                className={renderErrorClass("period_plan_end")}
                                                defaultValue={period_plan_end ? moment(period_plan_end, dateFormat) : null}
                                                placeholder="Дата окончания"
                                                disabledDate={periodPlanEndDisabledDate}
                                                onChange={handleOnChangePlan("period_plan_end")}
                                                allowClear={false}
                                            />
                                        </>
                                    )
                                    : (
                                        <>
                                            {
                                                period_plan_start && period_plan_end && (
                                                    <span className="text">
                                                        {period_plan_start}
                                                        {" - "}
                                                        {period_plan_end}
                                                    </span>
                                                )
                                            }
                                        </>
                                    )
                            }
                        </div>
                        <div className="table-item period-in-fact">
                            {
                                period_in_fact && period_in_fact.start && period_in_fact.end && (
                                    <span className="text">
                                        {period_in_fact.start}
                                        {" - "}
                                        {period_in_fact.end}
                                    </span>
                                )
                            }
                        </div>
                        <div className="table-item deviation">
                            <span className="text">{deviation}</span>
                        </div>
                    </>
                )
            }
            {
                showDistributionInfo && (
                    <>
                        <div className="table-item distributed">
                            <span className="text">{distributed}</span>
                        </div>
                        <div className="table-item not-distributed">
                            <span className="text">{notDistributed}</span>
                        </div>
                    </>
                )
            }
            {isEditable && <FormActions />}
        </div>
    );
};
