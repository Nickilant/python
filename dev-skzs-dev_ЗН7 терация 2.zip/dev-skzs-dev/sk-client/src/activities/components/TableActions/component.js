import React, { useEffect } from "react";
import "./styles.scss";
import { useDispatch, useSelector } from "react-redux";
import { DatePicker } from "antd";
import moment from "moment";
import locale from "antd/es/date-picker/locale/ru_RU";
import cx from "classnames";
import {
    changeCurrentFoundIndex,
    createNewActivity, search, setDate, setDateInfo, showAllInfo,
} from "../../actions/actions";
import { FORM, TYPE } from "../../constants/activities";
import { getEmptyMonth } from "../../selectors/activities";
import { Search } from "../../../shared/components/Search/component";
import { dateFormatMonth } from "../../../shared/constants/dateFormats";
import { Dropdown } from "../../../shared/components/Dropdown/component";
import { canCreateWorkActivityPredicate } from "../../../construction_control/base/selectors/permissions";

const { MonthPicker } = DatePicker;

export const TableActions = ({ treeRef, tableWrapperRef }) => {
    const dispatch = useDispatch();

    const items = useSelector((state) => state.activities.crud.items);
    const searchValue = useSelector((state) => state.activities.activities.searchQuery);
    const startDate = useSelector((state) => state.activities.activities.startDate);
    const dateType = useSelector((state) => state.activities.activities.maxDays);
    const foundIdsCount = useSelector((state) => state.activities.activities.foundIds).length;
    const currentFoundIndex = useSelector((state) => state.activities.activities.currentFoundIndex);
    const activityTypeDefaultSid = useSelector((state) => state.activities.activities.activityTypeDefaultSid);
    const canCreate = useSelector((state) => canCreateWorkActivityPredicate(state));

    const activitiesList = items.tree ? items.tree.list : [];
    const activityCategory = activitiesList[0];

    const newActivity = {
        sid: FORM.NEW_ACTIVITY_ID,
        type: TYPE.ACTIVITY,
        level: 1,
        number: "",
        title: "",
        status: {
            done: 0,
            left: 0,
        },
        unit: "",
        total: null,
        in_fact: 0,
        remainder: 0,
        period_plan_start: null,
        period_plan_end: null,
        period_in_fact: {
            start: null,
            end: null,
        },
        workType: { sid: activityTypeDefaultSid },
        deviation: 0,
        registered: 0,
        accumulated: 0,
        distributed: 0,
        orderingIndex: activityCategory && activityCategory.work_activities && activityCategory.work_activities.length - 2,
        notDistributed: 0,
        plan: getEmptyMonth(),
    };

    useEffect(() => () => {
        tableWrapperRef.current.scrollTo(tableWrapperRef.current.scrollWidth, 0);
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [startDate]);

    const handleCreateNewActivity = () => {
        dispatch(createNewActivity(newActivity));
        dispatch(showAllInfo());
    };

    const handleSearch = (value) => {
        dispatch(search(value, activityCategory));
    };

    const handleChangeDate = (value) => {
        dispatch(setDate(value.startOf("month")));
    };

    const handleSetMonth = (coef) => {
        dispatch(setDate(moment(startDate).add(coef, "month").startOf("month")));
    };

    const dateTypes = [
        { id: 7, title: "Неделю" },
        { id: 31, title: "Месяц" },
    ];

    const handleChangeDateType = (value) => {
        dispatch(setDateInfo(value));

        if (value === 31) {
            treeRef.current.resizeTree(147);
        }
    };

    const changeIndex = (value) => {
        dispatch(changeCurrentFoundIndex(value));
    };

    return (
        <div className="component-table-actions">
            {
                canCreate && (
                    <button disabled={!(activityCategory && activityCategory.isLeaf)} className="create-row" onClick={handleCreateNewActivity}>
                        <span className="bg-img" />
                        Создать строку
                    </button>
                )
            }
            <Search defaultValue={searchValue} placeholder="Поиск по наименованию" onSearch={handleSearch} />
            {
                searchValue && (
                    <div className="searched-count">
                        Найдено
                        {" "}
                        {foundIdsCount}
                        {" "}
                        совпадений
                        {
                            foundIdsCount > 1 && (
                                <div className="index-block">
                                    <div onClick={() => changeIndex(-1)} className={cx(["desc-index", "index-control", { disabled: currentFoundIndex <= 0 }])} />
                                    {currentFoundIndex + 1}
                                    /
                                    {foundIdsCount}
                                    <div onClick={() => changeIndex(1)} className={cx(["inc-index", "index-control", { disabled: currentFoundIndex >= foundIdsCount - 1 }])} />
                                </div>
                            )
                        }
                    </div>
                )
            }
            <div className="month-picker-wrapper">
                <div className="label">
                    Период данных
                </div>
                <button onClick={() => handleSetMonth(-1)} className="bg-img icon arrow" />
                <MonthPicker
                    onChange={handleChangeDate}
                    value={startDate}
                    format={dateFormatMonth}
                    locale={locale}
                    allowClear={false}
                />
                <button onClick={() => handleSetMonth(1)} className="bg-img icon arrow right" />
            </div>
            <div className="date-type-wrapper">
                <div className="label">
                    Информация на
                </div>
                <Dropdown onChange={handleChangeDateType} defaultValue={dateType} className="contractor">
                    { dateTypes }
                </Dropdown>
            </div>
        </div>
    );
};
