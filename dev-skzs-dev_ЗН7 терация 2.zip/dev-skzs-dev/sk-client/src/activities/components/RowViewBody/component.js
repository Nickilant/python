import React from "react";
import { useSelector } from "react-redux";
import { Switcher } from "../../../shared/components/Switcher/component";
import { SWITCHER_TYPES } from "../../../shared/constants/switcherTypes";
import { ViewAdditional } from "../ViewAdditional/component";
import { selectOpenedActivity, selectOpenedActivityDetails } from "../../selectors/activities";

export const RowViewBody = () => {
    const details = useSelector(selectOpenedActivityDetails);
    const activity = useSelector(selectOpenedActivity);

    const config = [
        // {
        //     type: SWITCHER_TYPES.HISTORY,
        //     title: "История",
        //     component: () => <UniversalHistory />,
        // },
        // {
        //     type: SWITCHER_TYPES.VERTICAL_DIVIDER,
        // },
        // {
        //     type: SWITCHER_TYPES.GEOTAGS,
        //     title: "Геометки",
        //     count: 4,
        //     component: () => <Geotags />,
        // },
        // {
        //     type: SWITCHER_TYPES.COMMENTS,
        //     title: "Комментарии",
        //     count: 3,
        //     component: () => (
        //         <UniversalComments />
        //     ),
        // },
        {
            type: SWITCHER_TYPES.FILES,
            title: "Приложения",
            count: activity.documents.length + (details && details.aosr_acts && details.aosr_acts.length),
            component: () => (<ViewAdditional />),
        },
    ];

    return (
        <div>
            <Switcher
                config={config}
            />
        </div>
    );
};
