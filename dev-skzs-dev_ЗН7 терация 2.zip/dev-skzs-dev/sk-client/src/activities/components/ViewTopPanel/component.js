import React from "react";
import { useDispatch, useSelector } from "react-redux";

import { WIDGET_TYPES } from "../../../shared/constants/widgetTypes";
import { openRightColumnContainerAction } from "../../../shared/actions/RightColumnContainer/actions";
import { PREVIEW_MODULES } from "../../../construction_control/base/widgets/DocumentPreviewColumn/previewModules";
import { universalClearFormAction } from "../../../shared/actions/managementForm/actions";
import {
    selectCurrentLeafCategoryActivity,
    selectOpenedActivity,
    selectOpenedActivityDetails,
} from "../../selectors/activities";
import { getCurrentUser } from "../../../users/selectors/users";
import { openModalAction } from "../../../shared/actions/Modal/actions";
import { MODAL_TYPES } from "../../../shared/constants/modalTypes";

import "./styles.scss";
import { canCreateAOSRPredicate } from "../../../construction_control/base/selectors/permissions";
import { loggedInUser } from "../../../users/selectors/permissions";

export const ViewTopPanel = () => {
    const dispatch = useDispatch();
    const activity = useSelector(selectOpenedActivity);
    const details = useSelector(selectOpenedActivityDetails);
    const category = useSelector(selectCurrentLeafCategoryActivity(activity.activityCategory));
    const canCreateAOSR = useSelector((state) => {
        if (activity) {
            const companyName = loggedInUser(state).user.company;

            if (activity.contractor && companyName === activity.contractor.name) {
                return canCreateAOSRPredicate(state);
            }
        }

        return false;
    });
    const user = useSelector(getCurrentUser);

    const createAOSR = () => {
        dispatch(openRightColumnContainerAction(WIDGET_TYPES.DOCUMENT_MANAGEMENT_FORM, {
            module: PREVIEW_MODULES.EXECUTIVE_DOCUMENTATION,
        }, true));
        dispatch(universalClearFormAction("documents", "document", {
            type: "aosr",
            work_activity: {
                ...activity,
                number: category.number,
                details,
            },
            description: `${activity.title} ${activity.accumulated_physical_volume} ${activity.unit}`,
            author: user && user.sid,
            related_category: category.projectCategory.sid,
        }));
    };

    const handleCreate = () => {
        if (!activity.accumulated) {
            return dispatch(openModalAction({
                widget: null,
                context: { description: "Нет накопленных ФО!" },
                type: MODAL_TYPES.ALERT,
            }));
        }

        if (!canCreateAOSR) {
            return dispatch(openModalAction({
                widget: null,
                context: { description: "Актирование по данной работе доступно только представителям организации, являющейся подрядчиком по данной работе" },
                type: MODAL_TYPES.ALERT,
            }));
        }

        createAOSR();
    };

    return (
        <div className="view-top-panel">
            <div className="info">
                <div className="info-block">
                    <div className="title">
                        Физ. объемы
                    </div>
                    <div className="info-block-desc">
                        <div className="info-block-desc-item">
                            План
                            <div className="text">
                                { activity.total }
                                {" "}
                                {activity.unit}
                            </div>
                        </div>
                        <div className="info-block-desc-item">
                            Накопленные
                            <div className="text">
                                { activity.accumulated }
                                {" "}
                                {activity.unit}
                            </div>
                        </div>
                    </div>
                    <div className="info-block-desc">
                        <div className="info-block-desc-item">
                            Факт
                            <div className="text">
                                { activity.in_fact }
                                {" "}
                                {activity.unit}
                            </div>
                        </div>
                        <div className="info-block-desc-item">
                            Заактированные
                            <div className="text">
                                { activity.registered }
                                {" "}
                                {activity.unit}
                            </div>
                        </div>
                    </div>
                </div>
                {
                    activity.contractor && (
                        <div className="contractor">
                            <div className="text">Подрядчик:</div>
                            {activity.contractor.name}
                        </div>
                    )
                }
                {
                    activity.workType && (
                        <div className="work-type">
                            <div className="text">Вид работы:</div>
                            {activity.workType.name}
                        </div>
                    )
                }
            </div>
            <div className="buttons">
                <button onClick={handleCreate} className="create">
                    <div className="icon" />
                    Создать АКТ
                </button>
            </div>
        </div>
    );
};
