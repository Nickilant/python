import React from "react";
import "./styles.scss";
import { useDispatch, useSelector } from "react-redux";
import { Search } from "../../../shared/components/Search/component";
import { decrementDate, incrementDate, search } from "../../actions/actions";
import { getEmptyMonth } from "../../selectors/activities";
// import cx from "classnames";

export const SubHeader = (props) => {
    const { showGeneralInfo, onHideGeneralInfo } = props;

    const dispatch = useDispatch();

    const handleIncrementDay = () => {
        dispatch(incrementDate());
    };
    const handleDecrementDay = () => {
        dispatch(decrementDate());
    };
    const plan = getEmptyMonth();

    const date_to = useSelector((state) => state.activities.activities.lastDay);
    const date_from = date_to - 6;

    return (
        <div className="component-sub-header component-activity">
            <div className="search-margin-left" />
            <div className="calendar-header">
                <div className="col" />
                <div className="col">
                    <div className="date">
                        <button className="arrow prev bg-img" onClick={handleDecrementDay} />
                        {plan[date_from].day}
                        {" "}
                        -
                        {" "}
                        {plan[date_to].day}
                        <button className="arrow next bg-img" onClick={handleIncrementDay} />
                    </div>
                    <div className="days">
                        {
                            Object.values(plan).slice(date_from - 1, date_to).map((item) => (
                                <div className="day" key={item.day}>
                                    {item.day}
                                </div>
                            ))
                        }
                    </div>
                </div>

            </div>
        </div>
    );
};
