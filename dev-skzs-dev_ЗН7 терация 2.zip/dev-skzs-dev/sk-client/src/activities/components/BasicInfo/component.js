import React, { useEffect } from "react";
import cx from "classnames";

import "./styles.scss";
import { useDispatch, useSelector } from "react-redux";
import Cascader from "antd/lib/cascader";
import { FormInput } from "../FormInput/component";
import { Dropdown } from "../../../shared/components/Dropdown/component";
import { setInputValueAction } from "../../actions/actions";
import ArrowIcon from "./assets/arrow.svg";
import { TYPE, validateActivityField } from "../../constants/activities";
import { If } from "../../../shared/components/If/component";

function searchSubstr(text, searchQuery) {
    const indexStart = text.toLowerCase().indexOf(searchQuery.toLowerCase());
    const indexEnd = indexStart + searchQuery.length;
    return (indexStart === -1 || searchQuery === "") ? null : { indexStart, indexEnd };
}

function highlightBySearch(text, searchQuery, isSearched) {
    const result = searchSubstr(text, searchQuery);

    if (!result) {
        return text;
    }
    return (
        <>
            {text.substring(0, result.indexStart)}
            <span style={{ background: isSearched ? "orange" : "yellow", color: "black" }}>
                {text.substring(result.indexStart, result.indexEnd)}
            </span>
            {text.substring(result.indexEnd, text.length)}
        </>
    );
}

export const BasicInfo = (props) => {
    const {
        level,
        number,
        title,
        skipCategory,
        handleSkipCategory,
        isEditable,
        onOpenRightColumn,
        type,
        contractor,
        validationFormConfig,
        workType,
        setExpandCategory,
        isSearched,
    } = props;

    const editableActivity = useSelector((state) => state.activities.activities.editableActivity);
    const editableActivityFields = useSelector((state) => state.activities.activities.editableActivityFields);
    const dirtyActivityForm = useSelector((state) => state.activities.activities.dirtyActivityForm);
    const workTypeGroupOptions = useSelector((state) => state.activities.activities.activityTypes);

    const searchQuery = useSelector((state) => state.activities.activities.searchQuery);

    const companies = Object.values(useSelector((state) => state.organizations.crud.items));

    const dispatch = useDispatch();

    useEffect(() => {
        if (searchSubstr(title, searchQuery) && setExpandCategory) {
            setExpandCategory(false);
        }
    }, [searchQuery, title]); // eslint-disable-line react-hooks/exhaustive-deps

    const handleInputCompany = (value) => {
        dispatch(setInputValueAction("contractor", value));
    };

    const cascaderFindPath = (options, value) => {
        const found = options.filter((item) => {
            if (item.children) {
                return item.children.filter((i) => i.value === value).length;
            }

            return item.value === value;
        });

        if (found.length && found[0].label !== "Не определен") {
            return [found[0].value, value];
        }

        return value ? [value] : null;
    };

    const handleInputWorkType = (value) => {
        dispatch(setInputValueAction("workType", value[1] || value[0]));
    };

    const renderErrorClass = (fieldName) => {
        const fieldValue = editableActivityFields[fieldName] === undefined ? editableActivity[fieldName] : editableActivityFields[fieldName];

        if (validateActivityField(validationFormConfig[fieldName], fieldValue) && dirtyActivityForm) {
            return "error-validation-field";
        }
    };

    const filter = (inputValue, path) => path.some((option) => option.label.toLowerCase().indexOf(inputValue.toLowerCase()) > -1);

    return (
        <>
            <div className="table-item title align-left" style={{ width: `${332 - level * 10 + (isEditable ? 118 : 0)}px` }}>
                {isEditable
                    ? (
                        <div className="category-title-form">
                            <FormInput
                                name="title"
                                defaultValue={title}
                                placeholder="Наименование"
                                className={renderErrorClass("title")}
                            />
                            <Dropdown onChange={handleInputCompany} defaultValue={(contractor && contractor.sid) || "Подрядчик"} className="contractor">
                                {
                                    companies.map((item) => (
                                        { id: item.key, title: item.full_name }
                                    ))
                                }
                            </Dropdown>
                            <Cascader
                                options={workTypeGroupOptions}
                                defaultValue={cascaderFindPath(workTypeGroupOptions, workType && workType.sid)}
                                onChange={handleInputWorkType}
                                displayRender={(labels) => <>{labels[1] || labels[0]}</>}
                                placeholder="Вид работы"
                                className={cx(["work-type", renderErrorClass("workType")])}
                                showSearch={{ filter }}
                                allowClear={false}
                            />
                        </div>
                    )
                    : (
                        <>
                            <If condition={type === TYPE.ACTIVITY_MARKER || type === TYPE.ACTIVITY_CATEGORY}>
                                <div className={cx(["category-title-info", { isMarker: type === TYPE.ACTIVITY_MARKER }])}>
                                    {
                                        skipCategory !== undefined && (
                                            <img className={cx(["skipCategoryIcon", { hiddenCategoryIcon: skipCategory }])} onClick={handleSkipCategory} src={ArrowIcon} alt="скрыть" />
                                        )
                                    }
                                    <div className="text">
                                        {highlightBySearch(title, searchQuery, isSearched)}
                                        <div className="cipher">
                                            {number}
                                        </div>
                                    </div>
                                </div>
                            </If>
                            <If condition={type === TYPE.ACTIVITY}>
                                <div className="category-title-info isActivity">
                                    <div className={`text ${onOpenRightColumn ? "link" : null}`} onClick={onOpenRightColumn}>
                                        {highlightBySearch(title, searchQuery, isSearched)}
                                    </div>
                                    {
                                        contractor && (<div className="contractor">{contractor.name}</div>)
                                    }
                                    {
                                        workType && (<div className="workType">{workType.name}</div>)
                                    }
                                </div>
                            </If>
                        </>
                    )}
            </div>
        </>
    );
};
