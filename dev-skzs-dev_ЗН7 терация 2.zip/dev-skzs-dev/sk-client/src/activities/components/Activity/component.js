import React, { useEffect, useRef, useState } from "react"; // eslint-disable-line react-hooks/exhaustive-deps
import "./styles.scss";
import { useDispatch, useSelector } from "react-redux";
import { Calendar } from "../Calendar/component";
import { GeneralInfo } from "../GeneralInfo/component";
import { BasicInfo } from "../BasicInfo/component";
import { selectEditableItem, setValidActivityFormAction } from "../../actions/actions";
import { activityFormValidators, TYPE, validateActivityField } from "../../constants/activities";
import { calcLeftOffset, selectCurrentFoundId } from "../../selectors/activities";
import { canEditWorkActivityPredicate } from "../../../construction_control/base/selectors/permissions";
import { scrollToActivityObjRef } from "../../utils/activities";

export const Activity = (props) => {
    const {
        data, onOpenRightColumn, tableRef, setExpandCategory,
    } = props;
    const dispatch = useDispatch();
    const {
        sid,
        level,
        number,
        title,
        status,
        unit,
        total,
        in_fact,
        remainder,
        period_plan_start,
        period_plan_end,
        period_in_fact,
        deviation,
        plan,
        contractor,
        distributed,
        notDistributed,
        registered,
        accumulated,
        workType,
    } = data;

    const editableActivity = useSelector((state) => state.activities.activities.editableActivity);
    const editableActivityFields = useSelector((state) => state.activities.activities.editableActivityFields);
    const dirtyActivityForm = useSelector((state) => state.activities.activities.dirtyActivityForm);
    const validActivityForm = useSelector((state) => state.activities.activities.validActivityForm);
    const showCommonDataInfo = useSelector((state) => state.activities.activities.showCommonDataInfo);
    const canEdit = useSelector((state) => canEditWorkActivityPredicate(state));
    const currentFoundId = useSelector(selectCurrentFoundId);
    const calcLeftEditOffset = useSelector(calcLeftOffset);
    const [isSearched, setIsSearched] = useState(false);

    const validationFormConfig = {
        title: [
            activityFormValidators.REQUIRED,
        ],
        workType: [
            activityFormValidators.REQUIRED,
        ],
        unit: [
            activityFormValidators.REQUIRED,
            activityFormValidators.MAX_SIZE(8),
        ],
        total: [
            activityFormValidators.REQUIRED,
            activityFormValidators.MAX_SIZE(8),
            activityFormValidators.NOT_LESS_THEN(editableActivity && editableActivity.distributed),
        ],
        period_plan_start: [
            activityFormValidators.REQUIRED,
        ],
        period_plan_end: [
            activityFormValidators.REQUIRED,
        ],
    };

    const ref = useRef(null);

    const openedActivity = useSelector((state) => state.activities.activities.openedActivity);
    const isOpened = openedActivity && openedActivity.sid === sid;

    const isEditable = sid === (editableActivity && editableActivity.sid);

    const handleSelectEditableItem = () => {
        dispatch(selectEditableItem(data));
    };

    useEffect(() => {
        if (editableActivity) {
            const formIsInvalid = Object.entries(validationFormConfig).some(([key, validators]) => {
                const fieldValue = editableActivityFields[key] === undefined ? editableActivity[key] : editableActivityFields[key];
                return validateActivityField(validators, fieldValue);
            });

            dispatch(setValidActivityFormAction(!formIsInvalid));
        }
    }, [editableActivityFields]); // eslint-disable-line react-hooks/exhaustive-deps

    useEffect(() => {
        if (isOpened || isEditable) {
            scrollToActivityObjRef(ref, tableRef);
        }
    }, [isOpened, isEditable]); // eslint-disable-line react-hooks/exhaustive-deps

    useEffect(() => {
        if (currentFoundId && currentFoundId === sid) {
            setIsSearched(true);
            setExpandCategory(false);
            setTimeout(() => {
                scrollToActivityObjRef(ref, tableRef);
            }, 0);
        } else {
            setIsSearched(false);
        }
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [currentFoundId]);

    return (
        <>
            <div
                className={`component-activity component-activity-item ${isEditable ? "is-editable" : ""} ${isOpened ? "is-opened" : ""} ${!validActivityForm && dirtyActivityForm && editableActivity && editableActivity.sid === sid ? "is-invalid" : ""} ${canEdit ? "can-edit" : ""}`}
                ref={ref}
            >
                <div className="component-activity-item-inner">
                    {
                        !isEditable && showCommonDataInfo && canEdit && (
                            <div style={{ left: calcLeftEditOffset(2) - 53 - 10 * level }} className="table-item edit">
                                <button className="edit-button bg-img" onClick={handleSelectEditableItem} title="Редактировать строку" />
                            </div>
                        )
                    }
                    <BasicInfo
                        level={level}
                        number={number}
                        title={title}
                        in_fact={in_fact}
                        contractor={contractor}
                        isEditable={isEditable}
                        type={TYPE.ACTIVITY}
                        workType={workType}
                        onOpenRightColumn={() => onOpenRightColumn(sid)}
                        validationFormConfig={validationFormConfig}
                        setExpandCategory={setExpandCategory}
                        isSearched={isSearched}
                    />

                    <GeneralInfo
                        unit={unit}
                        total={total}
                        in_fact={in_fact}
                        remainder={remainder}
                        period_plan_start={period_plan_start}
                        period_plan_end={period_plan_end}
                        period_in_fact={period_in_fact}
                        deviation={deviation}
                        distributed={distributed}
                        notDistributed={notDistributed}
                        isEditable={isEditable}
                        registered={registered}
                        accumulated={accumulated}
                        validationFormConfig={validationFormConfig}
                        status={status}
                    />
                </div>

                <Calendar
                    activity={data}
                    plan={plan}
                />
            </div>
        </>
    );
};
