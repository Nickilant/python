import React, { useEffect, useRef, useState } from "react";

import "./styles.scss";
import cx from "classnames";
import { push } from "connected-react-router";
import { useDispatch, useSelector } from "react-redux";
import { Calendar } from "../Calendar/component";
import { GeneralInfo } from "../GeneralInfo/component";
import { BasicInfo } from "../BasicInfo/component";
import { Activity } from "../Activity/component";
import { ActivityMarker } from "../ActivityMarker/component";
import { getURL } from "../../../shared/helpers/getPath";
import { selectActivityById, selectCurrentFoundId, selectCurrentLeafCategoryActivity } from "../../selectors/activities";
import { openActivity } from "../../actions/actions";
import { openRightColumnContainerAction } from "../../../shared/actions/RightColumnContainer/actions";
import { WIDGET_TYPES } from "../../../shared/constants/widgetTypes";
import { PREVIEW_MODULES } from "../../../construction_control/base/widgets/DocumentPreviewColumn/previewModules";
import { TYPE } from "../../constants/activities";
import { scrollToActivityObjRef } from "../../utils/activities";

export const ActivityCategory = (props) => {
    const { tableRef, data, setExpandCategory } = props;

    const dispatch = useDispatch();
    const state = useSelector((s) => s);
    const routerPathParams = useSelector((state) => state.core.router);
    const currentFoundId = useSelector(selectCurrentFoundId);

    const [isSearched, setIsSearched] = useState(false);
    const [skipCategory, setSkipCategory] = useState(false);

    const ref = useRef(null);

    const {
        sid,
        level,
        number,
        title,
        status,
        unit,
        total,
        in_fact,
        remainder,
        period_plan_start,
        period_plan_end,
        period_in_fact,
        deviation,
        plan,
        distributed,
        notDistributed,
        subcategories,
        work_activities,
        registered,
        accumulated,
    } = data;

    const styleLevel = ((level - 1) % 5) + 1;

    const openActivityRightColumn = (id) => {
        const activity = selectActivityById(id)(state);

        if (activity) {
            const category = selectCurrentLeafCategoryActivity(activity.activityCategory)(state);

            activity.number = category.number;

            dispatch(openActivity(activity));
            dispatch(openRightColumnContainerAction(WIDGET_TYPES.DOCUMENT_PREVIEW, { module: PREVIEW_MODULES.ACTIVITIES, activity }));
        }
    };

    const handleOpenRightColumn = (sid) => {
        const path = getURL(routerPathParams, ["projects", "section", "group", ["activity", sid]]);
        dispatch(push(path));
        openActivityRightColumn(sid);
    };

    const expandCategoryForActivity = (value) => {
        setSkipCategory(value);

        if (setExpandCategory) {
            setExpandCategory(value);
        }
    };

    useEffect(() => {
        if (currentFoundId && currentFoundId === sid) {
            setIsSearched(true);
            if (setExpandCategory) {
                setExpandCategory(false);
            }
            setTimeout(() => {
                scrollToActivityObjRef(ref, tableRef);
            }, 0);
        } else {
            setIsSearched(false);
        }
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [currentFoundId]);

    return (
        <div className={cx(["lvl", `lvl-${styleLevel}`])}>
            <div ref={ref} className="component-activity component-activity-category">
                <BasicInfo
                    skipCategory={skipCategory}
                    handleSkipCategory={() => setSkipCategory(!skipCategory)}
                    level={level}
                    number={number}
                    title={title}
                    isEditable={false}
                    type={TYPE.ACTIVITY_CATEGORY}
                    setExpandCategory={expandCategoryForActivity}
                    isSearched={isSearched}
                />

                <GeneralInfo
                    registered={registered}
                    accumulated={accumulated}
                    unit={unit}
                    total={total}
                    in_fact={in_fact}
                    remainder={remainder}
                    period_plan_start={period_plan_start}
                    period_plan_end={period_plan_end}
                    period_in_fact={period_in_fact}
                    deviation={deviation}
                    distributed={distributed}
                    notDistributed={notDistributed}
                    isEditable={false}
                    status={status}
                />

                <Calendar
                    plan={plan}
                    activity={null}

                />
            </div>
            <div style={{ display: skipCategory ? "none" : "" }}>
                {
                    subcategories && subcategories.length && (
                        subcategories.map((item) => (
                            <React.Fragment key={item.sid + item.position}>
                                <ActivityCategory
                                    tableRef={tableRef}
                                    key={item.sid}
                                    data={item}
                                    setExpandCategory={expandCategoryForActivity}
                                />
                            </React.Fragment>
                        ))
                    )
                }
                {
                    work_activities && work_activities.length && (
                        work_activities.map((item) => (
                            <React.Fragment key={item.sid + item.position}>
                                {{
                                    ACTIVITY: <Activity
                                        key={item.sid}
                                        data={item}
                                        onOpenRightColumn={handleOpenRightColumn}
                                        tableRef={tableRef}
                                        setExpandCategory={expandCategoryForActivity}
                                    />,
                                    ACTIVITY_MARKER: <ActivityMarker
                                        key={item.sid + item.position}
                                        data={item}
                                        tableRef={tableRef}
                                        setExpandCategory={expandCategoryForActivity}
                                    />,
                                }[item.type]}
                            </React.Fragment>
                        ))
                    )
                }
            </div>
        </div>
    );
};
