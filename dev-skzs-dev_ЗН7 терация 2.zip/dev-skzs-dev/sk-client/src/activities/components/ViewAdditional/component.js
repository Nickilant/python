import React from "react";
import { useDispatch, useSelector } from "react-redux";

import { push } from "connected-react-router";
import {
    selectCurrentLeafCategoryActivity,
    selectOpenedActivity,
    selectOpenedActivityDetails,
} from "../../selectors/activities";
import { SectionDocumentListItem } from "../../../documents/components/SectionDocumentsListItem/component";

import "./styles.scss";
import noFileIcon from "./assets/no_files.svg";
import { openRightColumnContainerAction } from "../../../shared/actions/RightColumnContainer/actions";
import { WIDGET_TYPES } from "../../../shared/constants/widgetTypes";
import AttachIcon from "./assets/plus.svg";
import { getURL } from "../../../shared/helpers/getPath";

export const ViewAdditional = () => {
    const dispatch = useDispatch();

    const activity = useSelector(selectOpenedActivity);
    const details = useSelector(selectOpenedActivityDetails);
    const activityParentCategory = useSelector(selectCurrentLeafCategoryActivity(activity.activityCategory));
    const routerPathParams = useSelector((state) => state.core.router);

    const handleAttach = () => {
        dispatch(openRightColumnContainerAction(
            WIDGET_TYPES.FILE_UPLOAD_FORM,
            { activity },
            true,
        ));
    };

    const handleOpenAOSR = (document) => {
        localStorage.removeItem("documents-list");

        const path = getURL(routerPathParams, ["projects", ["section", "executive-documents"], ["group", activityParentCategory.projectCategory.sid], ["document", document.sid]]);
        dispatch(push(path));
    };

    return (
        <div className="view-additional">
            <button onClick={handleAttach} className="attachment">
                <img src={AttachIcon} alt="Прикрепить" />
                Прикрепить документ
            </button>
            <div className="divider" />
            <div>
                {
                    details && details.aosr_acts.length
                        ? details.aosr_acts.map((it) => (
                            <div key={it.sid} className="document act">
                                <span className="icon" />
                                <span onClick={() => handleOpenAOSR(it)} className="title">
                                    Акт освидетельствования скрытых работ
                                    {" "}
                                    {it.act_number}
                                    {" "}
                                    от
                                    {" "}
                                    {it.act_date}
                                </span>
                            </div>
                        ))
                        : (
                            <div className="no-files">
                                <img src={noFileIcon} alt="Нет актов" />
                                Пока ещё никто не успел создать акт.
                            </div>
                        )
                }
            </div>
            <div className="divider" />
            <div>
                {
                    activity.documents.length
                        ? activity.documents.map((it) => (
                            <SectionDocumentListItem
                                item={{
                                    title: it.file.file_name,
                                    description: it.file.comment,
                                    ext: it.file.file_ext,
                                    size: it.file.size,
                                    link: it.file.file,
                                }}
                            />
                        ))
                        : (
                            <div className="no-files">
                                <img src={noFileIcon} alt="Нет файлов" />
                                Пока ещё никто не успел загрузить документов к этому разделу.
                            </div>
                        )
                }
            </div>
        </div>
    );
};
