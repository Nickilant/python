import React, { useEffect, useState } from "react";
import "./styles.scss";
import { useDispatch, useSelector } from "react-redux";
import cx from "classnames";
import { push } from "connected-react-router";
import { Header } from "../Header/component";
import { ActivityCategory } from "../ActivityCategory/component";
import {
    openActivity,
    toggleCommonDataInfo,
    toggleDistributionInfo,
    toggleExecutiveDocumentationInfo,
} from "../../actions/actions";
import {
    calcLeftOffset,
    selectActivityById,
    selectActivityFormMode,
    selectCurrentLeafCategoryActivity,
} from "../../selectors/activities";
import { openRightColumnContainerAction } from "../../../shared/actions/RightColumnContainer/actions";
import { WIDGET_TYPES } from "../../../shared/constants/widgetTypes";
import { PREVIEW_MODULES } from "../../../construction_control/base/widgets/DocumentPreviewColumn/previewModules";
import arrowIcon from "./assets/arrow.svg";
import { FORM } from "../../constants/activities";
import { getURL } from "../../../shared/helpers/getPath";

export const Table = ({ tableWrapperRef }) => {
    const dispatch = useDispatch();

    const showExecutiveDocumentationInfo = useSelector((state) => state.activities.activities.showExecutiveDocumentationInfo);
    const showCommonDataInfo = useSelector((state) => state.activities.activities.showCommonDataInfo);
    const showDistributionInfo = useSelector((state) => state.activities.activities.showDistributionInfo);
    const { editableActivity, editableActivityFields } = useSelector((state) => state.activities.activities);
    const editableActivityMode = useSelector(selectActivityFormMode);
    const calcLeftArrowOffset = useSelector(calcLeftOffset);

    const [lastOpened, setLastOpened] = useState(null);

    const items = useSelector((state) => state.activities.crud.items);

    const getOerderingIndex = (item) => {
        if (editableActivity && editableActivity.sid === item.sid) {
            return editableActivityFields.orderingIndex || item.orderingIndex;
        }

        return item.orderingIndex;
    };

    const iter = (item) => {
        if (item) {
            if (item.subcategories && item.subcategories.length) {
                item.subcategories.forEach((i) => iter(i));
            } else if (item.work_activities) {
                item.work_activities.sort((a, b) => getOerderingIndex(a) - getOerderingIndex(b));
            }
        }

        return item;
    };

    const createCondition = (item) => {
        if (item) {
            if (editableActivityMode === FORM.MODE.CREATE && item.work_activities && !item.work_activities.some((i) => i.sid === FORM.NEW_ACTIVITY_ID)) {
                const orderIndex = item.work_activities.length - 1;
                item.work_activities.splice(orderIndex, 0, editableActivity);
            } else if (!editableActivity && item.work_activities) {
                item.work_activities = item.work_activities.filter((i) => i.sid !== FORM.NEW_ACTIVITY_ID);
            }
        }

        return item;
    };

    const activitiesObj = createCondition(iter(items.tree && items.tree.list[0]));

    const routerPathParams = useSelector((state) => state.core.router);
    const state = useSelector((s) => s);

    const openActivityRightColumn = (id) => {
        const activity = selectActivityById(id)(state);

        if (activity) {
            const category = selectCurrentLeafCategoryActivity(activity.activityCategory)(state);

            activity.number = category.number;

            setLastOpened(id);
            dispatch(openActivity(activity));
            dispatch(openRightColumnContainerAction(WIDGET_TYPES.DOCUMENT_PREVIEW, { module: PREVIEW_MODULES.ACTIVITIES, activity }));
        }
    };

    useEffect(() => {
        const activityId = routerPathParams.activity;

        if (activityId && activitiesObj && activityId !== lastOpened) {
            openActivityRightColumn(activityId);
        }
    }, [routerPathParams.activity, activitiesObj]); // eslint-disable-line react-hooks/exhaustive-deps

    useEffect(() => {
        const activityId = routerPathParams.activity;

        if (activityId && activitiesObj && activityId === lastOpened) {
            const path = getURL(routerPathParams, ["projects", "section", "group"]);
            dispatch(push(path));
            setLastOpened(null);
        }
    }, [routerPathParams.group]); // eslint-disable-line react-hooks/exhaustive-deps

    const [baseArrowTopOffset, setBaseArrowTopOffset] = useState(0);

    setInterval(() => {
        if (tableWrapperRef.current) {
            setBaseArrowTopOffset((tableWrapperRef.current.offsetHeight - 15) / 2 + 8);
        }
    }, 400);

    const handleToggleExecutiveDocumentationInfo = () => dispatch(toggleExecutiveDocumentationInfo());
    const handleToggleCommonDataInfo = () => dispatch(toggleCommonDataInfo());
    const handleToggleDistributionInfo = () => dispatch(toggleDistributionInfo());

    return (
        <div className={cx(["component-table", { collapsed: !showExecutiveDocumentationInfo && !showCommonDataInfo && !showDistributionInfo }])}>
            <Header />
            {
                !editableActivity && (
                    <>
                        <div style={{ top: baseArrowTopOffset - 32 }} className={cx(["arrow-wrapper", { skip: !showExecutiveDocumentationInfo }])} onClick={handleToggleExecutiveDocumentationInfo}>
                            <div className="arrow" style={{ left: calcLeftArrowOffset(1) }}>
                                <div className="arrow-desc">Исполнительная документация</div>
                                <img src={arrowIcon} alt="свернуть" />
                            </div>
                        </div>
                        <div style={{ top: baseArrowTopOffset }} className={cx(["arrow-wrapper", { skip: !showCommonDataInfo }])} onClick={handleToggleCommonDataInfo}>
                            <div className="arrow" style={{ left: calcLeftArrowOffset(2) }}>
                                <div className="arrow-desc">Общие данные</div>
                                <img src={arrowIcon} alt="свернуть" />
                            </div>
                        </div>
                        <div style={{ top: baseArrowTopOffset + 32 }} className={cx(["arrow-wrapper", { skip: !showDistributionInfo }])} onClick={handleToggleDistributionInfo}>
                            <div className="arrow" style={{ left: calcLeftArrowOffset(3) }}>
                                <div className="arrow-desc">Распределение ФО</div>
                                <img src={arrowIcon} alt="свернуть" />
                            </div>
                        </div>
                    </>
                )
            }
            {
                activitiesObj && (
                    <ActivityCategory
                        tableRef={tableWrapperRef}
                        key={activitiesObj.sid}
                        data={activitiesObj}
                    />
                )
            }
        </div>

    );
};
