import React, { useEffect, useState } from "react";
import "./styles.scss";
import { useDispatch, useSelector } from "react-redux";
import "moment/locale/ru";
import { range } from "lodash";
import moment from "moment";
import cx from "classnames";
import { setDate } from "../../actions/actions";

export const Header = (props) => {
    const dispatch = useDispatch();

    const showExecutiveDocumentationInfo = useSelector((state) => state.activities.activities.showExecutiveDocumentationInfo);
    const showCommonDataInfo = useSelector((state) => state.activities.activities.showCommonDataInfo);
    const showDistributionInfo = useSelector((state) => state.activities.activities.showDistributionInfo);
    const maxDays = useSelector((state) => state.activities.activities.maxDays);
    const startDate = useSelector((state) => state.activities.activities.startDate);

    const [days, setDays] = useState([]);

    useEffect(() => {
        setDays(range(maxDays).map((i) => moment(startDate).add(i, "day").format("D")));
    }, [maxDays, startDate]); // eslint-disable-line react-hooks/exhaustive-deps

    const handleSetDay = (coef) => {
        dispatch(setDate(moment(startDate).add(coef, "day")));
    };

    return (
        <div className="component-header">
            {/* <div className="header-item level" /> */}
            <div className="header-item title">Наименование и шифр</div>
            {showExecutiveDocumentationInfo && (
                <>
                    <div className="header-item status">Статус ИТД</div>
                    <div className="header-item registered">Заактировано ФО</div>
                    <div className="header-item accumulated">Накоплено ФО</div>
                </>
            )}
            {showCommonDataInfo && (
                <>
                    <div className="header-item unit">Ед. изм.</div>
                    <div className="header-item total">Всего ФО</div>
                    <div className="header-item in-fact">Факт ФО</div>
                    <div className="header-item remainder">Остаток ФО</div>
                    <div className="header-item period-plan">Период работ План</div>
                    <div className="header-item period-in-fact">Период работ Факт</div>
                    <div className="header-item deviation">Отклонение</div>
                </>
            )}
            {showDistributionInfo && (
                <>
                    <div className="header-item distributed">Распределено ФО по суткам</div>
                    <div className="header-item not-distributed">Не распределено ФО по суткам</div>
                </>
            )}
            <div className={cx(["calendar-header", { week: maxDays === 7 }])}>
                <div onClick={() => handleSetDay(-1)} className="arrow prev" />
                <div onClick={() => handleSetDay(-1)} className="arrow-desc prev-desc">На день назад</div>
                {
                    days.map((d) => (
                        <div className="calendar-header-item">{d}</div>
                    ))
                }
                <div onClick={() => handleSetDay(1)} className="arrow-desc next-desc">На день вперед</div>
                <div onClick={() => handleSetDay(1)} className="arrow next" />
            </div>
        </div>
    );
};
