import React from "react";
// import cx from "classnames";
import { useDispatch } from "react-redux";

import "./styles.scss";
import { DatePicker } from "antd";
import locale from "antd/es/date-picker/locale/ru_RU";
import moment from "moment";
import { setInputValueDate } from "../../actions/actions";

const { RangePicker } = DatePicker;

export const FormInputDate = (props) => {
    const dispatch = useDispatch();
    const {
        defaultValue,
    } = props;

    const handleOnChange = (date, dateStr) => {
        dispatch(setInputValueDate(dateStr[0], dateStr[1]));
    };

    return (
        <div className="form-input-component form-input-component-date">
            <RangePicker
                defaultValue={[defaultValue.start && moment(defaultValue.start), defaultValue.end && moment(defaultValue.end)]}
                locale={locale}
                onChange={handleOnChange}
                format="YYYY-MM-DD"
            />
        </div>
    );
};
