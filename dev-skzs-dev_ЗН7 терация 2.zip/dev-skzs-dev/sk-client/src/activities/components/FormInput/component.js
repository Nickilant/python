import React from "react";
import cx from "classnames";
import { useDispatch } from "react-redux";

import "./styles.scss";
import { Input, InputNumber } from "antd";
import { setInputValueAction } from "../../actions/actions";
import { If } from "../../../shared/components/If/component";

export const FormInput = (props) => {
    const dispatch = useDispatch();
    const {
        name,
        meta,
        defaultValue,
        placeholder,
        className,
        type,
    } = props;

    const handleOnChange = (value) => {
        dispatch(setInputValueAction(name, value));
    };

    return (
        <>
            <If condition={type === "number"}>
                <div className={cx(["form-input-component", className])}>
                    <InputNumber
                        min={0}
                        defaultValue={defaultValue}
                        onChange={handleOnChange}
                        placeholder={placeholder}
                    />
                </div>
            </If>
            <If condition={!type || type === "text"}>
                <div className={cx(["form-input-component", className])}>
                    <Input
                        defaultValue={defaultValue}
                        onChange={(e) => handleOnChange(e.target.value)}
                        placeholder={placeholder}
                    />
                </div>
            </If>
        </>
    );
};
