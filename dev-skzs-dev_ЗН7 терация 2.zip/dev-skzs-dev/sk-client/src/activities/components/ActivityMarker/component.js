import React, { useEffect, useRef, useState } from "react";
import "./styles.scss";
import { useSelector } from "react-redux";
import { BasicInfo } from "../BasicInfo/component";
import { GeneralInfo } from "../GeneralInfo/component";
import { Calendar } from "../Calendar/component";
import { TYPE } from "../../constants/activities";
import { scrollToActivityObjRef } from "../../utils/activities";
import { selectCurrentFoundId } from "../../selectors/activities";

export const ActivityMarker = (props) => {
    const { data, setExpandCategory, tableRef } = props;

    const {
        title, level, number, sid,
    } = data;

    const { editableActivity } = useSelector((state) => state.activities.activities);
    const isEditable = sid === (editableActivity && editableActivity.sid);
    const currentFoundId = useSelector(selectCurrentFoundId);
    const [isSearched, setIsSearched] = useState(false);

    const ref = useRef(null);

    useEffect(() => {
        if (currentFoundId && currentFoundId === sid) {
            setIsSearched(true);
            setExpandCategory(false);
            setTimeout(() => {
                scrollToActivityObjRef(ref, tableRef);
            }, 0);
        } else {
            setIsSearched(false);
        }
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [currentFoundId]);

    return (
        <div ref={ref} className="component-activity-marker component-activity">
            <BasicInfo
                level={level}
                number={number}
                title={title}
                status={null}
                isEditable={isEditable}
                type={TYPE.ACTIVITY_MARKER}
                setExpandCategory={setExpandCategory}
                isSearched={isSearched}
            />

            <GeneralInfo
                isEditable={false}
            />

            <Calendar />
        </div>
    );
};
