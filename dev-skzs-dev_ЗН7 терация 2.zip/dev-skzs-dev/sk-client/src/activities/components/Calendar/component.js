import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { InputNumber, message } from "antd";

import cx from "classnames";
import "./styles.scss";
import { selectCurrentLeafCategoryActivity } from "../../selectors/activities";
import {
    calendarCRUDActions,
    selectEditableCalendarActivityAction,
    setValidCalendarInputsAction,
} from "../../actions/actions";
import { selectActiveProject } from "../../../projects/selectors/projects";
import EditIcon from "./assets/edit.svg";
import SuccessIcon from "./assets/success.svg";
import CloseIcon from "./assets/close.svg";
import { Modal } from "../../../shared/ConfirmModal/component";
import { dateFormatServer } from "../../../shared/constants/dateFormats";
import { activityFormValidators, validateActivityField } from "../../constants/activities";
import {
    canEditCalendarFactPredicate,
    canEditCalendarPlanPredicate,
} from "../../../construction_control/base/selectors/permissions";
import { loggedInUser } from "../../../users/selectors/permissions";

export const Calendar = ({ plan, activity }) => {
    const dispatch = useDispatch();

    const maxDays = useSelector((state) => state.activities.activities.maxDays);
    const project = useSelector(selectActiveProject);
    const validCalendarInputs = useSelector((state) => state.activities.activities.validCalendarInputs);
    const canEditPlan = useSelector((state) => canEditCalendarPlanPredicate(state));
    const canEditFact = useSelector((state) => {
        if (activity) {
            const companyName = loggedInUser(state).user.company;

            if (activity.contractor && companyName === activity.contractor.name) {
                return canEditCalendarFactPredicate(state);
            }
        }

        return false;
    });
    const currentEditableCalendarActivity = useSelector((state) => state.activities.activities.editableCalendarActivity);

    const [editPlan, setEditPlan] = useState(false);
    const [editFact, setEditFact] = useState(false);
    const [editedDays, setEditedDays] = useState({});
    const [errorsInputs, setErrorsInputs] = useState(new Set());
    const [modal, showModal] = useState(false);
    const [factAdded, setFactAdded] = useState(false);
    const [remainderEditedPlanDays, setRemainderEditedPlanDays] = useState(0);
    const [remainderEditedFactDays, setRemainderEditedFactDays] = useState(0);

    const activityCategoryId = activity ? activity.activityCategory : null;
    const activityCategory = useSelector(selectCurrentLeafCategoryActivity(activityCategoryId));

    const category = activityCategory && activityCategory.projectCategory;

    const entity = {};

    const source = {
        project,
        category,
        activity,
        entity,
    };

    const handleChangeInput = (value, object, key) => {
        if (key === "fact" && !factAdded) {
            setFactAdded(true);
        }

        setEditedDays({
            ...editedDays,
            [object.sid]: {
                ...editedDays[object.sid],
                [key]: value || 0,
                date: object.date,
                activity: activity.sid,
                oldValue: object[key],
            },
        });
    };

    useEffect(() => {
        let newSumPlan = 0;
        let newSumFact = 0;

        Object.values(editedDays).forEach((day) => {
            if (day.plan) {
                newSumPlan += day.oldValue ? day.plan - day.oldValue : day.plan;
            }
            if (day.fact) {
                newSumFact += day.oldValue ? day.fact - day.oldValue : day.fact;
            }
        });

        setRemainderEditedPlanDays(((activity && activity.notDistributed) || 0) - newSumPlan);
        setRemainderEditedFactDays(((activity && activity.remainder) || 0) - newSumFact);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [editedDays]);

    useEffect(() => {
        if (activity && currentEditableCalendarActivity !== activity.sid) {
            setEditFact(false);
            setEditPlan(false);
            setFactAdded(false);
            setEditedDays({});
            setErrorsInputs(new Set());
        }

        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [currentEditableCalendarActivity]);

    useEffect(() => {
        if (remainderEditedPlanDays < 0 || remainderEditedFactDays < 0) {
            message.error("Превышено максимально допустимое значение ФО");
        }

        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [remainderEditedFactDays, remainderEditedPlanDays]);

    const endAction = () => {
        setEditFact(false);
        setEditPlan(false);
        setFactAdded(false);
        setEditedDays({});
        setErrorsInputs(new Set());
        dispatch(selectEditableCalendarActivityAction(null));
    };

    const handleCancel = () => {
        endAction();
    };

    const handleSuccess = () => {
        if (validCalendarInputs) {
            if (factAdded) {
                showModal(true);
            } else if (Object.keys(editedDays).length) {
                confirm();
            } else {
                handleCancel();
            }
        }
    };

    const confirm = () => {
        const form = Object.entries(editedDays)
            .reduce((acc, [key, value]) => {
                if (key.indexOf("empty") < 0) {
                    acc.update.push({
                        sid: key,
                        plan: value.plan,
                        fact: value.fact,
                    });
                } else {
                    acc.create.push({
                        date: value.date.format(dateFormatServer),
                        plan: value.plan,
                    });
                }

                return acc;
            }, {
                update: [],
                create: [],
            });

        dispatch(calendarCRUDActions.use.UPDATE_ENTITY({
            source,
            form,
        }));

        showModal(false);
        endAction();
    };

    const validationConfig = {
        plan: [
            activityFormValidators.MAX_SIZE(7),
        ],
        fact: [
            activityFormValidators.MAX_SIZE(7),
            activityFormValidators.TARGET_NOT_NEGATIVE(remainderEditedFactDays),
        ],
    };

    useEffect(() => {
        const errorsCopy = new Set(errorsInputs);

        Object.entries(editedDays).forEach(([key, value]) => {
            const { plan, fact } = value;
            let config = [];

            if (plan) {
                config = validationConfig.plan;
            } else if (fact) {
                config = validationConfig.fact;
            }

            if (validateActivityField(config, plan || fact)) {
                errorsCopy.add(key);
            } else {
                errorsCopy.delete(key);
            }
        });

        setErrorsInputs(errorsCopy);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [remainderEditedPlanDays, remainderEditedFactDays]);

    useEffect(() => {
        if ((((remainderEditedPlanDays || remainderEditedFactDays) < 0) || !!errorsInputs.size) && validCalendarInputs) {
            dispatch(setValidCalendarInputsAction(false));
        } else if ((((remainderEditedPlanDays || remainderEditedFactDays) >= 0) && !errorsInputs.size) && !validCalendarInputs) {
            dispatch(setValidCalendarInputsAction(true));
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [errorsInputs, remainderEditedPlanDays, remainderEditedFactDays]);

    const handleEditPlan = () => {
        dispatch(selectEditableCalendarActivityAction(activity.sid));
        setEditPlan(true);
    };

    const handleEditFact = () => {
        dispatch(selectEditableCalendarActivityAction(activity.sid));
        setEditFact(true);
    };

    return (
        <div className={cx(["calendar table-item", { week: maxDays === 7 }])}>
            <div className="col col-title">
                <div className="row">План</div>
                <div className="row">Факт</div>
            </div>
            <div className={cx(["calendar-main-inner", { "inner-edit": (editFact || editPlan) && currentEditableCalendarActivity === activity.sid }, { "is-invalid": !validCalendarInputs && (editFact || editPlan) }])}>
                {
                    plan
                        ? (
                            <>
                                {
                                    Object.values(plan)
                                        .slice(0, maxDays)
                                        .map((item, index, arr) => (
                                            <div
                                                className={cx(["col", { last: index === arr.length - 1 }])}
                                                key={`${item.sid}`}
                                            >
                                                {
                                                    editPlan && currentEditableCalendarActivity === activity.sid
                                                        ? (
                                                            <InputNumber
                                                                className={cx(["row", { "error-validation-field": errorsInputs.has(item.sid) }])}
                                                                defaultValue={editedDays[item.sid] ? editedDays[item.sid].plan : item.plan}
                                                                disabled={!(item.permission && item.permission.plan)}
                                                                onChange={(value) => handleChangeInput(value, item, "plan")}
                                                                min={0}
                                                                placeholder={remainderEditedPlanDays}
                                                            />
                                                        )
                                                        : <div className="row">{item.plan || null}</div>
                                                }

                                                {
                                                    editFact && currentEditableCalendarActivity === activity.sid
                                                        ? (
                                                            <InputNumber
                                                                className={cx(["row", { "error-validation-field": errorsInputs.has(item.sid) }])}
                                                                defaultValue={editedDays[item.sid] ? editedDays[item.sid].fact : item.fact}
                                                                disabled={!(item.permission && item.permission.fact)}
                                                                onChange={(value) => handleChangeInput(value, item, "fact")}
                                                                placeholder={remainderEditedFactDays}
                                                                min={0}

                                                            />
                                                        )
                                                        : <div className="row">{item.fact || null}</div>
                                                }

                                            </div>
                                        ))
                                }
                                {
                                    activity && (
                                        <div className="edit-wrapper">
                                            {
                                                (editPlan || editFact) && currentEditableCalendarActivity === activity.sid
                                                    ? (
                                                        <>
                                                            <button className="edit success" onClick={handleSuccess}><img src={SuccessIcon} alt="Сохранить" /></button>
                                                            <button className="edit" onClick={handleCancel}><img src={CloseIcon} alt="Отменить" /></button>
                                                        </>
                                                    )
                                                    : (
                                                        <>
                                                            {
                                                                canEditPlan && (
                                                                    <button className="edit plan" onClick={handleEditPlan}><img src={EditIcon} alt="Редактировать" /></button>
                                                                )
                                                            }
                                                            {
                                                                canEditFact && (
                                                                    <button className="edit fact" onClick={handleEditFact}><img src={EditIcon} alt="Редактировать" /></button>
                                                                )
                                                            }
                                                        </>
                                                    )
                                            }
                                        </div>
                                    )
                                }
                            </>
                        )
                        : (
                            <>
                                <div className="col empty-col" />
                            </>
                        )
                }
            </div>
            <Modal
                className="section-activities-calendar-modal"
                title="Сохранить строку?"
                onOk={confirm}
                onCancel={() => showModal(false)}
                visible={modal}
                buttonText="Сохранить"
                footer={[
                    <button onClick={() => showModal(false)}>Вернуться назад</button>,
                    <button onClick={confirm}>Сохранить</button>,
                ]}
            >
                <div className="caution">
                    <div className="caution-inner">
                        После заполнения ячеек “Факт” в блоке суточных данных их нельзя будет отредактировать
                    </div>
                </div>
            </Modal>
        </div>
    );
};
