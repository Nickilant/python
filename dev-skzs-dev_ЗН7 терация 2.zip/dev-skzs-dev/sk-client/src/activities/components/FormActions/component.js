import React, { useState } from "react";
// import cx from "classnames";
import { useDispatch, useSelector } from "react-redux";

import "./styles.scss";
import {
    activitiesCRUDActions,
    selectEditableItem,
    setDirtyActivityFormAction,
    setInputValueAction,
} from "../../actions/actions";
import { selectActiveProject } from "../../../projects/selectors/projects";
import {
    selectActiveActivity,
    selectActivityFormMode,
    selectActivityFormValues,
    selectCurrentLeafCategoryActivity,
} from "../../selectors/activities";
import { FORM } from "../../constants/activities";
import { If } from "../../../shared/components/If/component";
import { selectedCategory } from "../../../categories/selectors/treeStructure";
import { Modal } from "../../../shared/ConfirmModal/component";

export const FormActions = () => {
    const dispatch = useDispatch();
    const mode = useSelector(selectActivityFormMode);
    const project = useSelector(selectActiveProject);

    const activity = useSelector(selectActiveActivity);
    const validForm = useSelector((state) => state.activities.activities.validActivityForm);
    const items = useSelector((state) => state.activities.crud.items);
    const activitiesList = items.tree ? items.tree.list : [];
    const categorySid = useSelector(selectedCategory);
    const [modal, showModal] = useState(false);
    const firstActivityCategory = activitiesList[0];

    const activityParentCategory = useSelector(selectCurrentLeafCategoryActivity(activity.activityCategory));

    const activityCategory = (mode === FORM.MODE.UPDATE) ? activityParentCategory : firstActivityCategory;
    const category = (mode === FORM.MODE.UPDATE) ? activityParentCategory.projectCategory : { sid: categorySid };
    const editableActivityFields = useSelector(selectActivityFormValues);
    const editableActivity = useSelector(selectActiveActivity);

    const form = {
        orderingIndex: editableActivity.orderingIndex,
        workType: editableActivity.workType.sid,
        activityCategory: activityCategory.sid,
        ...editableActivityFields,
    };

    const source = {
        project,
        entity: {
            activity,
            activityCategory: activityCategory.sid,
        },
        category,
    };

    const handleCancel = () => {
        dispatch(selectEditableItem(null));
    };

    const handleCreateActivity = () => {
        dispatch(activitiesCRUDActions.use.CREATE_ENTITY({
            source,
            form,
        }));
        dispatch(setDirtyActivityFormAction(false));
    };

    const handleUpdateActivity = () => {
        dispatch(activitiesCRUDActions.use.UPDATE_ENTITY({
            source,
            form,
        }));
        dispatch(setDirtyActivityFormAction(false));
    };

    const handleDeleteActivity = () => {
        showModal(true);
    };

    const confirmDeleteActivity = () => {
        dispatch(activitiesCRUDActions.use.DELETE_ENTITY({
            source,
        }));
    };

    const handleSubmitActivity = () => {
        dispatch(setDirtyActivityFormAction(true));

        if (validForm) {
            if (mode === FORM.MODE.CREATE) {
                handleCreateActivity();
            } else if (mode === FORM.MODE.UPDATE) {
                handleUpdateActivity();
            }
        }
    };

    const handleOrder = (direction) => {
        const currentValue = editableActivityFields.orderingIndex || activity.orderingIndex;
        const index = currentValue + direction;

        if (index > -1 && index < (activityCategory && activityCategory.work_activities && activityCategory.work_activities.length - 2)) {
            dispatch(setInputValueAction("orderingIndex", index));
        }
    };

    return (
        <div className="component-form-actions">
            <div className="form">
                <button onClick={() => handleOrder(-1.000001)} className="bg-img icon arrow" />
                <button onClick={() => handleOrder(1.000001)} className="bg-img icon arrow down" />
                <If condition={mode === FORM.MODE.UPDATE && !activity.in_fact}>
                    <button className="delete" onClick={handleDeleteActivity}>
                        Удалить строку
                    </button>
                </If>

                <button className="cancel" onClick={handleCancel}>Отменить</button>

                <button className="save" onClick={handleSubmitActivity}>Сохранить</button>
            </div>
            <Modal
                className="section-activities-form-action-modal"
                title="Удалить строку?"
                onOk={confirmDeleteActivity}
                onCancel={() => showModal(false)}
                visible={modal}
                buttonText="Сохранить"
                footer={[
                    <button onClick={() => showModal(false)}>Отменить</button>,
                    <button onClick={confirmDeleteActivity}>Удалить</button>,
                ]}
            >
                <div className="caution">
                    <div className="caution-inner">
                        Это действие необратимо и приведет к удалению всех данных, содержащихся в этой строке
                    </div>
                </div>
            </Modal>
        </div>
    );
};
