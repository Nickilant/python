import moment from "moment";
import { FORM, TYPE } from "../constants/activities";

export const selector = (state) => state;

export const selectCurrentFoundId = (state) => {
    const index = state.activities.activities.currentFoundIndex;

    if (index !== null) {
        return state.activities.activities.foundIds[index];
    }
};

export const selectActiveActivity = (state) => state.activities.activities.editableActivity;

export const selectOpenedActivity = (state) => {
    const a = state.activities.activities.openedActivity;
    if (a) {
        return selectActivityById(state.activities.activities.openedActivity.sid)(state);
    }
};

export const selectOpenedActivityDetails = (state) => {
    const a = state.activities.activities.openedActivity;
    if (a) {
        return state.activities.crud.details[a.sid];
    }
};

export const selectActivityFormValues = (state) => state.activities.activities.editableActivityFields;
export const selectActivityFormMode = (state) => {
    const activity = selectActiveActivity(state);
    if (activity) {
        return activity.sid === FORM.NEW_ACTIVITY_ID ? FORM.MODE.CREATE : FORM.MODE.UPDATE;
    }
};
export const selectActivityPlan = (state) => state.activities.crud.items.tree.list.map((item) => item.plan);

export const selectCurrentLeafCategoryActivity = (sid, customCondition) => (state) => {
    const iter = (item) => {
        if (customCondition ? customCondition(item, sid) : item.sid === sid) return item;
        if (item.subcategories) { // eslint-disable-next-line
            for (let i = 0; i < item.subcategories.length; i++) {
                const result = iter(item.subcategories[i]);
                if (result !== null) {
                    return result;
                }
            }
        }

        return null;
    };

    return iter(state.activities.crud.items.tree.list[0]);
};

export const selectCategoryByProjectId = (sid) => (state) => selectCurrentLeafCategoryActivity(sid, (item) => item.projectCategory && item.projectCategory.sid === sid)(state);

export const selectActivityById = (sid) => (state) => {
    const iter = (item) => {
        if (item.work_activities && item.work_activities.length) return item.work_activities.find((activity) => activity.sid === sid) || null;
        if (item.subcategories) { // eslint-disable-next-line
            for (let i = 0; i < item.subcategories.length; i++) {
                const result = iter(item.subcategories[i]);
                if (result !== null) {
                    return result;
                }
            }
        }

        return null;
    };

    return iter(state.activities.crud.items.tree.list[0]);
};

export const allIdsBySearch = (state) => {
    const { searchQuery } = state.activities.activities;

    const searchSubstr = (text) => {
        const indexStart = text.toLowerCase().indexOf(searchQuery.toLowerCase());
        return indexStart !== -1;
    };

    const iter = (item) => {
        const ids = [];

        if (searchSubstr(item.title)) {
            ids.push(item.sid);
        }
        if (item.work_activities) {
            const filteredActivities = item.work_activities.filter((activity) => searchSubstr(activity.title));
            ids.push(...filteredActivities);
        }
        if (item.subcategories) { // eslint-disable-next-line
            for (let i = 0; i < item.subcategories.length; i++) {
                const result = iter(item.subcategories[i]);
                ids.push(...result);
            }
        }

        return ids;
    };

    return iter(state.activities.crud.items.tree.list[0]);
};

function* range(from, to) {
    const f = to ? from : 0;
    const t = to || from;

    for (let i = f; i < t; i++) {
        yield i;
    }
}

export const getEmptyMonth = (type, month, year) => {
    const monthDaysArr = [...range(1, 32)];
    const emptyCalendar = {};
    const today = moment();

    monthDaysArr.forEach((i) => {
        const currentDate = moment(`${year}-${month + 1}-${i}`);

        emptyCalendar[i] = {
            day: i,
            plan: undefined,
            in_fact: undefined,
            sid: `empty-${i}`,
            permission: type === TYPE.ACTIVITY ? {
                plan: (currentDate.isAfter(today)) || (currentDate.isSame(today, "day")),
                fact: false,
            } : {
                plan: false,
                fact: false,
            },
        };
    });
    return emptyCalendar;
};

export const calcLeftOffset = (state) => (position) => {
    let baseOffset = 332 - 14;

    // eslint-disable-next-line default-case
    switch (position) {
        case 3:
            baseOffset += state.activities.activities.showDistributionInfo ? 274 : 0;
        // eslint-disable-next-line no-fallthrough
        case 2:
            baseOffset += state.activities.activities.showCommonDataInfo ? 650 : 0;
        // eslint-disable-next-line no-fallthrough
        case 1:
            baseOffset += state.activities.activities.showExecutiveDocumentationInfo ? 350 : 0;
    }

    return baseOffset;
};
