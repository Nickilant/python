import moment from "moment";
import { dateFormat } from "../../shared/constants/dateFormats";

export const activityFields = {
    level: "level",
    number: "number",
    title: "title",
    status: "status",
    unit: "unit",
    total: "total",
    in_fact: "in_fact",
    remainder: "remainder",
    period_plan: "period_plan",
    period_in_fact: "period_in_fact",
    deviation: "deviation",
    plan: "plan",
};

export const TYPE = {
    ACTIVITY: "ACTIVITY",
    ACTIVITY_CATEGORY: "ACTIVITY_CATEGORY",
    ACTIVITY_MARKER: "ACTIVITY_MARKER",
};

export const ENTITY_NAME = "activity";
export const MODULE_NAME = "activities";

export const CALENDAR_ENTITY_NAME = "calendar";

export const FORM = {
    NEW_ACTIVITY_ID: "NEW_ACTIVITY",
    MODE: {
        CREATE: "CREATE",
        UPDATE: "UPDATE",
    },
};

export const CALENDAR_DATE_TYPES = {
    WEEK: "WEEK",
    MONTH: "MONTH",
};

export const validateActivityField = (validatorsArr, value, payload = null) => validatorsArr && validatorsArr.some((validator) => validator(value, payload));

export const activityFormValidators = {
    REQUIRED: (value) => !value,
    MAX_SIZE: (maxSize) => (value) => String(value).length > maxSize,
    NOT_LESS_THEN: (targetValue) => (value) => +value < +targetValue,
    NOT_MORE_THEN: (targetValue) => (value) => +value > +targetValue,
    TARGET_NOT_NEGATIVE: (targetValue) => () => +targetValue < 0,
    IS_BEFORE: (targetDate, orSame = false) => (date) => {
        if (typeof date === "string") date = moment(date, dateFormat);
        return !(orSame ? moment(date).isSameOrBefore(moment(targetDate)) : moment(date).isBefore(moment(targetDate)));
    },
    IS_AFTER: (targetDate, orSame = false) => (date) => {
        if (typeof date === "string") date = moment(date, dateFormat);
        return !(orSame ? moment(date).isSameOrAfter(moment(targetDate)) : moment(date).isAfter(moment(targetDate)));
    },
};
