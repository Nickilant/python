import React from "react";
import "./styles.scss";
// import cx from "classnames";

export const Widget = (props) => (
    <div className="widget-Widget" />
);
