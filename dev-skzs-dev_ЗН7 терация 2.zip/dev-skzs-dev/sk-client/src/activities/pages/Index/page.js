import React, { useRef, useState } from "react";

import "./styles.scss";
import { useDispatch, useSelector } from "react-redux";
import { Table } from "../../components/Table/component";
import { TreeStructureContainer } from "../../../categories/containers/TreeStructure/container";
import { TableActions } from "../../components/TableActions/component";
import { Modal } from "../../../shared/ConfirmModal/component";
import { selectCategoryByProjectId } from "../../selectors/activities";
import { openModalAction } from "../../../shared/actions/Modal/actions";
import { MODAL_TYPES } from "../../../shared/constants/modalTypes";
import { selectNodeMSGAction } from "../../../categories/actions/actions";

export const ActivitiesPage = () => {
    const dispatch = useDispatch();
    const rightColumnOpened = useSelector((state) => state.shared.rightColumn.isOpened);
    const tableWrapperRef = useRef(null);
    const treeRef = useRef(null);
    const sidebarOpened = false;
    const state = useSelector((s) => s);

    const [modalDelete, showModalDelete] = useState(false);
    const [deleteFunction, setDeleteFunction] = useState(() => () => {});

    const deleteNode = (triggerDelete) => {
        setDeleteFunction(() => triggerDelete);
        showModalDelete(true);
    };

    const confirmDelete = () => {
        deleteFunction();
        showModalDelete(false);
    };

    const createNode = (triggerCreate, parentSid) => {
        const parentCategory = selectCategoryByProjectId(parentSid)(state);

        if (parentCategory && parentCategory.work_activities && parentCategory.work_activities.length - 2) {
            dispatch(openModalAction({
                widget: null,
                context: { description: `Внимание, прежде чем создать дочерний объект, удалите все работы в объекте ${parentCategory.projectCategory.name}` },
                type: MODAL_TYPES.ALERT,
            }));
        } else {
            triggerCreate();
        }
    };

    return (
        <div className={`page-activities activities-module ${rightColumnOpened && "right-column-opened"} ${sidebarOpened && "sidebar-opened"}`}>
            <TreeStructureContainer
                treeName="documents-list"
                rememberGroupInStorage
                showDeleteConfirm={false}
                deleteMiddleware={deleteNode}
                createMiddleware={createNode}
                customSelectNodeAction={selectNodeMSGAction}
                ref={treeRef}
            />
            <div className="content">
                <TableActions treeRef={treeRef} tableWrapperRef={tableWrapperRef} />
                <div className="table-wrapper" ref={tableWrapperRef}>
                    <Table tableWrapperRef={tableWrapperRef} />
                </div>
            </div>
            <Modal
                className="section-activities-delete-node-modal"
                title="Удалить объект?"
                onOk={confirmDelete}
                onCancel={() => showModalDelete(false)}
                visible={modalDelete}
                footer={[
                    <button onClick={() => showModalDelete(false)}>Отменить</button>,
                    <button onClick={confirmDelete}>Удалить</button>,
                ]}
            >
                <div className="caution">
                    <div className="caution-inner">
                        Это действие необратимо и приведет к удалению всех данных, находящихся в этом объекте
                    </div>
                </div>
            </Modal>
        </div>
    );
};
