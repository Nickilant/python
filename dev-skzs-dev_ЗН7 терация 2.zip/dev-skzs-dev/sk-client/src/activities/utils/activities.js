export const scrollToActivityObjRef = (ref, tableRef) => {
    tableRef.current.scrollTo(0, ref.current.offsetTop - 200);
};
