import { combineReducers } from "redux";
import { activitiesReducer } from "./activities";
import { crudReducerFactory } from "../../shared/reducers/crudFactory";
import { ENTITY_NAME, MODULE_NAME } from "../constants/activities";

export const activityReducer = combineReducers({
    activities: activitiesReducer,
    crud: crudReducerFactory(MODULE_NAME, ENTITY_NAME, "sid"),
    calendarCrud: crudReducerFactory("calendar", "day", "sid"),
});
