import moment from "moment";
import {
    ACTIVITIES_CALENDAR, ACTIVITIES_FORM, ACTIVITIES_TABLE, ACTIVITIES_WORK_TYPES,
} from "../actions/actionTypes";
import { LAYOUT_RIGHT_COLUMN_CONTAINER_CLOSE } from "../../shared/actions/RightColumnContainer/actionTypes";

const initialState = {
    editableActivity: null,
    editableActivityFields: {},
    editableCalendarActivity: null,
    searchQuery: "",
    foundIds: [],
    currentFoundIndex: null,
    showExecutiveDocumentationInfo: true,
    showCommonDataInfo: true,
    showDistributionInfo: true,
    maxDays: 7,
    startDate: moment().startOf("month"),
    openedActivity: null,
    dirtyActivityForm: false,
    validActivityForm: true,
    validCalendarInputs: true,
    activityTypes: [],
    activityTypeDefaultSid: null,
};

export const activitiesReducer = (state = initialState, action) => {
    switch (action.type) {
        case ACTIVITIES_FORM.SELECT_EDITABLE_ITEM: {
            return {
                ...state,
                editableActivity: action.payload.activity,
                dirtyActivityForm: action.payload.activity ? state.dirtyActivityForm : initialState.dirtyActivityForm,
                validActivityForm: action.payload.activity ? state.validActivityForm : initialState.validActivityForm,
                showExecutiveDocumentationInfo: !!action.payload.activity || state.showExecutiveDocumentationInfo,
                showCommonDataInfo: !!action.payload.activity || state.showCommonDataInfo,
                showDistributionInfo: !!action.payload.activity || state.showDistributionInfo,
                editableActivityFields: initialState.editableActivityFields,
            };
        }
        case ACTIVITIES_TABLE.OPEN_ACTIVITY: {
            return {
                ...state,
                openedActivity: action.payload.activity,
            };
        }
        case ACTIVITIES_FORM.SET_VALUE: {
            const { name, value } = action.payload;
            return {
                ...state,
                editableActivityFields: {
                    ...state.editableActivityFields,
                    [name]: value,
                },
            };
        }
        case ACTIVITIES_FORM.SET_VALUE_DATE: {
            const { start, end } = action.payload;

            return {
                ...state,
                editableActivityFields: {
                    ...state.editableActivityFields,
                    period_plan_start: start,
                    period_plan_end: end,
                },
            };
        }
        case ACTIVITIES_CALENDAR.SELECT_EDITABLE_ACTIVITY: {
            const { activitySid } = action.payload;

            return {
                ...state,
                editableCalendarActivity: activitySid,
                validCalendarInputs: activitySid !== state.editableCalendarActivity ? initialState.validCalendarInputs : state.validCalendarInputs,
            };
        }
        case ACTIVITIES_FORM.SET_DIRTY_FORM: {
            const { value } = action.payload;
            return {
                ...state,
                dirtyActivityForm: value,
            };
        }
        case ACTIVITIES_FORM.SET_VALID_FORM: {
            const { value } = action.payload;
            return {
                ...state,
                validActivityForm: value,
            };
        }
        case ACTIVITIES_TABLE.SEARCH: {
            const { searchQuery, tree } = action.payload;

            const searchSubstr = (text) => {
                const indexStart = text.toLowerCase().indexOf(searchQuery.toLowerCase());
                return indexStart !== -1;
            };

            const iter = (item) => {
                const ids = [];

                if (searchSubstr(item.title)) {
                    ids.push(item.sid);
                }
                if (item.work_activities) {
                    const filteredActivities = item.work_activities
                        .filter((activity) => searchSubstr(activity.title))
                        .map((activity) => activity.sid);
                    ids.push(...filteredActivities);
                }
                if (item.subcategories) { // eslint-disable-next-line
                    for (let i = 0; i < item.subcategories.length; i++) {
                        const result = iter(item.subcategories[i]);
                        ids.push(...result);
                    }
                }

                return ids;
            };

            const foundIds = iter(tree);

            return {
                ...state,
                searchQuery,
                foundIds,
                currentFoundIndex: foundIds.length !== 0 ? 0 : null,
            };
        }
        case ACTIVITIES_TABLE.CHANGE_CURRENT_FOUND_INDEX: {
            const { indexCoef } = action.payload;
            let futureIndex = state.currentFoundIndex + indexCoef;

            if (futureIndex >= state.foundIds.length || futureIndex < 0) {
                futureIndex = state.currentFoundIndex;
            }

            return {
                ...state,
                currentFoundIndex: futureIndex,
            };
        }
        case ACTIVITIES_TABLE.TOGGLE_EXECUTIVE_DOCUMENTATION_INFO: {
            return {
                ...state,
                showExecutiveDocumentationInfo: !state.showExecutiveDocumentationInfo,
            };
        }
        case ACTIVITIES_TABLE.TOGGLE_COMMON_DATA_INFO: {
            return {
                ...state,
                showCommonDataInfo: !state.showCommonDataInfo,
            };
        }
        case ACTIVITIES_TABLE.TOGGLE_DISTRIBUTION_INFO: {
            return {
                ...state,
                showDistributionInfo: !state.showDistributionInfo,
            };
        }
        case ACTIVITIES_TABLE.SHOW_ALL_INFO: {
            return {
                ...state,
                showExecutiveDocumentationInfo: true,
                showCommonDataInfo: true,
                showDistributionInfo: true,
            };
        }
        case ACTIVITIES_TABLE.HIDE_ALL_INFO: {
            return {
                ...state,
                showExecutiveDocumentationInfo: false,
                showCommonDataInfo: false,
                showDistributionInfo: false,
            };
        }
        case ACTIVITIES_CALENDAR.DATE_INCREMENT: {
            const { lastDay, maxDay } = state;
            const newLastDay = lastDay < maxDay ? lastDay + 1 : maxDay;

            return {
                ...state,
                lastDay: newLastDay,
            };
        }
        case ACTIVITIES_CALENDAR.DATE_DECREMENT: {
            const { lastDay } = state;
            const newLastDay = lastDay > 7 ? lastDay - 1 : 7;

            return {
                ...state,
                lastDay: newLastDay,
            };
        }
        case ACTIVITIES_CALENDAR.SET_DATE: {
            const { date } = action.payload;

            return {
                ...state,
                startDate: date,
                lastDay: 7,
            };
        }
        case ACTIVITIES_CALENDAR.SET_DATE_INFO: {
            const { maxDays } = action.payload;
            const isMonth = maxDays === 31;

            return {
                ...state,
                showExecutiveDocumentationInfo: !isMonth,
                showCommonDataInfo: !isMonth,
                showDistributionInfo: !isMonth,
                dirtyActivityForm: isMonth ? initialState.dirtyActivityForm : state.dirtyActivityForm,
                validActivityForm: isMonth ? initialState.validActivityForm : state.validActivityForm,
                editableActivity: isMonth ? initialState.editableActivity : state.editableActivity,
                editableActivityFields: isMonth ? initialState.editableActivityFields : state.editableActivityFields,
                maxDays,
            };
        }
        case ACTIVITIES_CALENDAR.SET_VALID_INPUTS: {
            const { value } = action.payload;
            return {
                ...state,
                validCalendarInputs: value,
            };
        }
        case LAYOUT_RIGHT_COLUMN_CONTAINER_CLOSE: {
            const { openedActivity } = initialState;
            return {
                ...state,
                openedActivity,
            };
        }
        case ACTIVITIES_WORK_TYPES.SET_LIST: {
            const { list } = action.payload;

            const defaultSid = list.find((item) => item.label === "Не определен");

            return {
                ...state,
                activityTypes: list,
                activityTypeDefaultSid: defaultSid ? defaultSid.value : null,
            };
        }
        default:
            return state;
    }
};
