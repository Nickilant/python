import { all } from "@redux-saga/core/effects";
import { createCRUDSaga } from "../../shared/sagas/entityCrudFactory";
import { ENTITY_NAME, MODULE_NAME } from "../constants/comments";
import { commentsSaga } from "./comments";

const commentsCrudSaga = createCRUDSaga({
    moduleName: MODULE_NAME,
    entityName: ENTITY_NAME,
    idField: "sid",

    getPrefixPath: ({ payload }) => `/projects/${payload.source.project.key}/${payload.source.entity.type}s/${payload.source.entity.id}/${MODULE_NAME}`,
    entityPath: ({ payload }) => `/projects/${payload.source.project.key}/${payload.source.entity.type}s/${payload.source.entity.id}/${MODULE_NAME}/${payload.source.sid}/`,
    postPath: ({ payload }) => `/projects/${payload.source.project.key}/${payload.source.entity.type}s/${payload.source.entity.id}/${MODULE_NAME}/`,
});

export function* commentsRootSaga() {
    yield all([
        commentsCrudSaga(),
        commentsSaga(),
    ]);
}
