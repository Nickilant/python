export const listActivitiesInConverters = {
    ACTIVITY: (item) => 0,
};
