import { put, takeEvery } from "@redux-saga/core/effects";
import { documentsCRUDActions } from "../../documents/actions/actions";
import {
    mapsCRUDActions,
} from "../../construction_control/extra_2d/actions/actions";
import { commentsCRUDActions } from "../actions/actions";

export function* commentsSaga() {
    function* watchCommentsCreated({ payload }) {
        yield put(commentsCRUDActions.use.LIST_ENTITIES({
            source: {
                project: payload.source.project,
                category: payload.source.category,
            },
        }));

        if (payload.source.entity) {
            yield put(documentsCRUDActions.use.GET_ENTITY_DETAILS({
                source: {
                    ...payload.source.entity,
                    project: payload.source.project,
                },
            }));
        }
    }

    function* watchCommentsDeleted({ payload }) {
        yield put(mapsCRUDActions.use.LIST_ENTITIES({
            source: {
                project: payload.source.project,
                category: payload.source.category,
            },
        }));

        if (payload.source.entity) {
            yield put(documentsCRUDActions.use.GET_ENTITY_DETAILS({
                source: {
                    ...payload.source.entity,
                    project: payload.source.project,
                },
            }));
        }
    }

    yield takeEvery(commentsCRUDActions.CREATE_ENTITY_COMPLETE, watchCommentsCreated);
    yield takeEvery(commentsCRUDActions.DELETE_ENTITY_COMPLETE, watchCommentsDeleted);
}
