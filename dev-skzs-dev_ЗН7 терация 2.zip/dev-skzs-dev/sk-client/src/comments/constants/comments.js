export const MODULE_NAME = "comments";
export const ENTITY_NAME = "comment";
