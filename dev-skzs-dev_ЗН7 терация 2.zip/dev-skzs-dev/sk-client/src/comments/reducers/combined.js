import { combineReducers } from "redux";
import { crudReducerFactory } from "../../shared/reducers/crudFactory";
import { ENTITY_NAME, MODULE_NAME } from "../constants/comments";

export const commentsReducers = combineReducers({
    crud: crudReducerFactory(MODULE_NAME, ENTITY_NAME, "sid"),
});
