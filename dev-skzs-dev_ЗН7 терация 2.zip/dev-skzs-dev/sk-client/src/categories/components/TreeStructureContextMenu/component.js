import React from "react";
import cx from "classnames";

import "./styles.scss";
import { useSelector } from "react-redux";
import { confirm } from "../../../shared/ConfirmModal/component";
import { canEditTreeStructurePredicate } from "../../../construction_control/base/selectors/permissions";

export const TreeStructureContextMenu = (props) => {
    const {
        renameNode,
        createNode,
        deleteNode,
        copyNode,
        pasteNode,
        pasteDisabled,
        showDeleteConfirm = true,
    } = props;

    const deleteConfirm = (actionOk) => () => {
        confirm({
            content: "Вы уверены что хотите удалить этот элемент?",
            onOk() {
                actionOk();
            },
        });
    };

    const canEditNode = useSelector((state) => canEditTreeStructurePredicate(state));

    const state = [
        {
            title: "Создать вложенный объект",
            key: "create-nesting-object",
            disabled: false,
            onClick: createNode,
        },
        {
            title: "Переименовать",
            key: "rename",
            disabled: false,
            onClick: renameNode,
        },
        {
            title: "Копировать",
            key: "copy",
            disabled: false,
            onClick: copyNode,
        },
        {
            title: "Вставить вложенный объект",
            key: "paste",
            disabled: pasteDisabled,
            onClick: pasteNode,
        },
        {
            title: "Удалить",
            key: "delete",
            disabled: false,
            onClick: showDeleteConfirm ? deleteConfirm(deleteNode) : deleteNode,
        },
    ];
    return canEditNode && (
        <ul className="context-menu">
            {state.map((item) => (
                <li
                    className={cx("context-menu-item", { disabled: item.disabled })}
                    onClick={item.disabled ? () => null : item.onClick}
                    key={item.key}
                >
                    {item.title}
                </li>
            ))}
        </ul>
    );
};
