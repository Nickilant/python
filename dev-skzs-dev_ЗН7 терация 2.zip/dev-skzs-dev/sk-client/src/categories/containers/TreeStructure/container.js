import React, {
    forwardRef, useEffect, useImperativeHandle, useState,
} from "react";
import cx from "classnames";
import { connect, useDispatch, useSelector } from "react-redux";
import {
    Form, Input, Modal, notification, Tree,
} from "antd";
import { ResizableBox } from "react-resizable";
import { push } from "connected-react-router";

import Search from "antd/es/input/Search";
import {
    categoriesCRUDActions,
    closeContextMenuAction,
    expandNodesAction,
    openContextMenuAction,
    searchNodesAction,
    selectNodeAction,
} from "../../actions/actions";
import { TreeStructureContextMenu } from "../../components/TreeStructureContextMenu/component";

import "./styles.scss";
import {
    currentCategory, findNodeById, getPath, searchTreeNodes,
} from "../../selectors/treeStructure";
import { selectActiveProject } from "../../../projects/selectors/projects";
import { INPUT_NAME_MODE_COPYPASTE, INPUT_NAME_MODE_CREATE, INPUT_NAME_MODE_UPDATE } from "../../constants/categories";
import { canManageCategories } from "../../selectors/permissions";
import { getURL } from "../../../shared/helpers/getPath";
import { categoryByName } from "../../../core/selectors/menu";

const { TreeNode } = Tree;

const stringSort = (key, order = 1) => (a, b) => {
    const aValue = a[key].toLowerCase();
    const bValue = b[key].toLowerCase();
    if (aValue < bValue) {
        return order * -1;
    }
    if (aValue < bValue) {
        return order;
    }
    return 0;
};

const TreeStructure = forwardRef(({
    tree,
    expandedKeys,
    searchQuery,
    expandNodes,
    searchNodes,
    selectedPath,
    attachmentForm,
    openContextMenu,
    contextMenuNode,
    closeContextMenu,
    createNode,
    project,
    updateNode,
    deleteNode,
    treeName,
    routerPathParams,
    group,
    deleteMiddleware,
    createMiddleware,
    showDeleteConfirm,
    disableContext = false,
    rememberGroupInStorage = false,
    currentSelectedCategory,
    selectedCategory,
    customSelectNodeAction = selectNodeAction,
}, ref) => {
    const [modalVisible, setModalVisible] = useState(false);

    const handleSearch = (e) => {
        searchNodes(e.target.value, treeName);
    };

    const manageCategories = useSelector(canManageCategories);
    const deletedCategories = useSelector((state) => state.categories.crud.deleted);
    const crudCategories = useSelector((state) => state.categories.crud.items);
    const [parentCategory, setParentCategory] = useState(null);

    const selectNode = (id) => {
        dispatch(customSelectNodeAction(id, treeName));
    };

    useEffect(() => {
        if (tree.length) {
            // openDocument(item);
            selectNode(group);
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [routerPathParams.group, tree, crudCategories]);

    const dispatch = useDispatch();

    const [prevNode, setPrevNode] = useState(null);

    const handleSelectNode = (ids) => {
        const id = ids.length ? ids[0] : prevNode;
        setPrevNode(id);
        if (treeName === "documents-list") {
            const path = getURL(routerPathParams, ["projects", "section", ["group", id], "document", "journals", "activity"]);

            if (rememberGroupInStorage) {
                localStorage.setItem(treeName, id);
            }

            dispatch(push(path));
        } else {
            selectNode(id);
        }
    };

    useEffect(() => {
        if (deletedCategories[group]) {
            handleSelectNode([parentCategory]);
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [deletedCategories]);

    const handleChange = (field, e) => {
        if (field === "name") {
            if (e.target.value) {
                setValidateStatus("success");
            } else {
                setValidateStatus("error");
            }
        }
    };
    useEffect(() => {
        if (treeName === "documents-list") {
            let id = group;

            if (rememberGroupInStorage) {
                const nodeIsPresent = findNodeById(localStorage.getItem(treeName))(selectedCategory);
                id = nodeIsPresent ? nodeIsPresent.sid : id;
            }

            handleSelectNode([id]);
        }

        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [routerPathParams.section, routerPathParams.group, group]);

    const handleRightClick = (e) => {
        if (attachmentForm || !manageCategories || disableContext) {
            return null;
        }
        openContextMenu(e.node.props.eventKey, treeName);
        return null;
    };

    const [inputNameParams, setInputNameParams] = useState({
        show: false, sid: null, mode: null, value: "",
    });

    const handleCreateNode = (sid) => {
        setInputNameParams({
            show: true, sid, mode: INPUT_NAME_MODE_CREATE,
        });

        const triggerFunc = () => handleOpenModal();

        if (createMiddleware) {
            createMiddleware(triggerFunc, sid);
        } else {
            triggerFunc();
        }
    };

    const handleRenameNode = (sid) => {
        setInputNameParams({
            show: true, sid, mode: INPUT_NAME_MODE_UPDATE,
        });
        handleOpenModal();
    };

    const handleDeleteNode = (sid) => {
        const triggerFunc = () => {
            setParentCategory(currentSelectedCategory.parent_category);
            deleteNode({
                source: {
                    project,
                    sid,
                },
            });
        };

        if (deleteMiddleware) {
            deleteMiddleware(triggerFunc);
        } else {
            triggerFunc();
        }
    };

    const [copyNode, setCopyNode] = useState({ sid: null, name: "", cipher: "" });

    const handleCopyNode = (sid, name) => {
        notification.open({
            message: "Скопировано в буфер обмена",
            onClick: () => {
            },
        });
        setCopyNode({ sid, name });
    };

    const handlePasteNode = (sid) => {
        setInputNameParams({
            show: true, sid, mode: INPUT_NAME_MODE_COPYPASTE,
        });
    };

    function handleExpandNode(ids) {
        expandNodes(ids, treeName);
    }

    const [inputNodeName, setInputNodeName] = useState("");
    const [inputNodeCipher, setInputNodeCipher] = useState("");
    const [inputNodePositionGp, setInputNodePositionGp] = useState("");
    const [inputNodeStamp, setInputNodeStamp] = useState("");
    const [inputNodeSetNumber, setInputNodeSetNumber] = useState("");
    const [inputNodeTagNumber, setInputNodeTagNumber] = useState("");
    const [inputNodeRevision, setInputNodeRevision] = useState("");
    const [validateStatus, setValidateStatus] = useState("success");
    function handleClearNodeInput() {
        setInputNodeName("");
        setInputNodeCipher("");
        setInputNodePositionGp("");
        setInputNodeStamp("");
        setInputNodeSetNumber("");
        setInputNodeTagNumber("");
        setInputNodeRevision("");
        setValidateStatus("success");
        setModalVisible(false);
    }
    const handleInputNodeName = ({
        cipher, name, positionGp, stamp, setNumber, tagNumber, revision,
    }) => {
        const resultCipher = inputNodeCipher || cipher;
        const resultName = inputNodeName || name;
        const resultPositionGp = inputNodePositionGp || positionGp;
        const resultStamp = inputNodeStamp || stamp;
        const resultSetNumber = inputNodeSetNumber || setNumber;
        const resultTagNumber = inputNodeTagNumber || tagNumber;
        const resultRevision = inputNodeRevision || revision;

        if (!resultName) {
            setValidateStatus("error");
            return;
        }

        const form = {
            name: resultName,
            cipher: resultCipher || "",
            position_gp: resultPositionGp || "",
            stamp: resultStamp || "",
            set_number: resultSetNumber || "",
            tag_number: resultTagNumber || "",
            revision: resultRevision || "",
        };
        switch (inputNameParams.mode) {
            case INPUT_NAME_MODE_CREATE: {
                createNode({
                    source: {
                        project,
                    },
                    form: {
                        ...form,
                        sort: 1,
                        parent_category: inputNameParams.sid,
                    },
                });
                break;
            }
            case INPUT_NAME_MODE_UPDATE: {
                updateNode({
                    source: {
                        project,
                        sid: inputNameParams.sid,
                    },
                    form: {
                        ...form,
                    },
                });
                break;
            }
            case INPUT_NAME_MODE_COPYPASTE: {
                createNode({
                    source: {
                        project,
                    },
                    form: {
                        ...form,
                        sort: 1,
                        parent_category: inputNameParams.sid,
                        prototype_category: copyNode.sid,
                    },
                });
                break;
            }
            default: {
                break;
            }
        }
        setInputNameParams({ show: false, sid: null, mode: null });
        handleClearNodeInput();
    };

    const getNodeDefaultValue = (inputParams, node, field) => {
        switch (inputParams.mode) {
            case INPUT_NAME_MODE_CREATE: {
                return null;
            }
            case INPUT_NAME_MODE_UPDATE: {
                return node[field];
            }
            case INPUT_NAME_MODE_COPYPASTE: {
                if (field === "name") return `${copyNode.name} - Копия`;
                return copyNode[field];
            }
            default: {
                return null;
            }
        }
    };

    const handleOpenModal = () => {
        setModalVisible(true);
    };
    const handleCloseModal = () => {
        setModalVisible(false);
        handleClearNodeInput();
    };
    const renderTreeNodes = (nodes) => nodes.map((node) => (
        <TreeNode
            key={node.sid}
            // style={(inputNameParams.sid === node.sid) ? { height: 52 } : {}}
            className={cx([
                selectedPath.includes(node.sid) ? "path" : "not-path",
                { found: expandedKeys.includes(node.sid) && searchQuery },
            ])}
            title={(
                <div className="node-content">
                    {
                        `${node.cipher} - ${node.name}`
                    }
                    {
                        inputNameParams.sid === node.sid
                        && (
                            <Modal
                                className="category-modal"
                                width="584px"
                                visible={modalVisible}
                                title={inputNameParams.mode === INPUT_NAME_MODE_CREATE ? "Создать новый объект" : "Редактировать объект"}
                                onCancel={() => handleCloseModal()}
                                destroyOnClose
                            >
                                <Form className="category-form-container">
                                    <Form.Item className="item-full inline-block">
                                        <span className="custom-label">Шифр объекта</span>
                                        <Input
                                            className={cx(["input-name", { new: inputNameParams.mode === INPUT_NAME_MODE_CREATE }])}
                                            onBlur={({ target: { value } }) => setInputNodeCipher(value)}
                                            defaultValue={node.cipher}
                                            autoFocus
                                        />
                                    </Form.Item>
                                    <Form.Item
                                        className="item-full inline-block"
                                        required
                                        validateStatus={validateStatus}
                                    >
                                        <span className="custom-label">Наименование объекта</span>
                                        <div className="validated-field">
                                            <Input
                                                required
                                                className={cx(["input-name", { new: inputNameParams.mode === INPUT_NAME_MODE_CREATE }])}
                                                onBlur={({ target: { value } }) => {
                                                    setInputNodeName(value);
                                                }}
                                                onChange={(event) => handleChange("name", event)}
                                                defaultValue={getNodeDefaultValue(inputNameParams, node, "name")}
                                            />
                                            <span className="error-validation" hidden={validateStatus === "success"}>{validateStatus === "error" ? "Это поле обязательно." : ""}</span>
                                        </div>
                                    </Form.Item>
                                    <Form.Item className="item-full inline-block">
                                        <span className="custom-label">
                                            Позиция ГП/ участок/
                                            <br />
                                            код подобъекта
                                        </span>
                                        <Input
                                            className={cx(["input-name", { new: inputNameParams.mode === INPUT_NAME_MODE_CREATE }])}
                                            onBlur={({ target: { value } }) => setInputNodePositionGp(value)}
                                            defaultValue={getNodeDefaultValue(inputNameParams, node, "position_gp")}
                                        />
                                    </Form.Item>
                                    <Form.Item className="item-full inline-block">
                                        <span className="custom-label">Марка (дисциплина)</span>
                                        <Input
                                            className={cx(["input-name", { new: inputNameParams.mode === INPUT_NAME_MODE_CREATE }])}
                                            onBlur={({ target: { value } }) => setInputNodeStamp(value)}
                                            defaultValue={getNodeDefaultValue(inputNameParams, node, "stamp")}
                                        />
                                    </Form.Item>
                                    <Form.Item className="item-full inline-block">
                                        <span className="custom-label">Номер комплекта</span>
                                        <Input
                                            className={cx(["input-name", { new: inputNameParams.mode === INPUT_NAME_MODE_CREATE }])}
                                            onBlur={({ target: { value } }) => setInputNodeSetNumber(value)}
                                            defaultValue={getNodeDefaultValue(inputNameParams, node, "set_number")}
                                            onChange={({ target: { value } }) => setInputNodeSetNumber(value)}
                                        />
                                    </Form.Item>
                                    <Form.Item className="item-full inline-block">
                                        <span className="custom-label">Теговый номер объекта КС</span>
                                        <Input
                                            className={cx(["input-name", { new: inputNameParams.mode === INPUT_NAME_MODE_CREATE }])}
                                            onBlur={({ target: { value } }) => setInputNodeTagNumber(value)}
                                            defaultValue={getNodeDefaultValue(inputNameParams, node, "tag_number")}
                                        />
                                    </Form.Item>
                                    <Form.Item className="item-full inline-block">
                                        <span className="custom-label">Версия (ревизия)</span>
                                        <Input
                                            className={cx(["input-name", { new: inputNameParams.mode === INPUT_NAME_MODE_CREATE }])}
                                            onBlur={({ target: { value } }) => setInputNodeRevision(value)}
                                            defaultValue={getNodeDefaultValue(inputNameParams, node, "revision")}
                                        />
                                    </Form.Item>
                                    <button
                                        onClick={() => handleCloseModal()}
                                        className="cancel-button"
                                    >
                                        Отмена
                                    </button>
                                    <button
                                        className="submit-button"
                                        id="node-name-input"
                                        onClick={() => {
                                            if (validateStatus === "success") {
                                                handleInputNodeName({
                                                    cipher: node.cipher,
                                                    name: getNodeDefaultValue(inputNameParams, node, "name"),
                                                    position_gp: getNodeDefaultValue(inputNameParams, node, "position_gp"),
                                                    brand: getNodeDefaultValue(inputNameParams, node, "brand"),
                                                    set_number: getNodeDefaultValue(inputNameParams, node, "set_number"),
                                                    tag_number: getNodeDefaultValue(inputNameParams, node, "tag_number"),
                                                    version: getNodeDefaultValue(inputNameParams, node, "version"),
                                                });
                                            }
                                        }}
                                    >
                                        {inputNameParams.mode === INPUT_NAME_MODE_CREATE ? "Создать" : "Сохранить"}
                                    </button>
                                </Form>
                            </Modal>
                        )
                    }

                    {node.sid === contextMenuNode && !disableContext
                    && (
                        <TreeStructureContextMenu
                            createNode={() => handleCreateNode(node.sid)}
                            deleteNode={() => handleDeleteNode(node.sid)}
                            renameNode={() => handleRenameNode(node.sid)}
                            copyNode={() => handleCopyNode(node.sid, node.name)}
                            pasteNode={() => handlePasteNode(node.sid)}
                            pasteDisabled={copyNode.sid === null}
                            showDeleteConfirm={showDeleteConfirm}
                        />
                    )}
                </div>
            )}
            disabled={node.disabled}
        >
            {node.children && renderTreeNodes(node.children.slice().sort(stringSort("creation_date")))}

        </TreeNode>
    ));

    const [treeWidth, setTreeWidth] = useState(400);

    useImperativeHandle(ref, () => ({
        resizeTree(width) {
            setTreeWidth(width);
        },
    }));

    const resizeTree = (event, { element, size, handle }) => {
        setTreeWidth(size.width);
    };

    return (
        <ResizableBox className="tree" width={treeWidth} height={100} axis="x" minConstraints={[100]} maxConstraints={[600]} onResize={resizeTree}>
            <div className="tree-container" onClick={() => closeContextMenu(treeName)}>
                <div className="tree-header">
                    {/* <div className="title">{section && section.name}</div> */}
                    <Search className="search-bar" value={searchQuery} allowClear onChange={handleSearch} />

                </div>
                <Tree
                    className="tree-structure"
                    switcherIcon={<span className="treeNode-icon bg-img" />}
                    expandedKeys={expandedKeys}
                    onExpand={handleExpandNode}
                    autoExpandParent={Boolean(searchQuery)}
                    onSelect={handleSelectNode}
                    onRightClick={handleRightClick}
                    selectedKeys={[group]}
                >
                    {tree && renderTreeNodes(tree)}
                </Tree>
            </div>
        </ResizableBox>
    );
});

const mapStateToProps = (state, ownProps) => {
    const {
        treeName,
        sectionOverride,
        disableContext,
        rememberGroupInStorage,
        deleteMiddleware,
        showDeleteConfirm,
        createMiddleware,
        customSelectNodeAction,
    } = ownProps;

    const { treeStructure } = state.categories;

    const {
        nested_tree,
    } = treeStructure;

    const {
        searchQuery,
        expandedKeys,
        contextMenuNode,
        selectedNode,
    } = treeStructure[treeName];

    let { section } = treeStructure[treeName];

    if (sectionOverride && nested_tree) {
        // TODO: all of this should be replaced with the proper category mapping, when categories have aliases on BE
        // OR the geodata category should have the proper separate root in seeds
        section = categoryByName(nested_tree, sectionOverride).sid;
    }

    const tree = nested_tree ? nested_tree[section].children : [];

    const selectedPath = getPath(state, treeName);

    const routerPathParams = state.core.router;

    const selectedCategory = categoryByName(nested_tree, routerPathParams.section);
    const currentSelectedCategory = currentCategory(state);

    const autoSelectedCategory = selectedCategory ? selectedCategory.children[0].sid : "";
    const findNodeFromRouterParams = selectedCategory ? findNodeById(routerPathParams.group)(selectedCategory) : { sid: routerPathParams.group };
    const routerPathGroup = findNodeFromRouterParams ? findNodeFromRouterParams.sid : autoSelectedCategory;
    const group = treeName === "documents-list" ? routerPathGroup : selectedNode;

    return {
        attachmentForm: treeName === "file-attachment",
        treeName,
        tree,
        expandedKeys: searchQuery ? searchTreeNodes(state, treeName) : expandedKeys,
        searchQuery,
        selectedPath,
        contextMenuNode,
        section,
        project: selectActiveProject(state),
        routerPathParams,
        // group: routerPathParams.group ? routerPathParams.group : categoryByName(tree, routerPathParams.section),
        // selectGroup(),
        group,
        disableContext,
        rememberGroupInStorage,
        deleteMiddleware,
        createMiddleware,
        showDeleteConfirm,
        currentSelectedCategory,
        selectedCategory,
    };
};

export const TreeStructureContainer = connect(mapStateToProps, {
    expandNodes: expandNodesAction,
    openContextMenu: openContextMenuAction,
    closeContextMenu: closeContextMenuAction,
    searchNodes: searchNodesAction,
    createNode: categoriesCRUDActions.use.CREATE_ENTITY,
    updateNode: categoriesCRUDActions.use.UPDATE_ENTITY,
    deleteNode: categoriesCRUDActions.use.DELETE_ENTITY,
}, null, { forwardRef: true })(TreeStructure);
