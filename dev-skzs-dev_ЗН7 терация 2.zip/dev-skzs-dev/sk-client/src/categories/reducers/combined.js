import { combineReducers } from "redux";
import { crudReducerFactory } from "../../shared/reducers/crudFactory";
import { ENTITY_NAME, MODULE_NAME } from "../constants/categories";
import { treeStructureReducer } from "./treeStructure";

export const categoriesReducers = combineReducers({
    crud: crudReducerFactory(MODULE_NAME, ENTITY_NAME, "sid"),
    treeStructure: treeStructureReducer,
});
