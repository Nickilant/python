import {
    CATEGORIES_CREATE_TREE,
    CATEGORIES_UPDATE_TREE,
    TREE_STRUCTURE_CONTEXT_MENU_CLOSE,
    TREE_STRUCTURE_CONTEXT_MENU_OPEN,
    TREE_STRUCTURE_EXPANDING_NODES,
    TREE_STRUCTURE_SEARCH_NODES,
    TREE_STRUCTURE_SELECT_NODE, TREE_STRUCTURE_SELECT_NODE_MSG,
} from "../actions/actionTypes";
import { ROUTER_SECTION_CHANGED } from "../../projects/actions/actionTypes";

import {
    FILE_ATTACHMENT_FORM_OPEN,
    FILE_ATTACHMENT_FORM_SELECT_SECTION,
} from "../../documents/actions/FileAttachment/actionTypes";

const initialState = {
    nested_tree: null,
    categories_tree: null,
    categories_map: null,

    "documents-list": {
        searchQuery: "",
        selectedNode: null,
        expandedKeys: [],
        contextMenuNode: null,
        section: "",
    },
    "file-attachment": {
        searchQuery: "",
        selectedNode: null,
        expandedKeys: [],
        contextMenuNode: null,
        section: "",
    },
    "document-attachment": {
        searchQuery: "",
        selectedNode: null,
        expandedKeys: [],
        contextMenuNode: null,
        section: "construction-control",
    },
};

export const treeStructureReducer = (state = initialState, action) => {
    switch (action.type) {
        case CATEGORIES_CREATE_TREE: {
            const {
                tree, section, nested_tree, categories_map,
            } = action.payload;
            return {
                ...state,
                nested_tree,
                categories_map,
                categories_tree: tree,
                "file-attachment": {
                    ...state["file-attachment"],
                    section: section.sid,
                },
                "document-attachment": {
                    ...state["document-attachment"],
                    section: section.sid,
                },
            };
        }
        case CATEGORIES_UPDATE_TREE: {
            const {
                tree, nested_tree, categories_map,
            } = action.payload;
            return {
                ...state,
                nested_tree,
                categories_map,
                categories_tree: tree,
            };
        }
        case FILE_ATTACHMENT_FORM_OPEN: {
            const treeName = "file-attachment";

            const { entity } = action.payload;

            let firstNode;
            let section;

            if (entity) {
                firstNode = entity.group;
                section = state["documents-list"].section;
            } else {
                firstNode = Object.values(state.nested_tree)[0].children[0].sid;
            }

            return {
                ...state,
                [treeName]: {
                    ...state[treeName],
                    section: section || state[treeName].section,
                    selectedNode: firstNode,
                    expandedKeys: [firstNode],
                },
            };
        }
        case FILE_ATTACHMENT_FORM_SELECT_SECTION: {
            const { sid } = action.payload;

            const treeName = "file-attachment";

            const firstNode = state.nested_tree[sid].children[0].sid;

            return {
                ...state,
                [treeName]: {
                    ...state[treeName],
                    section: sid,
                    selectedNode: firstNode,
                    expandedKeys: [firstNode],
                },
            };
        }
        case ROUTER_SECTION_CHANGED: {
            const { section } = action.payload;

            if (!state.nested_tree || !section) return state;

            const treeName = "documents-list";
            const firstNode = state.nested_tree[section.sid].children[0].sid;
            return {
                ...state,
                [treeName]: {
                    ...state[treeName],
                    section: section.sid,
                    selectedNode: firstNode,
                    expandedKeys: [firstNode],

                },
            };
        }
        case TREE_STRUCTURE_SELECT_NODE_MSG:
        case TREE_STRUCTURE_SELECT_NODE: {
            const selectedNode = action.payload.id;
            const { treeName } = action.payload;
            return {
                ...state,
                [treeName]: {
                    ...state[treeName],
                    selectedNode,
                },
            };
        }
        case TREE_STRUCTURE_EXPANDING_NODES: {
            const { treeName } = action.payload;

            return {
                ...state,
                [treeName]: {
                    ...state[treeName],
                    searchQuery: "",
                    expandedKeys: action.payload.ids,
                    autoExpandParent: false,
                },

            };
        }
        case TREE_STRUCTURE_SEARCH_NODES: {
            const { treeName } = action.payload;

            return {
                ...state,
                [treeName]: {
                    ...state[treeName],
                    searchQuery: action.payload.query,
                },
            };
        }
        case TREE_STRUCTURE_CONTEXT_MENU_OPEN: {
            const contextMenuNode = action.payload.sid;
            const { treeName } = action.payload;

            return {
                ...state,
                [treeName]: {
                    ...state[treeName],
                    contextMenuNode,
                },
            };
        }

        case TREE_STRUCTURE_CONTEXT_MENU_CLOSE: {
            const { treeName } = action.payload;

            return {
                ...state,
                [treeName]: {
                    ...state[treeName],
                    contextMenuNode: undefined,
                },
            };
        }
        default: {
            return state;
        }
    }
};
