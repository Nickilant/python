export const MODULE_NAME = "categories";
export const ENTITY_NAME = "category";

export const INPUT_NAME_MODE_CREATE = "create";
export const INPUT_NAME_MODE_UPDATE = "update";
export const INPUT_NAME_MODE_COPYPASTE = "copyPaste";
