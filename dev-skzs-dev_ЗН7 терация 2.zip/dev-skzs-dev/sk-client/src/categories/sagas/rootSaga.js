import {
    all, put, select, takeEvery,
} from "@redux-saga/core/effects";
import { delay } from "redux-saga/effects";
import { omit } from "lodash";
import { createCRUDSaga } from "../../shared/sagas/entityCrudFactory";
import { ENTITY_NAME, MODULE_NAME } from "../constants/categories";
import {
    categoriesCRUDActions, createTreeAction, expandNodesAction, updateTreeAction,
} from "../actions/actions";
import { getPath } from "../selectors/treeStructure";

const categoriesCrudSaga = createCRUDSaga({
    moduleName: MODULE_NAME,
    entityName: ENTITY_NAME,
    idField: "sid",

    getPrefixPath: ({ payload }) => `/projects/${payload.source.project.key}/categories`,
    entityPath: ({ payload }) => `/projects/${payload.source.project.key}/categories/${payload.source.sid}/`,
    postPath: ({ payload }) => `/projects/${payload.source.project.key}/categories/`,
});

function* createTree({ payload }) {
    yield put(createTreeAction(payload.list));
}

const getItems = (state) => state.categories.crud.items;

function* updateTree({ payload }) {
    const newCategories = (categories = []) => categories.reduce((acc, category) => {
        if (category.categories.length) {
            return [...acc, omit(category, ["categories"]), ...newCategories(category.categories)];
        }
        return [...acc, category];
    }, []);

    if (payload.item && payload.item.categories && payload.item.categories.length) {
        yield put(categoriesCRUDActions.use.CREATE_ENTITIES_COMPLETE({
            items: newCategories([payload.item]),
        }));
    }

    const items = yield select(getItems);

    yield put(updateTreeAction(items));
}

function* watchFetchCategories() {
    yield takeEvery(categoriesCRUDActions.LIST_ENTITIES_COMPLETE, createTree);
}

function* expandNodesToSelected() {
    yield delay(500);
    const path = yield select(getPath);
    yield put(expandNodesAction(path, "documents-list"));
}

function* watchUpdateCategories() {
    yield takeEvery(categoriesCRUDActions.CREATE_ENTITY_COMPLETE, updateTree);
    yield takeEvery(categoriesCRUDActions.DELETE_ENTITY_COMPLETE, updateTree);
    yield takeEvery(categoriesCRUDActions.UPDATE_ENTITY_COMPLETE, updateTree);
    yield takeEvery(categoriesCRUDActions.CREATE_ENTITIES_COMPLETE, updateTree);
    yield takeEvery(categoriesCRUDActions.LIST_ENTITIES_COMPLETE, expandNodesToSelected);
}

export function* categoriesRootSaga() {
    yield all([
        categoriesCrudSaga(),
        watchFetchCategories(),
        watchUpdateCategories(),
    ]);
}
