import { getCRUDEntityActions } from "../../shared/actions/entityCrudActions";
import { ENTITY_NAME, MODULE_NAME } from "../constants/categories";
import {
    CATEGORIES_CREATE_TREE,
    CATEGORIES_UPDATE_TREE,
    TREE_STRUCTURE_CONTEXT_MENU_CLOSE,
    TREE_STRUCTURE_CONTEXT_MENU_OPEN,
    TREE_STRUCTURE_EXPANDING_NODES,
    TREE_STRUCTURE_SEARCH_NODES,
    TREE_STRUCTURE_SELECT_NODE, TREE_STRUCTURE_SELECT_NODE_MSG,
} from "./actionTypes";

export const categoriesCRUDActions = getCRUDEntityActions(MODULE_NAME, ENTITY_NAME);

export const expandNodesAction = (ids, treeName) => ({
    type: TREE_STRUCTURE_EXPANDING_NODES,
    payload: { ids, treeName },
});

export const selectNodeAction = (id, treeName) => ({
    type: TREE_STRUCTURE_SELECT_NODE,
    payload: { id, treeName },
});

export const selectNodeMSGAction = (id, treeName) => ({
    type: TREE_STRUCTURE_SELECT_NODE_MSG,
    payload: { id, treeName },
});

export const openContextMenuAction = (sid, treeName) => ({
    type: TREE_STRUCTURE_CONTEXT_MENU_OPEN,
    payload: { sid, treeName },
});

export const closeContextMenuAction = (treeName) => ({
    type: TREE_STRUCTURE_CONTEXT_MENU_CLOSE,
    payload: {
        treeName,
    },
});

export const searchNodesAction = (query, treeName) => ({
    type: TREE_STRUCTURE_SEARCH_NODES,
    payload: {
        query,
        treeName,
    },
});

export const convertTree = (categoriesMap, mode) => {
    const categories = Object.values(categoriesMap);
    const tree = {};
    const nested_tree = {};
    const categories_map = {};
    const unsolved_children_map = {};

    categories.forEach((category) => {
        const tree_node = {
            ...category,
            children: [],
        };

        const nested_tree_node = {
            ...category,
            children: [],
        };

        categories_map[category.sid] = nested_tree_node;
        tree[category.sid] = tree_node;

        if (unsolved_children_map[category.sid]) {
            nested_tree_node.children = unsolved_children_map[category.sid];
            tree_node.children = nested_tree_node.children.map((it) => it.sid);
            delete unsolved_children_map[category.sid];
        }

        if (category.parent_category) {
            if (categories_map[category.parent_category]) {
                categories_map[category.parent_category].children.push(nested_tree_node);
                tree[category.parent_category].children.push(category.sid);
            } else {
                if (!unsolved_children_map[category.parent_category]) {
                    unsolved_children_map[category.parent_category] = [];
                }
                unsolved_children_map[category.parent_category].push(nested_tree_node);
            }
        } else {
            nested_tree[category.sid] = nested_tree_node;
        }
    });

    return {
        type: mode,
        payload: {
            categories, tree, nested_tree, categories_map, section: Object.values(nested_tree)[0],
        },
    };
};

export const createTreeAction = (categories) => convertTree(categories, CATEGORIES_CREATE_TREE);

export const updateTreeAction = (categories) => convertTree(categories, CATEGORIES_UPDATE_TREE);
