import { loggedInUser } from "../../users/selectors/permissions";
import { USER_ROLES } from "../../users/constants/roles";

export const canManageCategories = (state) => {
    const { role } = loggedInUser(state);
    return [USER_ROLES.ADMIN, USER_ROLES.MODERATOR, USER_ROLES.DEMO].includes(role);
};
