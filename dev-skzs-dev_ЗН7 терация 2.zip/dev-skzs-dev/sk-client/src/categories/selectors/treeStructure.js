import { mappingCharsRuToEng } from "../../construction_control/base/selectors/documents";

export const currentCategory = (state, treeName = "documents-list") => state.categories.crud.items[selectedCategory(state, treeName)];

export const selectedCategory = (state, treeName = "documents-list") => state.categories.treeStructure[treeName].selectedNode;

export const getAllChildren = (state, treeName = "documents-list") => {
    const { categories_map } = state.categories.treeStructure;
    const { selectedNode } = state.categories.treeStructure[treeName];

    if (!selectedNode) return [];

    function collapse(items) {
        return items.reduce((acc, it) => {
            if (!it) {
                return acc;
            }
            return [...acc, it.sid, ...collapse(it.children)];
        }, []);
    }
    const result = collapse([categories_map[selectedNode]]);
    return result;
};

export const searchTreeNodes = (state, treeName) => {
    const categories_map = state.categories.crud.items;
    const { searchQuery } = state.categories.treeStructure[treeName];
    if (categories_map === null) {
        return [];
    }
    const array = Object.values(categories_map);
    return array.filter((item) => {
        const name = mappingCharsRuToEng(item.name);
        const cipher = mappingCharsRuToEng(item.cipher || "");
        const query = mappingCharsRuToEng(searchQuery.toUpperCase());

        return Boolean(name.indexOf(query) + 1) || Boolean(cipher.indexOf(query) + 1);
    }).map((item) => item.sid);
};

export const getPath = (state, treeName = "documents-list") => {
    const categories_map = state.categories.crud.items;
    const { selectedNode } = state.categories.treeStructure[treeName];
    const result = [];

    if (!selectedNode) return result;

    const iter = (sid) => {
        result.push(sid);
        const parentKey = categories_map[sid] && categories_map[sid].parent_category;
        if (parentKey) {
            iter(parentKey);
        }
    };
    iter(selectedNode);
    return result;
};

export const findNodeById = (sid) => (tree) => {
    const iter = (item) => {
        if (item.sid === sid) return item;
        if (item.children) { // eslint-disable-next-line
            for (const child of item.children) {
                const result = iter(child);
                if (result !== null) {
                    return result;
                }
            }
        }

        return null;
    };

    return tree ? iter(tree) : null;
};
