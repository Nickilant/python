import React from "react";

import { ChooseParams } from "../../components/ChooseParams/component";

import "./styles.scss";

export const AirMonitoringPage = () => (
    <div className="air-monitoring-module main-page">
        <ChooseParams />
    </div>
);
