import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { Select } from "antd";

import { selectActiveProject } from "../../../projects/selectors/projects";

import "./styles.scss";

const { Option } = Select;

const options = [
    {
        value: 1,
        label: "Мессояха",
    },
    {
        value: 2,
        label: "Тазовский",
    },
];

const takeValue = (project) => {
    const opt = options.find((it) => new RegExp(it.label, "i").test(project.name));
    return opt ? opt.value : null;
};

export const ChooseParams = () => {
    const project = useSelector(selectActiveProject);
    const [selector, setSelector] = useState(project && takeValue(project));

    useEffect(() => {
        setSelector(project && takeValue(project));
    }, [project]);

    return (
        <div className="sarex-frame-block">
            <div className="selector-block">
                <div className="label">
                    Выбор проекта:
                </div>
                <Select
                    className="selector"
                    value={selector}
                    onChange={setSelector}
                >
                    {
                        options.map((opt) => (
                            <Option
                                key={opt.value}
                                value={opt.value}
                            >
                                { opt.label }
                            </Option>
                        ))
                    }
                </Select>
            </div>
            {
                selector && (
                    <iframe
                        className="sarex-frame"
                        title="sarex"
                        align="center"
                        src={`https://gpnr.sarex.io/iframe/?auth_key=7C147B21344EC53427B5BF63F9BCC&oid=${selector}`}
                        frameBorder="0"
                    />
                )
            }
        </div>
    );
};
