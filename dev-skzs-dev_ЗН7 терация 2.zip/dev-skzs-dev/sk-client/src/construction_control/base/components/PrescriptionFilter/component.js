import React from "react";
import cx from "classnames";

import "./styles.scss";

export const PrescriptionFilter = (props) => {
    const { triggerFilter, divider, filter } = props;

    const handleClick = () => () => {
        triggerFilter(filter);
    };

    return (
        <div className="filter-block">
            <div
                className={cx(
                    "filter",
                    `filter-${filter.name}`,
                    filter.active && "filter-active",
                )}
                onClick={handleClick()}
            >
                {filter.count}
            </div>
            {divider && <div className="vertical-divider" />}
        </div>
    );
};
