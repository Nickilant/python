import React from "react";
import { useSelector } from "react-redux";

import { Switcher } from "../../../../shared/components/Switcher/component";
import { SWITCHER_TYPES } from "../../../../shared/constants/switcherTypes";
import { UniversalHistory } from "../../../../executive_documentation/widgets/UniversalHistory/component";
import { Geotags } from "../../../../executive_documentation/widgets/UniversalGeotags/component";
import { UniversalComments } from "../../../../executive_documentation/widgets/UniversalComments/component";
import { UniversalFiles } from "../../../../executive_documentation/widgets/UniversalFiles/component";
import { PREVIEW_MODULES } from "../../widgets/DocumentPreviewColumn/previewModules";
import { PrescriptionDetailsView } from "../../containers/PrescriptionDetailsView/container";
import { getCurrentDocument } from "../../../../executive_documentation/selectors/documents";

import "./styles.scss";

export const PrescriptionDetailsSwitcherComponent = () => {
    const document = useSelector(getCurrentDocument);

    const {
        commentsCount,
        filesCount,
        geotagsCount,
        type,
    } = document;

    const title = {
        prescription: "предписания",
        remark: "замечания",
        act: "акта-уведомления",
    }[type];

    const config = [
        {
            type: SWITCHER_TYPES.VIEW,
            title: `Полный вид ${title}`,
            component: () => (
                <PrescriptionDetailsView />
            ),
        },
        {
            type: SWITCHER_TYPES.HISTORY,
            title: "История изменений",
            component: () => (
                <UniversalHistory />
            ),
        },
        {
            type: SWITCHER_TYPES.VERTICAL_DIVIDER,
        },
        {
            type: SWITCHER_TYPES.GEOTAGS,
            title: "Список геометок",
            count: geotagsCount,
            component: () => (
                <Geotags />
            ),
        },
        {
            type: SWITCHER_TYPES.COMMENTS,
            title: "Список комментариев",
            count: commentsCount,
            component: () => (
                <UniversalComments document={document} />
            ),
        },
        {
            type: SWITCHER_TYPES.FILES,
            title: "Всего файлов",
            count: filesCount,
            component: () => (
                <UniversalFiles
                    module={PREVIEW_MODULES.CONSTRUCTION_CONTROL}
                />
            ),
        },
    ];

    return (
        <Switcher
            config={config}
        />
    );
};
