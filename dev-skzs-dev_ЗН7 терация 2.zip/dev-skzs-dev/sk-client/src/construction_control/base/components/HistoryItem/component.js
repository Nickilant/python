import React from "react";

import "./styles.scss";
import moment from "moment";
import { UserInfo } from "../UserInfo/component";

export const HistoryItem = (props) => {
    const {
        user,
        date,
        title,
    } = props;

    return (
        <div className="history-item">
            <div className="info">
                <div className="title">{title}</div>
                <div className="date">{moment(date).format("DD.MM.YY HH:mm")}</div>
            </div>
            <div className="user">
                <div className="user-avatar">
                    <img src={user.avatar} alt="аватар" />
                </div>
                <UserInfo
                    user={user}
                />
            </div>
        </div>
    );
};
