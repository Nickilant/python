import React from "react";
import { useDispatch } from "react-redux";
import { WIDGET_TYPES } from "../../../../shared/constants/widgetTypes";
import { openRightColumnContainerAction } from "../../../../shared/actions/RightColumnContainer/actions";
import { usersCRUDActions } from "../../../../users/actions/actions";
import { organizationsCRUDActions } from "../../../../organizations/actions/actions";

export const UserInfo = ({ user }) => {
    const { company } = user;

    const dispatch = useDispatch();

    const openRightColumn = (...payload) => {
        dispatch(openRightColumnContainerAction(...payload));
    };

    const getUserDetails = (...payload) => {
        dispatch(usersCRUDActions.use.GET_ENTITY_DETAILS(...payload));
    };

    const selectUser = (...payload) => {
        dispatch(usersCRUDActions.use.SELECT_SINGLE_ENTITY(...payload));
    };

    const showUser = () => {
        getUserDetails({ source: { key: user.sid } });
        selectUser({ key: user.sid });
        openRightColumn(WIDGET_TYPES.USER_PROFILE, { key: user.sid, ...user, styles: { width: "644px" } }, true);
    };

    const getCompanyDetails = (...payload) => {
        dispatch(organizationsCRUDActions.use.GET_ENTITY_DETAILS(...payload));
    };

    const selectCompany = (...payload) => {
        dispatch(organizationsCRUDActions.use.SELECT_SINGLE_ENTITY(...payload));
    };

    const showCompany = () => {
        getCompanyDetails({ source: { key: company.sid } });
        selectCompany({ key: company.sid });
        openRightColumn(WIDGET_TYPES.COMPANY_PROFILE, { key: company.sid, ...company, styles: { width: "644px" } }, true);
    };

    return (
        <div>
            <span>
                {`${user.position} `}
            </span>
            <span>
                <span
                    className="link"
                    onClick={showCompany}
                >
                    {`${user.company.name} `}
                </span>
            </span>
            <span>
                <span
                    className="link"
                    onClick={showUser}
                >
                    {user.full_name}
                </span>
            </span>
        </div>
    );
};
