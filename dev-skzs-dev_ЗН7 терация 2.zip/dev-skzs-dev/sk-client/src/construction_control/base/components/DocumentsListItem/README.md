# Элемент списка

## Props

Заголовок `title` *string*  
Адрес иконки `icon` *string*  
Описание `description` *string*  
Статус `status` *string*  
Возможные статусы:
- default
- notChecked
- checked
- delayed

**Все даты задаются в UNIX формате**

Дата документа `date` *number*  
Дата дедлайна `deadline`  *number*  
Дата выполнения `dateOfCompletion`  *number*  
Количество комментариев `commentsCount`  *number*  
Количество геотегов`geotagsCount`  *number*  
Количество файлов `filesCount`  *number*  
Является ли избранным `isFavorite` *boolean*  
Является ли скачанным `isDownloaded` *boolean*
Является ли выбранным `selected` *boolean*

## Example
```
<DocumentListItem
    title='Предписание 53/122/У от 11.07.2019'
    icon=''
    description={`1. Электроинструмент (УШМ) не отключается от сети при переходе рабочего на другой вид работ.\n2. Эксплуатация удлинителей без бирок с инвентарными номерами и  датой испытаний.`}
    status='default'
    date={1562792400000}
    deadline={1563138000000}
    dateOfCompletion={1562892400000}
    commentsCount={2}
    geotagsCount={3}
    filesCount={3}
    isFavorite={true}
    isDownloaded={false}
    selected={true}
    >
</DocumentListItem>
```

## TODO
- [ ] Иконки
- [ ] Доработка отображения дедлайна
- [ ] Красный бейдж в отображении количества комментариев
- [ ] События
