import React from "react";
import cx from "classnames";
import moment from "moment";

import { DOCUMENT_TYPES } from "../../../../documents/constants/types";

import "./styles.scss";

export default (props) => {
    const countDeadline = () => {
        const ONE_DAY = (24 * 60 * 60 * 1000);
        const to = document.deadline;
        const from = props.document.dateOfCompletion ? moment(props.document.dateOfCompletion).toDate() : new Date();
        const diff = from - to - ONE_DAY;
        const countOfDays = Math.ceil(diff / ONE_DAY);

        let str = "просрочено на";
        if (countOfDays < 0) str = "осталось";
        else if (countOfDays === 0) str = "срок истекает сегодня";

        return (
            <div className={countOfDays > 0 ? "warning" : ""}>
                { countOfDays
                    ? `${str} ${Math.abs(countOfDays)} дн.`
                    : `${str}`}
            </div>
        );
    };

    const {
        selected = false,
        selectItem,
        document,
    } = props;

    const {
        title = "",
        description = "",
        status = "",
        deadline = null,
        dateOfCompletion = null,
        commentsCount = null,
        geotagsCount = null,
        filesCount = null,
        // isFavorite = false,
        // isDownloaded = false,
        criticality = null,
        issued_to_full = "",
        type,
    } = document;

    return (
        <div className={cx("document-list-item", status, { selected }, { critical: criticality === "CRITICAL" })} onClick={() => selectItem(props.document.id)}>
            <div className="bg-img icon-prediction">
                <span className={cx(["badge", criticality])}>
                    {
                        {
                            CRITICAL: "О",
                            MAJOR: "У",
                        }[criticality]
                    }
                </span>
            </div>
            <div className="info">
                <div className="title">
                    {title}
                    {/* <div className="icons"> */}
                    {/*    <span className={cx("icon", "bg-img", isDownloaded ? "download" : "notDownloaded")} /> */}
                    {/*    <span className={cx("icon", "bg-img", isFavorite ? "favorite" : "notFavorite")} /> */}
                    {/* </div> */}
                </div>
                <div className="contractor">{issued_to_full && issued_to_full.name}</div>
                <div className="description">{description.slice(0, 120)}</div>
            </div>

            {
                !!(dateOfCompletion || deadline)
                && (
                    <div className="deadline">
                        <div className="date">
                            {
                                status === "checked"
                                    ? (
                                        <div>
                                            Устранено
                                            {" "}
                                            {new Date(dateOfCompletion).toLocaleDateString("ru-ru")}
                                        </div>
                                    )
                                    : new Date(deadline).toLocaleDateString("ru-ru")
                            }
                        </div>
                        <div className="expired">
                            {
                                (type === DOCUMENT_TYPES.ACT || (type === DOCUMENT_TYPES.PRESCRIPTION && status === "checked"))
                                    ? null : countDeadline(deadline)
                            }
                        </div>
                    </div>
                )

            }
            <div className="counter-icons">
                {geotagsCount !== null
                && <div className="icon bg-img geotag"><span className={`counter ${!geotagsCount ? "zero" : ""}`}>{geotagsCount}</span></div>}
                {commentsCount !== null
                && <div className="icon bg-img comments"><span className={`counter ${!commentsCount ? "zero" : ""}`}>{commentsCount}</span></div>}
                {filesCount !== null
                && <div className="icon bg-img files"><span className={`counter ${!filesCount ? "zero" : ""}`}>{filesCount}</span></div>}
            </div>

        </div>
    );
};
