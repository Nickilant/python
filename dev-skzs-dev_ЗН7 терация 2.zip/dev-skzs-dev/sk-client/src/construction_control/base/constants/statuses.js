import { DOCUMENT_TYPES } from "../../../documents/constants/types";

export const DOCUMENT_STATUS = {
    NEW: "new",
    EXPIRED: "expired",
    RESOLVED: "resolved",
    CHECKED: "checked",
    RESCHEDULED: "rescheduled",
};

const MAX_RESCHEDULE_TIMES = 1;

const canBeRescheduled = (document, statuses) => (document.rescheduled_times < MAX_RESCHEDULE_TIMES ? statuses : statuses.filter((it) => it !== DOCUMENT_STATUS.RESCHEDULED));

export const DOCUMENT_STATUS_TRANSITIONS = {
    [DOCUMENT_TYPES.PRESCRIPTION]: {
        [DOCUMENT_STATUS.NEW]: {
            canCreateAct: true,
            transitions: (document) => canBeRescheduled(document, [DOCUMENT_STATUS.RESCHEDULED]),
        },
        [DOCUMENT_STATUS.EXPIRED]: {
            canCreateAct: true,
            transitions: (document) => canBeRescheduled(document, [DOCUMENT_STATUS.RESCHEDULED]),
        },
        [DOCUMENT_STATUS.RESOLVED]: {
            canCreateAct: false,
            transitions: (document) => canBeRescheduled(document, [
                DOCUMENT_STATUS.CHECKED,
                DOCUMENT_STATUS.RESCHEDULED,
                DOCUMENT_STATUS.NEW,
            ]),
        },
        [DOCUMENT_STATUS.RESCHEDULED]: {
            canCreateAct: true,
            transitions: () => [],
        },
        [DOCUMENT_STATUS.CHECKED]: {
            canCreateAct: false,
            transitions: [],
        },
    },
    [DOCUMENT_TYPES.REMARK]: {
        [DOCUMENT_STATUS.NEW]: {
            canCreateAct: false,
            transitions: [DOCUMENT_STATUS.RESOLVED],
        },
        [DOCUMENT_STATUS.EXPIRED]: {
            canCreateAct: false,
            transitions: [DOCUMENT_STATUS.RESOLVED],
        },
        [DOCUMENT_STATUS.RESOLVED]: {
            canCreateAct: false,
            transitions: [DOCUMENT_STATUS.CHECKED, DOCUMENT_STATUS.NEW],
        },
        [DOCUMENT_STATUS.CHECKED]: {
            canCreateAct: false,
            transitions: [],
        },
    },
    [DOCUMENT_TYPES.ACT]: {},
    [DOCUMENT_TYPES.AOSR]: {},
};
