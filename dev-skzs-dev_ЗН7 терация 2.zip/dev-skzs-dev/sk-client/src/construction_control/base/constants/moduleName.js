export const moduleNameAction = "CONSTRUCTION_CONTROL";
export const moduleName = "constructionControl";
