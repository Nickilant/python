export const typeLabel = {
    prescription: "предписание",
    remark: "замечаниe",
    act: "акт",
    daily_report: "ежедневный отчет",
    consolidated_report: "сводный отчет",
    photo_report: "фотоотчет",
    other: "документ",
};
