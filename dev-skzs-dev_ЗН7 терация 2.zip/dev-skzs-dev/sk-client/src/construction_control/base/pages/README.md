
## Pages package

Pages contain full page components for the module 