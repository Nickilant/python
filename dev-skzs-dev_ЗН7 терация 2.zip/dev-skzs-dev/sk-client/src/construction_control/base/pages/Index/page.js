import React, { useState } from "react";
import { connect } from "react-redux";

import "./styles.scss";
import { Button, Modal } from "antd";
import { TreeStructureContainer } from "../../../../categories/containers/TreeStructure/container";
import { PrescriptionFilters } from "../../containers/PrescriptionFilters/container";
import DocumentSearchContainer from "../../containers/DocumentSearch/container";
import EntityListContainer from "../../containers/EntityList/container";
import { closeSidebarAction, openSidebarAction } from "../../../../core/actions/actions";
import {
    universalClearFormAction,
    universalValidateChangeFormAction,
} from "../../../../shared/actions/managementForm/actions";
import { FileAttachment } from "../../../../documents/containers/FileAttachment/container";
import { WIDGET_TYPES } from "../../../../shared/constants/widgetTypes";
import { openRightColumnContainerAction } from "../../../../shared/actions/RightColumnContainer/actions";
import { selectedDocumentView } from "../../../../documents/selectors/documents";
import { canCreateDocument } from "../../selectors/permissions";
import { DOCUMENT_TYPES } from "../../../../documents/constants/types";
import { ExportForm } from "../../widgets/ExportForm/ExportForm";

export const ConstructionControlPageContainer = (props) => {
    const {
        canCreatePrescription,
        attachmentFormOpened,
        openRightColumn,
        clearForm,
        match,
    } = props;
    const { document_id } = match.params;

    const [modalVisible, setModalVisible] = useState(false);

    const handleOpenForm = () => {
        openRightColumn(WIDGET_TYPES.DOCUMENT_MANAGEMENT_FORM);
        clearForm("documents", "document", { type: "prescription" });
    };

    const handleOpenModal = () => {
        setModalVisible(true);
    };

    return (
        <div className="construction-control-module construction-control-page columns">
            <Modal
                className="export-modal"
                width="679px"
                title="Выгрузить реестр предписаний"
                visible={modalVisible}
                onCancel={() => setModalVisible(false)}
                footer={[]}
                destroyOnClose
            >
                <div>
                    <ExportForm />
                </div>
            </Modal>
            { attachmentFormOpened && <FileAttachment /> }
            <TreeStructureContainer treeName="documents-list" />

            <div className="content">
                <div className="document-filter">
                    {
                        canCreatePrescription
                        && (
                            <Button className="create-document" onClick={handleOpenForm}>
                                Создать документ
                            </Button>
                        )
                    }
                    <Button className="export" onClick={handleOpenModal}>
                        <svg width="28" height="28" viewBox="0 0 28 28" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M15.0749 4.81687C14.9253 4.6935 14.7271 4.64231 14.5355 4.67775L4.0355 6.6465C3.72444 6.70425 3.5 6.97462 3.5 7.29094V21.7284C3.5 22.0434 3.72444 22.3151 4.0355 22.3729L14.5355 24.3416C14.5749 24.3495 14.6169 24.3534 14.6562 24.3534C14.8072 24.3534 14.9568 24.3009 15.0749 24.2025C15.2259 24.0778 15.3125 23.8914 15.3125 23.6972V5.32219C15.3125 5.12662 15.2259 4.94156 15.0749 4.81687ZM14 22.9057L4.8125 21.1837V7.83562L14 6.11362V22.9057Z" fill="white" />
                            <path d="M23.8438 7.29096H14.6562C14.294 7.29096 14 7.58496 14 7.94721C14 8.30946 14.294 8.60346 14.6562 8.60346H23.1875V20.416H14.6562C14.294 20.416 14 20.71 14 21.0722C14 21.4345 14.294 21.7285 14.6562 21.7285H23.8438C24.206 21.7285 24.5 21.4345 24.5 21.0722V7.94721C24.5 7.58496 24.206 7.29096 23.8438 7.29096Z" fill="white" />
                            <path d="M17.2812 9.91596H14.6562C14.294 9.91596 14 10.21 14 10.5722C14 10.9345 14.294 11.2285 14.6562 11.2285H17.2812C17.6435 11.2285 17.9375 10.9345 17.9375 10.5722C17.9375 10.21 17.6435 9.91596 17.2812 9.91596Z" fill="white" />
                            <path d="M17.2812 12.541H14.6562C14.294 12.541 14 12.835 14 13.1972C14 13.5595 14.294 13.8535 14.6562 13.8535H17.2812C17.6435 13.8535 17.9375 13.5595 17.9375 13.1972C17.9375 12.835 17.6435 12.541 17.2812 12.541Z" fill="white" />
                            <path d="M17.2812 15.166H14.6562C14.294 15.166 14 15.46 14 15.8222C14 16.1845 14.294 16.4785 14.6562 16.4785H17.2812C17.6435 16.4785 17.9375 16.1845 17.9375 15.8222C17.9375 15.46 17.6435 15.166 17.2812 15.166Z" fill="white" />
                            <path d="M17.2812 17.791H14.6562C14.294 17.791 14 18.085 14 18.4472C14 18.8095 14.294 19.1035 14.6562 19.1035H17.2812C17.6435 19.1035 17.9375 18.8095 17.9375 18.4472C17.9375 18.085 17.6435 17.791 17.2812 17.791Z" fill="white" />
                            <path d="M21.2188 9.91596H19.9062C19.544 9.91596 19.25 10.21 19.25 10.5722C19.25 10.9345 19.544 11.2285 19.9062 11.2285H21.2188C21.581 11.2285 21.875 10.9345 21.875 10.5722C21.875 10.21 21.581 9.91596 21.2188 9.91596Z" fill="white" />
                            <path d="M21.2188 12.541H19.9062C19.544 12.541 19.25 12.835 19.25 13.1972C19.25 13.5595 19.544 13.8535 19.9062 13.8535H21.2188C21.581 13.8535 21.875 13.5595 21.875 13.1972C21.875 12.835 21.581 12.541 21.2188 12.541Z" fill="white" />
                            <path d="M21.2188 15.166H19.9062C19.544 15.166 19.25 15.46 19.25 15.8222C19.25 16.1845 19.544 16.4785 19.9062 16.4785H21.2188C21.581 16.4785 21.875 16.1845 21.875 15.8222C21.875 15.46 21.581 15.166 21.2188 15.166Z" fill="white" />
                            <path d="M21.2188 17.791H19.9062C19.544 17.791 19.25 18.085 19.25 18.4472C19.25 18.8095 19.544 19.1035 19.9062 19.1035H21.2188C21.581 19.1035 21.875 18.8095 21.875 18.4472C21.875 18.085 21.581 17.791 21.2188 17.791Z" fill="white" />
                            <path d="M12.5263 16.7029L7.93256 11.4529C7.69106 11.1786 7.27762 11.1523 7.00593 11.3912C6.73293 11.6301 6.70537 12.0448 6.94424 12.3165L11.538 17.5665C11.6679 17.7148 11.8491 17.7909 12.0315 17.7909C12.1851 17.7909 12.3386 17.7371 12.4646 17.6282C12.7376 17.3893 12.7652 16.9759 12.5263 16.7029Z" fill="white" />
                            <path d="M12.4342 10.7113C12.1481 10.4869 11.736 10.5407 11.5128 10.8255L6.91908 16.7318C6.69727 17.0179 6.74846 17.4313 7.03458 17.6531C7.15533 17.7463 7.29708 17.791 7.43752 17.791C7.63177 17.791 7.82602 17.7043 7.95465 17.539L12.5484 11.6327C12.7715 11.3453 12.7203 10.9331 12.4342 10.7113Z" fill="white" />
                        </svg>
                    </Button>
                    <PrescriptionFilters />
                </div>
                <DocumentSearchContainer />
                <EntityListContainer activeDocument={document_id} />
            </div>

        </div>
    );
};

const mapStateToProps = (state) => ({
    sidebar: state.core.sidebar,
    details: state.core.details,
    selectedDocument: selectedDocumentView(state),
    canCreatePrescription: canCreateDocument(state, DOCUMENT_TYPES.PRESCRIPTION),
    attachmentFormOpened: state.documents.attachmentForm.attachmentFormOpened,
});

export const ConstructionControlPage = connect(mapStateToProps, {
    openSidebar: openSidebarAction,
    closeSidebar: closeSidebarAction,
    validateChangeForm: universalValidateChangeFormAction,
    openRightColumn: openRightColumnContainerAction,
    clearForm: universalClearFormAction,
})(ConstructionControlPageContainer);
