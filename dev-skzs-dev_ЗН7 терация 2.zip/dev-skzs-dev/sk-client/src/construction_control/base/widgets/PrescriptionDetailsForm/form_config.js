// TODO: this component can be made even more universal in future
import moment from "moment";

import { formTypes } from "../../../../shared/containers/ManagementForm/formTypes";
import { prescription_config } from "./prescription_config";
import { dateFormat } from "../../../../shared/constants/dateFormats";
import { remark_config } from "./remark_config";
import { act_config } from "./act_config";
import { DOCUMENT_TYPES } from "../../../../documents/constants/types";
import { loggedInUser } from "../../../../users/selectors/permissions";
import { documentCreationMap } from "../../../../users/constants/roles";
import { currentCategory } from "../../../../categories/selectors/treeStructure";

export const formConfig = [
    {
        name: "location",
        type: formTypes.INPUT,
        label: "Наименование объекта",
        is_required: true,
        default_value: ({ state }) => currentCategory(state).name,
    },
    {
        name: "code",
        type: formTypes.INPUT,
        label: "Шифр объекта",
        default_value: ({ state }) => currentCategory(state).cipher,
    },
    {
        name: "date",
        type: formTypes.TEXT,
        label: "Дата",
        value_source: () => moment().format(dateFormat),
    },
    {
        name: "type",
        type: formTypes.SELECTOR,
        source: ({ config, state }) => {
            const documentTypes = documentCreationMap[loggedInUser(state).role];
            return {
                ...config,
                options: [
                    { label: "ПРЕДПИСАНИЕ", value: DOCUMENT_TYPES.PRESCRIPTION },
                    // { label: "ЗАМЕЧАНИЕ", value: DOCUMENT_TYPES.REMARK },
                    { label: "АКТ-УВЕДОМЛЕНИЕ", value: DOCUMENT_TYPES.ACT },
                ].filter((it) => documentTypes.includes(it.value)),
            };
        },
        label: "Тип документа",
    },
    {
        name: "type_switch",
        type: formTypes.SWITCH,
        switchMap: (data) => (data.type ? ({
            prescription: {
                type: formTypes.FORM,
                reducer: "documentForm", // TODO: explain
                formConfig: prescription_config,
                module: "documents",
                moduleAction: "DOCUMENTS",
            },
            remark: {
                type: formTypes.FORM,
                reducer: "documentForm", // TODO: explain
                formConfig: remark_config,
                module: "documents",
                moduleAction: "DOCUMENTS",
            },
            act: {
                type: formTypes.FORM,
                reducer: "documentForm", // TODO: explain
                formConfig: act_config,
                module: "documents",
                moduleAction: "DOCUMENTS",
            },
        }[data.type]) : {
            name: "none",
            type: formTypes.DIVIDER,
        }),
    },
];
