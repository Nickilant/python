import moment from "moment";

import { formTypes } from "../../../../shared/containers/ManagementForm/formTypes";
import { universalSubmitValueAction } from "../../../../shared/actions/managementForm/actions";
import { selectActiveProject } from "../../../../projects/selectors/projects";
import { selectedCategory } from "../../../../categories/selectors/treeStructure";
import { companiesArray } from "../../../../organizations/selectors/companies";
import { usersArray, userWithId } from "../../../../users/selectors/users";
import { loggedInUser } from "../../../../users/selectors/permissions";

export const remark_config = [
    {
        name: "issued_to",
        type: formTypes.SELECTOR,
        label: "Выдано",
        source: ({ config, state }) => ({
            ...config,
            options: companiesArray(state),
        }),
        is_required: true,
    },
    {
        name: "issued_by",
        type: formTypes.TEXT,
        value_source: ({ state, data }) => {
            const current = loggedInUser(state).user;
            if (data.issued_by_full && data.issued_by_full.sid !== current.sid) {
                return data.issued_by_full.full_name;
            }
            return loggedInUser(state).user.full_name;
        },
        source: ({ config, state, data }) => {
            const current = loggedInUser(state).user;
            let label = "Мною, представителем СК";
            let help = current.position;

            if (data.issued_by_full && data.issued_by_full.sid !== current.sid) {
                label = "Представителем СК";
                help = data.issued_by_full.position;
            }

            return {
                ...config,
                label,
                help,
            };
        },
    },
    {
        name: "issued_with",
        type: formTypes.SELECTOR,
        label: "В присутствии, ФИО",
        is_required: false,
        source: ({ config, state, data }) => {
            const user = userWithId(state, data.issued_with);

            return {
                ...config,
                options: usersArray(state), // TODO: filter by company as well in selector?
                help: user ? user.position : config.help,
            };
        },
    },
    {
        name: "description",
        type: formTypes.TEXTAREA,
        label: "Описание замечания",
        is_required: true,
        placeholder: "Заполняется вручную",
    },
    {
        name: "suggested_solution",
        type: formTypes.TEXTAREA,
        label: "Предлагаемые меры",
        placeholder: "Заполняется вручную",
    },
    {
        name: "deadline",
        type: formTypes.DATE_INPUT,
        label: "Срок устранения (до)",
    },
    {
        name: "document_code",
        type: formTypes.SELECTOR,
        label: "Номер/шифр фото или иного документа",
        is_disabled: true,
        options: [
            { value: "", label: "Не выбран" },
        ],
    },
    {
        name: "person",
        type: formTypes.SELECTOR,
        label: "Ответственное лицо",
        is_required: true,
        source: ({ config, state, data }) => {
            const user = userWithId(state, data.person);
            return {
                ...config,
                options: usersArray(state, data.issued_to),
                help: user && user.position,
            };
        },
    },
    {
        name: "submit",
        type: formTypes.BUTTON,
        on_click: ({
            state, data, isEdited, isValidated, changedFields, dispatch,
        }) => {
            dispatch(universalSubmitValueAction("documents", "document", {
                isEdited,
                isValidated,
                changedFields,
                data: {
                    ...data,
                    project: selectActiveProject(state),
                    deadline: data.deadline ? data.deadline : moment().format("YYYY-MM-DD"),
                    related_category: !isEdited && selectedCategory(state),
                },
            }));
        },
        source: ({ config, isEdited, changedFields }) => ({
            ...config,
            is_disabled: Object.keys(changedFields).length === 0,
            btn_label: isEdited
                ? "Сохранить изменения"
                : "Создать замечание",
        }),
    },
];
