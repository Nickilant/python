import moment from "moment";

import { formTypes } from "../../../../shared/containers/ManagementForm/formTypes";
import { dateFormat } from "../../../../shared/constants/dateFormats";
import { companiesArray } from "../../../../organizations/selectors/companies";
import { usersArray, userWithId } from "../../../../users/selectors/users";
import { universalSubmitValueAction } from "../../../../shared/actions/managementForm/actions";
import { selectActiveProject } from "../../../../projects/selectors/projects";
import { selectedCategory } from "../../../../categories/selectors/treeStructure";
import { loggedInUser } from "../../../../users/selectors/permissions";
import { issueCategoriesLabels } from "../../../../shared/constants/issueСategories";

export const prescription_config = [
    // {
    //     name: "number",
    //     type: formTypes.INPUT,
    //     is_required: true,
    //     label: "Номер предписания",
    // },
    {
        name: "criticality",
        type: formTypes.SELECTOR,
        options: [
            { value: "MAJOR", label: "Устранение" },
            { value: "CRITICAL", label: "Остановка работ" },
        ],
        is_required: true,
        label: "Критичность",
    },
    {
        name: "issued_to",
        type: formTypes.SELECTOR,
        label: "Выдано организации",
        source: ({ config, state }) => ({
            ...config,
            options: companiesArray(state),
        }),
        is_required: true,
    },
    {
        name: "issued_by",
        type: formTypes.TEXT,
        value_source: ({ state, data }) => {
            const current = loggedInUser(state).user;
            if (data.issued_by_full && data.issued_by_full.sid !== current.sid) {
                return data.issued_by_full.full_name;
            }
            return loggedInUser(state).user.full_name;
        },
        source: ({ config, state, data }) => {
            const current = loggedInUser(state).user;
            let label = "Мною, представителем СК";
            let help = current.position;

            if (data.issued_by_full && data.issued_by_full.sid !== current.sid) {
                label = "Представителем СК";
                help = data.issued_by_full.position;
            }

            return {
                ...config,
                label,
                help,
            };
        },
    },
    {
        name: "by_order",
        type: formTypes.INPUT,
        label: "На основании Распоряжения",
    },
    {
        name: "issued_with_role",
        type: formTypes.SELECTOR,
        label: "В присутствии ответственного представителя",
        is_disabled: true,
        value_source: () => "",
        options: [
            { value: "", label: "технического заказчика" },
        ],
    },
    {
        name: "issued_with_company",
        type: formTypes.SELECTOR,
        label: "Организация представителя",
        source: ({ config, state }) => ({
            ...config,
            options: companiesArray(state),
        }),
    },
    {
        name: "issued_with",
        type: formTypes.SELECTOR,
        label: "Ф.И.О. представителя",
        is_required: false, // TODO: only on select org in issued_organization
        source: ({ config, state, data }) => ({
            ...config,
            options: usersArray(state, data.issued_with_company),
            is_disabled: !data.issued_with_company,
        })
        ,
    },
    {
        name: "cause",
        type: formTypes.SELECTOR,
        label: "В результате",
        value_source: ({ data }) => (data.cause ? data.cause : "current_examination"),
        options: [
            { value: "current_examination", label: "Текущего обследования" },
            { value: "planned_examination", label: "Планового обследования" },
            { value: "inspection_examination", label: "Инспекционного обследования " },
            { value: "target_examination", label: "Целевого обследования" },
        ],
        is_required: true,
    },
    {
        name: "since",
        type: formTypes.DATE_INPUT,
        label: "С",
        format: dateFormat,
        value_source: ({ data }) => (data.since ? data.since : moment().subtract(1, "days")),
        disabled_date: ({ date: curDate }) => {
            const curDF = curDate.format(dateFormat);
            if (curDF === moment().format(dateFormat)
                || curDF === moment().subtract(1, "days").format(dateFormat)) {
                return false;
            }
            return curDate.valueOf() > moment().valueOf();
        },
    },
    {
        name: "by",
        type: formTypes.DATE_INPUT,
        label: "По",
        format: dateFormat,
        value_source: ({ data, changeValue, type }) => {
            if (data.since && data.by) {
                if (moment(data.by).valueOf() < moment(data.since).valueOf()) {
                    changeValue(type, ["by"], moment().valueOf());
                }
            }

            return data.by;
        },
        disabled_date: ({ date: curDate, data }) => {
            const limit = data.since ? moment(data.since) : moment().subtract(1, "days");
            return curDate.format(dateFormat) < limit.format(dateFormat) || curDate.valueOf() >= moment().valueOf();
        },
    },
    {
        name: "form_divider",
        type: formTypes.DIVIDER,
        value_source: () => "выявлены следующие нарушения и несоответствия:",
    },
    {
        name: "description",
        type: formTypes.TEXTAREA,
        label: "Краткое изложение выявленного нарушения",
        is_required: true,
        placeholder: "Заполняется вручную",
    },
    {
        name: "specific_item",
        type: formTypes.TEXTAREA,
        label: "Пункт требований, который нарушен/не исполнен",
        placeholder: "Заполняется вручную",
    },
    {
        name: "document",
        type: formTypes.SELECTOR,
        label: "Ссылка на нормативный документ",
        is_disabled: true,
        options: [
            { value: "", label: "Не выбран" },
        ],
    },
    {
        name: "suggested_solution",
        type: formTypes.TEXTAREA,
        label: "Предлагаемые меры",
        placeholder: "Заполняется вручную",
    },
    {
        name: "issue_categories",
        type: formTypes.CASCADER,
        label: "Категории нарушения",
        options: [
            {
                label: "Правила ПБ, ОТ и ОС",
                value: "RULES",
                children: [
                    { value: "LABOR_SAFETY_VIOLATIONS", label: issueCategoriesLabels.LABOR_SAFETY_VIOLATIONS },
                    { value: "INDUSTRIAL_SAFETY_VIOLATIONS", label: issueCategoriesLabels.INDUSTRIAL_SAFETY_VIOLATIONS },
                    { value: "VIOLATIONS_OF_THE_TERRITORY_AND_WORKPLACE", label: issueCategoriesLabels.VIOLATIONS_OF_THE_TERRITORY_AND_WORKPLACE },
                    { value: "FIRE_SAFETY_VIOLATIONS", label: issueCategoriesLabels.FIRE_SAFETY_VIOLATIONS },
                    { value: "ENVIRONMENTAL_IMPAIRMENT", label: issueCategoriesLabels.ENVIRONMENTAL_IMPAIRMENT },
                    { value: "TRANSPORT_SAFETY", label: issueCategoriesLabels.TRANSPORT_SAFETY },
                    { value: "ELECTRICAL_SAFETY_VIOLATION", label: issueCategoriesLabels.ELECTRICAL_SAFETY_VIOLATION },
                ],
            },
            {
                label: "СМР",
                value: "ACTIVITY",
                children: [
                    // { value: "OT_AND_TB_RULES", label: issueCategoriesLabels.OT_AND_TB_RULES },
                    { value: "LICENSING_AND_ADMISSION_DOCUMENTATION", label: issueCategoriesLabels.LICENSING_AND_ADMISSION_DOCUMENTATION },
                    { value: "EXECUTIVE_DOCUMENTATION", label: issueCategoriesLabels.EXECUTIVE_DOCUMENTATION },
                    { value: "STORAGE_AND_TRANSPORTATION", label: issueCategoriesLabels.STORAGE_AND_TRANSPORTATION },
                    { value: "INPUT_CONTROL", label: issueCategoriesLabels.INPUT_CONTROL },
                    { value: "ASSEMBLY_AND_WELDING", label: issueCategoriesLabels.ASSEMBLY_AND_WELDING },
                    { value: "UNBREAKABLE_CONTROL", label: issueCategoriesLabels.UNBREAKABLE_CONTROL },
                    { value: "EXCAVATION", label: issueCategoriesLabels.EXCAVATION },
                    { value: "ELECTRIC_INSTALLATION_WORKS", label: issueCategoriesLabels.ELECTRIC_INSTALLATION_WORKS },
                    { value: "GENERAL_BUILDING_WORKS", label: issueCategoriesLabels.GENERAL_BUILDING_WORKS },
                    { value: "PNEUMATIC_AND_HYDRO_TESTS", label: issueCategoriesLabels.PNEUMATIC_AND_HYDRO_TESTS },
                    { value: "INSULATION_WORKS", label: issueCategoriesLabels.INSULATION_WORKS },
                    { value: "GEODETIC_BREAKDOWN", label: issueCategoriesLabels.GEODETIC_BREAKDOWN },
                    { value: "USE_OF_AN_UNVERIFIED_TOOL", label: issueCategoriesLabels.USE_OF_AN_UNVERIFIED_TOOL },
                    { value: "LAYING_AND_BASING_OF_PIPELINES", label: issueCategoriesLabels.LAYING_AND_BASING_OF_PIPELINES },
                    { value: "OPERATIONAL_CONTROL", label: issueCategoriesLabels.OPERATIONAL_CONTROL },
                    { value: "FAILURE_OF_PREVIOUS_REQUIREMENTS", label: issueCategoriesLabels.FAILURE_OF_PREVIOUS_REQUIREMENTS },
                    { value: "CERTIFICATION_AND_QUALIFICATION", label: issueCategoriesLabels.CERTIFICATION_AND_QUALIFICATION },
                ],
            },

            { value: "OTHER", label: issueCategoriesLabels.OTHER, children: [] },
        ],
        is_required: true,
    },
    {
        name: "issue_categories_other",
        type: formTypes.INPUT,
        label: "Своя категория",
        is_visible: ({ data }) => data.issue_categories === "OTHER",
        is_required: true,
    },
    {
        name: "deadline",
        type: formTypes.DATE_INPUT,
        label: "Срок устранения (до)",
        format: dateFormat,
        disabled_date: ({ date: curDate }) => curDate.isBefore(moment().subtract(1, "days")),
        is_required: true,
    },
    {
        name: "document_code",
        type: formTypes.SELECTOR,
        label: "Номер/шифр фото или иного документа",
        options: [
            { value: "", label: "Не выбран" },
        ],
        is_disabled: true,
    },
    {
        name: "explanation",
        type: formTypes.TEXT,
        label: "Пояснения",
        value_source: () => "В связи с тем, что выявленные в ходе обследования факты повлекли нарушение Федерального закона № 116 \"О промышленной безопасности…\", как следствие, ведут к снижению качества работ, увеличению сроков строительства, удорожанию строительства.",
    },
    {
        name: "assignee",
        type: formTypes.SELECTOR,
        label: "Предписнаие к исполнению принял",
        is_required: true,
        source: ({ config, state, data }) => ({
            ...config,
            is_disabled: !data.issued_to,
            options: usersArray(state, data.issued_to),
        })
        ,
    },
    {
        name: "copies",
        type: formTypes.CLONER,
        cloning_limit: 8,
        source: ({ data, config }) => ({
            ...config,
            cloning_count: (data.copies && data.copies.length) || 1,
        }),
        top_panel: {
            name: "title",
            type: formTypes.TEXT,
            value_source: () => "Копии направлены:",
        },
        body: [
            {
                name: "organization",
                type: formTypes.SELECTOR,
                label: "Организация",
                value_source: ({ data, clonerIndex }) => (data.copies && data.copies[clonerIndex] ? data.copies[clonerIndex].organization : ""),
                source: ({ config, state }) => ({
                    ...config,
                    options: [
                        { value: "", label: "Не выбрана" },
                        ...companiesArray(state),
                    ],
                }),
            },
            {
                name: "position",
                type: formTypes.SELECTOR,
                label: "Должность, Ф.И.О.",
                source: ({
                    config, state, data, clonerIndex, changeValue, type,
                }) => {
                    const organization = data.copies && data.copies[clonerIndex] && data.copies[clonerIndex].organization;
                    const position = data.copies && data.copies[clonerIndex] && data.copies[clonerIndex].position;
                    const user = userWithId(state, position);

                    if (user && user.company.sid !== organization) changeValue(type, "position", "");

                    const userHelp = () => {
                        if (user) return user.position;

                        if (organization) return "Это поле не может быть пустым.";

                        return "";
                    };

                    return {
                        ...config,
                        options: usersArray(state, organization),
                        help: userHelp(),
                        is_required: organization,
                        is_disabled: !organization,
                    };
                },
            },
        ],
        bottom_panel: {
            name: "inc",
            type: formTypes.BUTTON,
            btn_label: "Добавить адресата",
            on_click: ({ addCloningCount }) => addCloningCount(),
            source: ({ config, data, cloningNumber }) => {
                const fieldsFilled = data.copies && data.copies.every((item) => item.organization && item.position);
                const parentLength = data.copies && data.copies.length;

                return {
                    ...config,
                    is_disabled: !(fieldsFilled && parentLength === cloningNumber),
                };
            },
        },
    },
    {
        name: "current_user",
        type: formTypes.TEXT,
        label: "Предписание выдал",
        value_source: ({ state, data }) => {
            const current = loggedInUser(state).user;
            if (data.issued_by_full && data.issued_by_full.sid !== current.sid) {
                return data.issued_by_full.full_name;
            }
            return loggedInUser(state).user.full_name;
        },
    },
    {
        name: "submit",
        type: formTypes.BUTTON,
        on_click: ({
            state, data, isEdited, isValidated, changedFields, dispatch,
        }) => {
            dispatch(universalSubmitValueAction("documents", "document", {
                isEdited,
                isValidated,
                changedFields,
                data: {
                    ...data,
                    deadline: data.deadline ? data.deadline : moment().format("YYYY-MM-DD"),
                    project: selectActiveProject(state),
                    related_category: !isEdited && selectedCategory(state),
                },
            }));
        },
        source: ({ config, isEdited, changedFields }) => ({
            ...config,
            is_disabled: Object.keys(changedFields).length === 0,
            btn_label: isEdited
                ? "Сохранить изменения"
                : "Создать предписание",
        }),
    },
];
