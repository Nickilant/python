import moment from "moment";
import { formTypes } from "../../../../shared/containers/ManagementForm/formTypes";
import { universalSubmitValueAction } from "../../../../shared/actions/managementForm/actions";
import { selectActiveProject } from "../../../../projects/selectors/projects";
import { filterByGroup, selectCurrentProjectDocuments } from "../../../../documents/selectors/documents";
import { getAllChildren } from "../../../../categories/selectors/treeStructure";
import { loggedInUser } from "../../../../users/selectors/permissions";
import { dateFormat } from "../../../../shared/constants/dateFormats";

export const act_config = [
    {
        name: "as_prescribed",
        type: formTypes.SELECTOR,
        label: "В соответствии с предписанием",
        source: ({ config, state }) => {
            // TODO: get all opened prescriptions from current node in tree
            const categories = getAllChildren(state);

            return {
                ...config,
                options: filterByGroup(
                    selectCurrentProjectDocuments(state).filter((it) => it.type === "prescription"),
                    categories,
                ).map((it) => ({
                    value: it.id,
                    label: it.number,
                })),
            };
        },
        is_required: true,
    },
    // {
    //     name: "number",
    //     type: formTypes.INPUT,
    //     label: "Номер акта",
    //     is_required: true,
    // },
    {
        name: "act_date",
        type: formTypes.TEXT,
        label: "От",
        is_required: true,
        value_source: () => moment().format(dateFormat),
    },
    {
        // TODO: displayed if issued_to exist
        name: "act_issued_by",
        type: formTypes.TEXT,
        label: "Выданным",
        value_source: ({ data, state }) => data.as_prescribed
                && state.documents.crud.items[data.as_prescribed].issued_to_full.name,
    },
    {
        // TODO: displayed if issue_reason exist
        name: "by_order",
        type: formTypes.TEXT,
        label: "На основании распоряжения",
        value_source: ({ data, state }) => {
            // TODO: get issue_reason
            //  from chosen prescription in as_prescribed
            const prescription = data.as_prescribed
                && state.documents.crud.items[data.as_prescribed];
            return prescription
                && `${prescription.by_order} от ${prescription.date_text}`;
        },
        is_visible: ({ data, state }) => {
            const prescription = data.as_prescribed
                && state.documents.crud.items[data.as_prescribed];
            return prescription && prescription.by_order;
        },
    },
    {
        name: "form_divider",
        type: formTypes.DIVIDER,
        value_source: () => "выполнены следующие мероприятия:",
    },
    {
        name: "work_description",
        type: formTypes.TEXTAREA,
        placeholder: "Заполняется вручную",
        label: "Описание мероприятия",
        is_required: true,
    },
    {
        name: "current_user",
        type: formTypes.TEXT,
        label: "Представитель подрядной организации",
        // TODO: some selector would be more appropriate
        value_source: ({ state }) => loggedInUser(state).user.full_name,
        source: ({ config, state }) => {
            const { user } = loggedInUser(state);

            return {
                ...config,
                help: `${user.position}`, // TODO company
            };
        },
    },
    {
        name: "representative_construction_control",
        type: formTypes.TEXT,
        label: "Представитель строительного контроля",
        value_source: ({ state, data }) => {
            // TODO: some selector would be more appropriate
            const prescription = data.as_prescribed
                && state.documents.crud.items[data.as_prescribed];
            return prescription && prescription.issued_by_full.full_name;
        },
        source: ({ config, state, data }) => {
            const prescription = data.as_prescribed
                && state.documents.crud.items[data.as_prescribed];

            return {
                ...config,
                help: prescription
                    && `${prescription.issued_by_full.position} ${prescription.issued_by_full.company.name}`,
            };
        },
    },
    {
        name: "submit",
        type: formTypes.BUTTON,
        on_click: ({
            state, data, isEdited, isValidated, changedFields, dispatch,
        }) => {
            dispatch(universalSubmitValueAction("documents", "document", {
                isEdited,
                isValidated,
                changedFields,
                data: {
                    ...data,
                    act_date: data.act_date ? data.act_date : moment().format("YYYY-MM-DD"),
                    project: selectActiveProject(state),
                    related_category: !isEdited
                        && data.as_prescribed
                        && state.documents.crud.items[data.as_prescribed].group,
                },
            }));
        },
        source: ({ config, isEdited, changedFields }) => ({
            ...config,
            is_disabled: Object.keys(changedFields).length === 0,
            btn_label: isEdited
                ? "Сохранить изменения"
                : "Создать акт",
        }),
    },
];
