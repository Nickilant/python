import React from "react";
import { Form } from "antd";

import { ManagementForm } from "../../../../shared/containers/ManagementForm/container";
import { formConfig } from "./form_config";

import "./styles.scss";

export const PrescriptionDetailsFormWidget = () => {
    const titleText = {
        prescription: "предписания",
        remark: "замечания",
        act: "акта",
    };

    const handleSubmit = (e) => {
        e.preventDefault();
    };

    return (
        <div className="prescription-details-form">
            <Form
                className="details-form"
                onSubmit={handleSubmit}
            >
                <ManagementForm formConfig={formConfig} reducer="documentForm" moduleAction="DOCUMENTS" module="documents">
                    {
                        (isEdited, state) => (
                            <div className="details-form-header">
                                <div className="title">
                                    {state.users.currentUser.user.company}
                                </div>
                                {
                                    state.documents.documentForm.data.type && (
                                        <div className="sub-title">
                                            {isEdited ? "Редактирование " : "Создание " }
                                            {titleText[state.documents.documentForm.data.type]}
                                        </div>
                                    )
                                }
                            </div>
                        )
                    }
                </ManagementForm>
            </Form>
        </div>
    );
};
