import React from "react";

import "./styles.scss";
import cx from "classnames";

export const GeotagsListItem = (props) => {
    const {
        geotag, selectItem, isSelected, remove,
    } = props;

    const {
        name,
        desc,
        favorite,
    } = geotag;

    const handleSelectItem = () => {
        selectItem(geotag);
    };

    const handleRemove = () => {
        remove(geotag);
    };

    // const handleEdit = () => {
    //     edit(geotag);
    // };

    return (
        <li onClick={handleSelectItem} className={cx("construction-control-geo-list-item", { selected: isSelected })}>
            <div className="img" />
            <div className="geotag-content">
                <div className="title">
                    {name}
                    { favorite && <div className="star" /> }
                </div>
                <div className="desc">
                    {desc}
                </div>
            </div>
            <div className="actions">
                {/* <div onClick={handleEdit} className="actions-icon edit" /> */}
                <div onClick={handleRemove} className="actions-icon remove" />
            </div>
        </li>
    );
};
