// import React from "react";

// import pngIcon from "./assets/png_file.svg";
// import pdfIcon from "./assets/pdf_file.svg";

export const labels = [
    { name: "location", label: "Наименование объекта:" },
    { name: "code", label: "Шифр объекта:" },
    { name: "issued_to", label: "Выдано организации:" },
    { name: "issued_by", label: "Выдал:" },
    { name: "issued_with_role", label: "В присутствии ответственного представителя:" },
    { name: "divider" },
    { name: "description", label: "Краткое изложение выявленных несоответствий:" },
    // { name: "document_code", label: (<img src={pngIcon} alt="png" />) },
    { name: "divider" },
    { name: "specific_item", label: "Нормативные требования, которые нарушены:" },
    // { name: "document", label: (<img src={pdfIcon} alt="pdf" />) },
    { name: "divider" },
    { name: "suggested_solution", label: "Предлагаемые меры:" },
    { name: "divider" },
    { name: "issue_categories", label: "Категории нарушения:" },
    { name: "divider" },
    { name: "deadline", label: "срок устранения" },
    { name: "divider" },
    { name: "assignee", label: "Предписание к исполнению принял:" },
    { name: "checked_status_author", label: "Подтвердил устранение нарушения:" },

    // { name: "informed", label: "Копии направлены:" },
];
