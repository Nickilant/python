import React from "react";
import cx from "classnames";
import moment from "moment";

import { labels } from "./labels";

import "./styles.scss";
import { UserInfo } from "../../components/UserInfo/component";
import { DOCUMENT_STATUS } from "../../constants/statuses";
import { issueCategoriesLabels } from "../../../../shared/constants/issueСategories";

const dateFormat = "DD.MM.YYYY";

export const PrescriptionDetailsViewPrescription = ({ document }) => {
    const infoItem = (item, index) => {
        switch (item.name) {
            case "deadline": {
                const ONE_DAY = (24 * 60 * 60 * 1000);
                const today = new Date();
                const diff = today - document.deadline - ONE_DAY;
                const countOfDays = Math.ceil(diff / ONE_DAY);

                let str = "просрочено на";
                if (countOfDays < 0) {
                    str = "осталось";
                } else if (countOfDays === 0) str = "срок истекает сегодня";

                return (
                    <div key={index} className={`info-item info-${item.name}`}>
                        <div>
                            <div className="label">
                                {item.label}
                            </div>
                            {
                                moment(document[item.name]).isSame(moment(), "day")
                                    ? <span className="info-item-value-bold">Немедленно</span>
                                    : (
                                        <>
                                            до
                                            {" "}
                                            <span className="info-item-value-bold">
                                                {
                                                    moment(document[item.name])
                                                        .format(dateFormat)
                                                }
                                            </span>
                                        </>
                                    )
                            }

                        </div>
                        <div
                            className={cx("sub-block", (document.status !== "checked") && (document.status !== DOCUMENT_STATUS.RESOLVED) ? "info-warning" : "info-success")}
                        >
                            <div className="label">
                                {
                                    (document.status === "checked") || (document.status === DOCUMENT_STATUS.RESOLVED)
                                        ? "устранено"
                                        : str
                                }
                            </div>
                            {
                                (document.status === "checked") || (document.status === DOCUMENT_STATUS.RESOLVED)
                                    ? moment(document.dateOfCompletion)
                                        .format(dateFormat)
                                    : `${Math.abs(countOfDays)} дн.`
                            }
                        </div>
                    </div>
                );
            }

            case "issued_to":
                return (
                    <div key={index} className={`info-item info-${item.name}`}>
                        <span className="label">
                            {item.label}
                        </span>
                        <span>
                            {document.issued_to_full.name}
                        </span>
                    </div>
                );

            case "issued_by":
                return (
                    <div key={index} className={`info-item info-${item.name}`}>
                        <span className="label">
                            {item.label}
                        </span>
                        <UserInfo
                            user={document.issued_by_full}
                        />
                        {document.by_order && (
                            <span>
                                {`на основании распоряжения ${document.by_order}`}
                            </span>
                        )}
                    </div>
                );

            case "issued_with_role":
                return document.issued_with_full && (
                    <div key={index} className={`info-item info-${item.name}`}>
                        <span className="label">
                            {item.label}
                        </span>
                        <UserInfo
                            user={document.issued_with_full}
                        />
                    </div>
                );

            case "assignee":
                return (
                    <div key={index} className={`info-item info-${item.name}`}>
                        <span className="label">
                            {item.label}
                        </span>
                        <UserInfo
                            user={document.assignee_full}
                        />

                    </div>
                );
            case "checked_status_author":
                if (!document.checked_status_author) {
                    break;
                }
                return (
                    <div key={index} className={`info-item info-${item.name}`}>
                        <span className="label">
                            {item.label}
                        </span>
                        <UserInfo
                            user={document[item.name]}
                        />
                    </div>
                );
            case "issue_categories":
                return (
                    <div key={index} className={`info-item info-${item.name}`}>
                        <span className="label">
                            {item.label}
                        </span>
                        {document[item.name] === "OTHER" ? document.issue_categories_other : issueCategoriesLabels[document[item.name]]}
                    </div>
                );
            default:
                return (
                    <div key={index} className={`info-item info-${item.name}`}>
                        <span className="label">
                            {item.label}
                        </span>
                        {document[item.name]}
                    </div>
                );
        }
    };

    return (
        <div className="prescription-details-view-item">
            <div className="divider" />
            <div className="info">
                {
                    labels.map((item, index) => (item.name === "divider"
                        ? (<div key={index} className="divider" />)
                        : infoItem(item, index)))
                }
            </div>
        </div>
    );
};
