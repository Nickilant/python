import React from "react";
import { useSelector } from "react-redux";

import { typeLabel } from "../../constants/documentsLabel";
import { confirm } from "../../../../shared/ConfirmModal/component";
import { canDeleteDocument, canEditDocument } from "../../selectors/permissions";

import "./styles.scss";

export const PrescriptionBottomPanel = (props) => {
    const {
        remove, edit, type, document,
    } = props;

    const canEdit = useSelector((state) => canEditDocument(state, document.type));
    const canDelete = useSelector((state) => canDeleteDocument(state, document.type));

    const handleEdit = () => {
        edit();
    };

    const handleRemove = () => {
        confirm({
            onOk: () => {
                remove();
            },
            content: "Вы уверены, что хотите удалить этот документ?",
        });
    };

    return (
        (canEdit || canDelete) && (
            <div className="bottom-panel">
                {canEdit && (
                    <button className="btn-edit" onClick={handleEdit}>
                        {`Редактировать ${typeLabel[type]}`}
                    </button>
                )}
                {canDelete && (
                    <button
                        className="btn-remove"
                        onClick={() => confirm({
                            onOk() {
                                handleRemove();
                            },
                            content: `Удалить ${typeLabel[type]}? Это действие невозможно отменить.`,
                        })}
                    >
                        {`Удалить ${typeLabel[type]}`}
                    </button>
                )}
            </div>
        )
    );
};
