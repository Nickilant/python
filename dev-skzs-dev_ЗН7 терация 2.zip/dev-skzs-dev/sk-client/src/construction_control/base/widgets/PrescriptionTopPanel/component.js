import React, { useEffect, useState } from "react";
import { last } from "lodash";
import { useSelector } from "react-redux";
import { Input, Modal, Select } from "antd";

import { DOCUMENT_STATUS } from "../../constants/statuses";
import { getStatusTransitions } from "../../selectors/statuses";
import { canCreateActForPrescription } from "../../selectors/permissions";
import { getDaysTitle } from "../../../../shared/helpers/getDaysTitle";

import closeIcon from "./assets/close.svg";
import "./styles.scss";

const { Option } = Select;

export const PrescriptionTopPanel = (props) => {
    const {
        changeStatus,
        // print,
        moveTo,
        createAct,
        document,
        downloadPrescription,
        downloadAct,
    } = props;
    const { status, title, type } = document;

    const [openModal, setModal] = useState(false);
    const [selectedStatus, setStatus] = useState(status);
    const [days, setDays] = useState(10);

    useEffect(() => {
        setStatus(status);
    }, [status]);

    const possibleStatuses = useSelector((state) => getStatusTransitions(state, document));
    const canCreateAct = useSelector((state) => canCreateActForPrescription(state, document));

    const handleChangeSelect = (value) => {
        setStatus(value);
        setModal(true);
    };

    const handleOk = () => {
        if (!parseInt(days, 10)) return false;
        setModal(false);
        return changeStatus({ status: selectedStatus, days });
    };

    const handleCancel = () => {
        setModal(false);
        setStatus(status);
    };

    // const handlePrint = () => {
    //     print();
    // };

    const typesValues = {
        prescription: "Предписание",
        remark: "Замечание",
    };

    const selectValues = {
        [DOCUMENT_STATUS.NEW]: "открыто",
        [DOCUMENT_STATUS.EXPIRED]: "просрочено",
        [DOCUMENT_STATUS.RESOLVED]: "выполнено",
        [DOCUMENT_STATUS.CHECKED]: "проверено",
        [DOCUMENT_STATUS.RESCHEDULED]: "перенесено",
    };

    const renderBtn = () => {
        const btnClass = "documents-move-btn";

        switch (type) {
            case "prescription": {
                return (
                    <>
                        {
                            document.acts.length > 0
                            && (
                                <button
                                    className={btnClass}
                                    onClick={() => moveTo(last(document.acts))}
                                >
                                    Перейти к прикреплённому акту-уведомлению
                                </button>
                            )
                        }
                        {
                            canCreateAct
                            && (
                                <button className={btnClass} onClick={createAct}>
                                    Создать акт-уведомление
                                </button>
                            )
                        }
                        <button
                            className="btn-usual btn-download"
                            style={{ marginTop: 0 }}
                            onClick={downloadPrescription}
                        >
                            Скачать документ
                        </button>
                    </>
                );
            }
            case "act": {
                return (
                    <>
                        <button className={btnClass} onClick={() => moveTo(document.prescription)}>
                            Перейти к соответствующему предписанию
                        </button>

                        <button className="btn-usual btn-download" style={{ marginTop: 0 }} onClick={downloadAct}>
                            Скачать документ
                        </button>
                    </>
                );
            }
            case "remark": {
                return (<></>);
            }
            default:
                return (<></>);
        }
    };

    const handleChangeDays = (e) => {
        const { value } = e.target;
        if (value === "") {
            setDays("");
        }
        const days = parseInt(value, 10);

        if ((!Number.isNaN(days) && days > 0)) {
            setDays(days);
        }
    };

    return (
        <div className="top-panel">
            {
                type !== "act" && (
                    <div>
                        <Select
                            className={`top-panel-status ${selectedStatus}-document-status-active`}
                            value={selectedStatus}
                            onChange={handleChangeSelect}
                        >
                            {
                                Object.entries(selectValues)
                                    .filter(([value]) => possibleStatuses.includes(value))
                                    .map(([value, statusTitle]) => (
                                        <Option
                                            className={`${value}-document-status`}
                                            key={value}
                                            value={value}
                                        >
                                            {`${typesValues[type]} ${statusTitle}`}
                                        </Option>
                                    ))
                            }
                        </Select>
                        <Modal
                            className="documents-top-panel-modal"
                            title="Изменить статус?"
                            icon={() => (<img src={closeIcon} alt="Закрыть" />)}
                            visible={openModal}
                            onOk={handleOk}
                            onCancel={handleCancel}
                            footer={[
                                <button className="cancel-btn" key="back" onClick={handleCancel}>
                                    Вернуться назад
                                </button>,
                                <div key="submit" className="submit-btn-block">
                                    <button className="submit-btn" onClick={handleOk}>
                                        Изменить статус
                                    </button>
                                    <span className="submit-btn-help">Это действие невозможно отменить!</span>
                                </div>,
                            ]}
                        >
                            <div>
                                <span className="documents-top-panel-modal-bold">{`Изменить статус ${title}  `}</span>
                                <span className="documents-top-panel-modal-bold">{`${selectValues[status]} на `}</span>
                                <span
                                    className="documents-top-panel-modal-bold"
                                >
                                    {`${selectValues[selectedStatus]}?`}
                                </span>
                                {selectedStatus === "rescheduled" && (
                                    <div className="days-block">
                                        <Input className="days" value={days} onChange={handleChangeDays} />
                                        <div className="days-title">{getDaysTitle(days)}</div>
                                    </div>
                                )}
                            </div>
                        </Modal>
                    </div>
                )
            }
            {/* <button */}
            {/* className="documents-print-btn disabled" */}
            {/*    onClick={handlePrint} */}
            {/* > */}
            {/*    <img className="documents-print-icon" src={printIcon} alt="Печать"/> */}
            {/*    Версия для печати */}
            {/* </button> */}
            {renderBtn()}
        </div>
    );
};
