import React from "react";
import { useDispatch, useSelector } from "react-redux";

import RightColumn from "../../../../core/components/RightColumn/component";
import { selectActiveProject } from "../../../../projects/selectors/projects";
import { selectedDocumentView } from "../../../../documents/selectors/documents";
import { previewConfig } from "./config";
import { documentsCRUDActions } from "../../../../documents/actions/actions";
import { PREVIEW_MODULES } from "./previewModules";

export const DocumentView = ({ module = PREVIEW_MODULES.CONSTRUCTION_CONTROL, ...context }) => {
    const dispatch = useDispatch();
    const project = useSelector(selectActiveProject);
    const document = useSelector(selectedDocumentView);

    const derivedConfig = {
        dispatch,
        project,
        document,
        handleEdit: (mod) => {
            dispatch(documentsCRUDActions.use.ENTITY_FORM_EDIT({ ...document, project, module: mod }));
        },
        handleRemove: () => {
            dispatch(documentsCRUDActions.use.DELETE_ENTITY({ source: { ...document, project } }));
        },
        ...context,
    };

    const {
        icon,
        title,
        subTitle,
        otherActions,
        topAction,
        body,
        bottomAction,
    } = previewConfig[module](derivedConfig);

    return (
        <RightColumn
            icon={icon}
            title={title}
            subTitle={subTitle}
            otherActions={otherActions}
            TopAction={topAction}
            Body={body}
            BottomAction={bottomAction}
        />
    );
};
