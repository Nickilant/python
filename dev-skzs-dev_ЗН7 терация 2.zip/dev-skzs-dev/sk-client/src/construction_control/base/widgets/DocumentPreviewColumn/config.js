import React from "react";
import cx from "classnames";

import moment from "moment";
import axios from "axios";
import { PREVIEW_MODULES } from "./previewModules";
import { PrescriptionTopPanel } from "../PrescriptionTopPanel/component";
import { documentsCRUDActions } from "../../../../documents/actions/actions";
import { DOCUMENT_STATUS } from "../../constants/statuses";
import { commentsCRUDActions } from "../../../../comments/actions/actions";
import { openRightColumnContainerAction } from "../../../../shared/actions/RightColumnContainer/actions";
import { WIDGET_TYPES } from "../../../../shared/constants/widgetTypes";
import { universalClearFormAction } from "../../../../shared/actions/managementForm/actions";
import { PrescriptionBottomPanel } from "../PrescriptionBottomPanel/component";
import { PreviewTopPanel } from "../../../../executive_documentation/components/PreviewTopPanel/component";
import { DocumentPreviewSwitcher } from "../../../../executive_documentation/containers/DocumentPreviewSwitcher/component";
import { PreviewBottomPanel } from "../../../../executive_documentation/components/PreviewBottomPanel/component";
import executiveDocumentationIcon from "./assets/executive-documentation-icon.svg";
import { RowViewBody } from "../../../../activities/components/RowViewBody/component";
import { ViewTopPanel } from "../../../../activities/components/ViewTopPanel/component";
import { ViewBottomPanel } from "../../../../activities/components/ViewBottomPanel/component";
import { PrescriptionDetailsSwitcherComponent } from "../../components/PrescriptionDetailsSwitcher/component";

export const previewConfig = {
    [PREVIEW_MODULES.CONSTRUCTION_CONTROL]: (context) => {
        const {
            document,
            project,
            dispatch,
            handleEdit,
            handleRemove,
        } = context;

        const handlePrint = () => {
        };

        const handleChangeStatus = ({ status, days }) => {
            if (status === DOCUMENT_STATUS.RESCHEDULED) {
                dispatch(documentsCRUDActions.use.UPDATE_ENTITY({
                    source: { ...document, project },
                    form: { status, deadline: moment(document.deadline).add(days, "days") },
                }));
            } else {
                dispatch(documentsCRUDActions.use.UPDATE_ENTITY({
                    source: { ...document, project },
                    form: { status },
                }));
            }
        };

        const handleMoveTo = (item) => {
            dispatch(documentsCRUDActions.use.SELECT_SINGLE_ENTITY({ ...item, project }));
            dispatch(documentsCRUDActions.use.ENTITY_PREVIEW({ ...item, module: PREVIEW_MODULES.CONSTRUCTION_CONTROL }));
            dispatch(commentsCRUDActions.use.LIST_ENTITIES({ source: { project, entity: item } }));
            // TODO: possibly revert to the following to make url in sync. But parameters should be adjusted properly
            // const { id } = item;
            // const path = getURL(routerPathParams, ["projects", "section", "group", ["document", id]]);
            // dispatch(push(path));
        };

        const handleCreateAct = () => {
            dispatch(openRightColumnContainerAction(WIDGET_TYPES.DOCUMENT_MANAGEMENT_FORM, { module: PREVIEW_MODULES.CONSTRUCTION_CONTROL }));
            dispatch(universalClearFormAction("documents", "document", {
                type: "act",
                location: document.location,
                code: document.code,
                as_prescribed: document.id,
            }));
        };

        const handleDownloadPrescription = () => {
            axios.get(`projects/${project.key}/prescriptions/${document.id}/pdf`).then((r) => {
                const link = window.document.createElement("a");
                link.target = "_blank";
                link.download = r.data.url;
                link.href = r.data.url;
                link.click();
            });
        };

        const handleDownloadAct = () => {
            axios.get(`projects/${project.key}/acts/${document.id}/pdf`).then((r) => {
                const link = window.document.createElement("a");
                link.target = "_blank";
                link.download = r.data.url;
                link.href = r.data.url;
                link.click();
            });
        };

        if (!document) {
            return {};
        }

        return {
            icon: (
                <div className="bg-img icon-prediction">
                    <span className={cx(["badge", document && document.criticality])}>
                        {
                            {
                                CRITICAL: "О",
                                MAJOR: "У",
                            }[document.criticality]
                        }
                    </span>
                </div>
            ),
            title: document.title,
            subTitle: document.description,
            otherActions: [],
            topAction: (
                <PrescriptionTopPanel
                    document={document}
                    changeStatus={handleChangeStatus}
                    print={handlePrint}
                    moveTo={handleMoveTo}
                    createAct={handleCreateAct}
                    downloadPrescription={handleDownloadPrescription}
                    downloadAct={handleDownloadAct}
                />
            ),
            body: (<PrescriptionDetailsSwitcherComponent
                document={document}
            />),
            bottomAction: (<PrescriptionBottomPanel
                document={document}
                type={document.type}
                edit={() => handleEdit(PREVIEW_MODULES.CONSTRUCTION_CONTROL)}
                remove={handleRemove}
            />),
        };
    },
    [PREVIEW_MODULES.EXECUTIVE_DOCUMENTATION]: (context) => {
        const { document, handleRemove, handleEdit } = context;
        if (!document) {
            return {};
        }

        return {
            icon: (<img src={executiveDocumentationIcon} alt="иконка" />),
            title: (document.title),
            subTitle: (document.description),
            topAction: (<PreviewTopPanel />),
            body: (<DocumentPreviewSwitcher document={document} />),
            bottomAction: (<PreviewBottomPanel
                remove={handleRemove}
                edit={() => handleEdit(PREVIEW_MODULES.EXECUTIVE_DOCUMENTATION)}
            />),
        };
    },
    [PREVIEW_MODULES.ACTIVITIES]: ({ activity }) => ({
        title: activity && activity.title,
        subTitle: activity && activity.number,
        topAction: (<ViewTopPanel />),
        body: (<RowViewBody />),
        bottomAction: (<ViewBottomPanel />),
    }),
};
