import React from "react";
import cx from "classnames";
import moment from "moment";

import { labels } from "./labels";

import "./styles.scss";
import { UserInfo } from "../../components/UserInfo/component";

export const PrescriptionDetailsViewAct = ({ document }) => {
    const dateFormat = "DD.MM.YYYY";

    const infoItem = (item, index) => {
        switch (item.name) {
            case "date": {
                return (
                    <div key={index} className="info-item info-deadline">
                        <div
                            className={cx("sub-block", "info-success")}
                        >
                            <div className="label">
                                устранено
                            </div>
                            {moment(document[item.name]).format(dateFormat)}
                        </div>
                    </div>
                );
            }

            case "prescription":
                return (
                    <div key={index} className={`info-item info-${item.name}`}>
                        <span className="label">
                            {item.label}
                        </span>
                        <span>{document.prescription.number}</span>
                        <span>
                            {" "}
                            от
                            {document.prescription.date_text}
                        </span>
                    </div>
                );

            case "prescription_issued_by":
                return (
                    <div key={index} className={`info-item info-${item.name}`}>
                        <span className="label">
                            {item.label}
                        </span>
                        <UserInfo user={document.prescription.issued_by_full} />
                        {" "}

                        <span>
                            на основании распоряжения
                            {" "}
                            {document.prescription.by_order}
                        </span>
                    </div>
                );

            case "issued_by":
                return (
                    <div key={index} className={`info-item info-${item.name}`}>
                        <span className="label">
                            {item.label}
                        </span>
                        <UserInfo user={document.issued_by_full} />
                        {" "}
                    </div>
                );

            case "prescription_issued_by_initial":
                return (
                    document.prescription.issued_with_full && (
                        <div key={index} className={`info-item info-${item.name}`}>
                            <span className="label">
                                {item.label}
                            </span>
                            <UserInfo user={document.prescription.issued_with_full} />
                            {" "}

                        </div>
                    )
                );
            default:
                return (
                    <div key={index} className={`info-item info-${item.name}`}>
                        <span className="label">
                            {item.label}
                        </span>
                        {document[item.name]}
                    </div>
                );
        }
    };

    return (
        <div className="prescription-details-view-item">
            <div className="divider" />
            <div className="info">
                {
                    labels.map((item, index) => (item.name === "divider"
                        ? (<div key={index} className="divider" />)
                        : infoItem(item, index)))
                }
            </div>
        </div>
    );
};
