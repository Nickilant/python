export const labels = [
    { name: "location", label: "Наименование объекта:" },
    { name: "code", label: "Шифр объекта:" },
    { name: "prescription", label: "В соответствии с предписанием:" },
    { name: "prescription_issued_by", label: "Выданным:" },
    { name: "divider" },
    { name: "work_description", label: "Выполнены следующие мероприятия:" },
    { name: "divider" },
    { name: "date", label: "" },
    { name: "divider" },
    { name: "issued_by", label: "Представитель подрядной организации:" },
    { name: "divider" },
    { name: "prescription_issued_by_initial", label: "Представитель строительного контроля:" },
];
