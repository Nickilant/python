// import React from "react";

// import pngIcon from "./assets/png_file.svg";

export const labels = [
    { name: "location", label: "Наименование объекта:" },
    { name: "code", label: "Шифр объекта:" },
    { name: "issued_to", label: "Выдано:" },
    { name: "issued_by", label: "Выдал:" },
    { name: "issued_with_role", label: "В присутствии ответственного представителя:" },
    { name: "divider" },
    { name: "description", label: "Описание замечания:" },
    // { name: "document_code", label: (<img src={pngIcon} alt="png"/>) },
    { name: "divider" },
    { name: "suggested_solution", label: "Предлагаемые меры:" },
    { name: "divider" },
    { name: "deadline", label: "" },
    { name: "checked_status_author", label: "Подтвердил устранение нарушения:" },

    // { name: "divider" },
    // { name: "informed", label: "Копии направлены:" },
];
