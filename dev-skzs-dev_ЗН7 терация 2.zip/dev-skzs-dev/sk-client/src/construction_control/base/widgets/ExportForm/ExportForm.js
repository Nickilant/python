import React, { useEffect, useState } from "react";

import {
    Button, DatePicker, Form, Select,
} from "antd";

import "./styles.scss";
import moment from "moment";
import { connect, useSelector } from "react-redux";
import axios from "axios";
import { dateFormat } from "../../../../shared/constants/dateFormats";
import { companiesArray } from "../../../../organizations/selectors/companies";
import { selectActiveProject } from "../../../../projects/selectors/projects";

export const ExportFormComponent = (props) => {
    const {
        companies,
        routerPathParams,
        project,
    } = props;
    const contractors = [{ value: "all", label: "Все подрядчики" }, ...companies];

    const [selectedContractors, setSelectedContactors] = useState(["all"]);
    const [dateFrom, setDateFrom] = useState(moment(project.creation_date));
    const [dateTo, setDateTo] = useState(moment());
    const [format, setFormat] = useState("xls");

    const onChangeContactors = (values) => {
        if (values.length && values.length > 1 && values.includes("all")) {
            if (selectedContractors.includes("all")) {
                values.splice(values.findIndex((v) => v === "all"), 1);
            } else {
                values = ["all"];
            }
        } else if (!values.length) {
            values.push("all");
        }

        setSelectedContactors(values);
    };

    useEffect(() => {
        if (dateFrom.isSameOrAfter(dateTo)) {
            setDateTo(moment(dateFrom).add(1, "day"));
        }
    }, [dateFrom]); // eslint-disable-line react-hooks/exhaustive-deps

    useEffect(() => {
        if (dateTo.isSameOrBefore(dateFrom)) {
            setDateFrom(moment(dateTo).subtract(1, "day"));
        }
    }, [dateTo]); // eslint-disable-line react-hooks/exhaustive-deps

    const onChangeDateTo = (date) => {
        setDateTo(date);
    };

    const doExport = (e) => {
        e.preventDefault();
        axios.post(
            `projects/${routerPathParams.projects}/section/construction-control/group/${routerPathParams.group}/export/${format}`,
            {
                dates: [dateFrom.format("YYYY-MM-DD"), dateTo.format("YYYY-MM-DD")],
                contractors: selectedContractors[0] === "all" ? [] : selectedContractors,
            },
        )
            .then((r) => {
                const link = window.document.createElement("a");

                link.target = "_blank";
                link.download = r.data.url;
                link.href = r.data.url;
                link.click();
            });
    };

    return (
        <Form className="form" onSubmit={doExport}>
            <Form.Item className="inline-block" style={{ marginBottom: 0 }}>
                <span className="custom-label">Отчетный период с</span>
                <Form.Item
                    style={{ display: "inline-block", width: "144px" }}
                >
                    <DatePicker
                        value={dateFrom}
                        onChange={setDateFrom}
                        placeholder="ДД.ММ.ГГГГ"
                        format={dateFormat}
                        allowClear={false}
                    />
                </Form.Item>
                <span className="by">по</span>
                <Form.Item style={{ display: "inline-block", width: "144px" }}>
                    <DatePicker
                        value={dateTo}
                        onChange={onChangeDateTo}
                        placeholder="ДД.ММ.ГГГГ"
                        format={dateFormat}
                        allowClear={false}
                    />
                </Form.Item>
            </Form.Item>
            <Form.Item className="item-full contactors-input">
                <span className="custom-label">Подрядчики</span>
                <Select
                    showSearch
                    mode="multiple"
                    maxTagCount={0}
                    maxTagPlaceholder={() => (selectedContractors.length && selectedContractors[0] === "all" ? "Все подрядчики" : "Выберите нужные варианты")}
                    notFoundContent="Подрядчики не найдены"
                    optionFilterProp="children"
                    onChange={onChangeContactors}
                    value={selectedContractors}
                    filterOption={(input, option) => option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0}
                >
                    {
                        contractors.map((c, i) => <Select.Option key={i} value={c.value}>{c.label}</Select.Option>)
                    }
                </Select>
            </Form.Item>
            <div className="contractors-block">
                {
                    selectedContractors.map((c, i) => {
                        const con = contractors.find((contactor) => contactor.value === c);

                        if (c === "all") {
                            return (<></>);
                        }

                        return (
                            <div key={i} className="contractor">
                                {con.label}
                            </div>
                        );
                    })
                }
            </div>
            <Form.Item className="item-full format-input">
                <span className="custom-label">Формат выгружаемого документа</span>
                <Select value={format} onChange={setFormat}>
                    <Select.Option value="xls">XLS</Select.Option>
                    <Select.Option value="pdf">PDF</Select.Option>
                </Select>
            </Form.Item>
            <Form.Item>
                <Button className="submit-button" htmlType="submit">
                    Скачать документ
                </Button>
            </Form.Item>
        </Form>
    );
};

const mapStateToProps = (state, props) => ({
    companies: companiesArray(state),
    routerPathParams: state.core.router,
    project: selectActiveProject(state),
});

const mapDispatchToProps = (dispatch, ownProps) => ({});

export const ExportForm = connect(mapStateToProps, mapDispatchToProps)(ExportFormComponent);
