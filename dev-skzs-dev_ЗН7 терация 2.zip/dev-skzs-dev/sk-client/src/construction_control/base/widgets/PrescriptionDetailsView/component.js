import React from "react";

import { PrescriptionDetailsViewPrescription } from "../PrescriptionDetailsViewPrescription/component";
import { PrescriptionDetailsViewRemark } from "../PrescriptionDetailsViewRemark/component";
import { PrescriptionDetailsViewAct } from "../PrescriptionDetailsViewAct/component";

import "./styles.scss";

export const PrescriptionDetailsViewComponent = (props) => {
    const { document } = props;

    const view = {
        prescription: <PrescriptionDetailsViewPrescription document={document} />,
        remark: <PrescriptionDetailsViewRemark document={document} />,
        act: <PrescriptionDetailsViewAct document={document} />,
    }[document.type];

    return (
        <div className="prescription-details-view">
            {view}
        </div>
    );
};
