import { DOCUMENT_STATUS_TRANSITIONS } from "../constants/statuses";
import { statusEditMap } from "../../../users/constants/roles";
import { loggedInUser } from "../../../users/selectors/permissions";

export const getStatusTransitions = (state, document) => {
    const config = DOCUMENT_STATUS_TRANSITIONS[document.type][document.status];
    if (!config) return [document.status];

    const transitions = (config.transitions instanceof Function)
        ? config.transitions(document)
        : config.transitions;

    return [
        ...transitions.filter(
            (it) => statusEditMap[document.type][loggedInUser(state).role].includes(it),
        ),
        document.status,
    ];
};
