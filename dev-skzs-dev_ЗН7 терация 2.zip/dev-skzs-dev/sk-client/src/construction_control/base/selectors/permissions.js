import { DOCUMENT_STATUS_TRANSITIONS } from "../constants/statuses";
import { loggedInUser } from "../../../users/selectors/permissions";
import {
    calendarFactEditMap,
    calendarPlanEditMap,
    commentAddMap,
    commentDeleteMap, companiesEditMap, createAosrMap,
    documentCreationMap,
    documentDeleteMap,
    documentEditMap,
    fileAttachMap, fileDeleteMap,
    geotagAddMap, geotagDeleteMap, treeStructureEditMap, USER_ROLES, workActivityCreateMap, workActivityEditMap,
} from "../../../users/constants/roles";
import { DOCUMENT_TYPES } from "../../../documents/constants/types";

export const canCreateActForPrescription = (state, document) => {
    const config = DOCUMENT_STATUS_TRANSITIONS[document.type][document.status];
    if (!config) return false;
    return (
        (config.canCreateAct instanceof Function) ? config.canCreateAct(document) : config.canCreateAct
        && canCreateDocument(state, DOCUMENT_TYPES.ACT)
    );
};

export const isOwnComment = (state, comment) => {
    const user = loggedInUser(state);
    return (comment.user.sid === user.user.sid);
};

export const canEditComment = (state, comment) => {
    const creationDate = new Date(comment.creation_date);
    const now = new Date();
    if ((now - creationDate) < 3 * 60 * 1000) {
        const { role } = loggedInUser(state);
        return isOwnComment(state, comment) || (USER_ROLES.ADMIN === role);
    }
    return false;
};

export const canCreateDocument = (state, type) => documentCreationMap[loggedInUser(state).role].includes(type);

export const canEditDocument = (state, documentType) => documentEditMap[loggedInUser(state).role].includes(documentType);

export const canDeleteDocument = (state, documentType) => documentDeleteMap[loggedInUser(state).role].includes(documentType);

export const canAddCommentPredicate = (state) => commentAddMap[loggedInUser(state).role];

export const canDeleteCommentPredicate = (state, comment) => commentDeleteMap[loggedInUser(state).role] || isOwnComment(state, comment);

export const canAttachFilePredicate = (state) => fileAttachMap[loggedInUser(state).role];

export const canDeleteFilePredicate = (state) => fileDeleteMap[loggedInUser(state).role];

export const canAddGeotagPredicate = (state, documentType) => geotagAddMap[loggedInUser(state).role].includes(documentType);

export const canDeleteGeotagPredicate = (state) => geotagDeleteMap[loggedInUser(state).role];

export const canEditTreeStructurePredicate = (state) => treeStructureEditMap[loggedInUser(state).role];

export const canEditCompanyPredicate = (state) => companiesEditMap[loggedInUser(state).role];

export const canCreateWorkActivityPredicate = (state) => workActivityCreateMap[loggedInUser(state).role];

export const canEditWorkActivityPredicate = (state) => workActivityEditMap[loggedInUser(state).role];

export const canEditCalendarPlanPredicate = (state) => calendarPlanEditMap[loggedInUser(state).role];

export const canEditCalendarFactPredicate = (state) => calendarFactEditMap[loggedInUser(state).role];

export const canCreateAOSRPredicate = (state) => createAosrMap[loggedInUser(state).role];
