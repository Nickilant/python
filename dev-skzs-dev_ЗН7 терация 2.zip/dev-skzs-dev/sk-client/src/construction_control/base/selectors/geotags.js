export const getGeotags = (state) => {
    const { selectedKey } = state.documents.crud;
    const selectedDocument = state.documents.crud.items[selectedKey];
    if (selectedDocument) {
        return selectedDocument.markers;
    }
    return [];
};
