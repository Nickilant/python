import { filterBy, searchBy, sortBy } from "../../../shared/helpers/filterHelpers";

const DICT = {
    А: "A",
    В: "B",
    С: "C",
    Е: "E",
    Н: "H",
    К: "K",
    М: "M",
    О: "O",
    Р: "P",
    Т: "T",
    Х: "X",
    У: "Y",
};

export const mappingCharsRuToEng = (str) => str.split("").map((sym) => {
    const result = DICT[sym.toUpperCase()];
    return result || sym;
}).join("");

export const search = (array, query, attributes, showAll, type = "type") => {
    if (query === "") {
        return array;
    }
    const searchResultByQuery = array.filter((item) => {
        const searchStr = mappingCharsRuToEng(query);
        const searchItem = mappingCharsRuToEng(item.title);
        return 1 + searchItem.indexOf(searchStr);
    });

    if (!showAll) {
        const selectedAttributes = attributes.filter((item) => item.value).map((item) => item[type]);
        return searchResultByQuery.filter(
            (item) => selectedAttributes.includes(item[type]),
        );
    }

    return searchResultByQuery;
};

export const filterByStatus = (documents, state) => filterBy(documents, state.constructionControl.documentFilters.statusFilters, "status");

export const filterByType = (documents, state) => filterBy(documents, state.constructionControl.documentFilters.typeFilters, "type");

export const sort = (documents, state) => {
    const params = state.constructionControl.documentFilters.attribute;
    const dict = {
        new: 1,
        expired: 2,
        resolved: 3,
        checked: 4,
        rescheduled: 5,
    };

    return sortBy(documents, params, dict);
};

export const documentSearch = (documents, state) => searchBy(documents, state.constructionControl.documentFilters.searchQuery, "title");
