import { managementFormReducerFactory } from "../../../shared/reducers/formFactory";

const initialState = {
    type: "remark",
    formValidated: false,
    data: {
        note_number: "",
        issued_to: "",
        presence: "",
        note_desc: "",
        suggested_solution: "",
        note_issue_time: new Date(),
        document_code: "",
    },
};

export const remarkDetailsReducer = managementFormReducerFactory(initialState, initialState.type, "CONSTRUCTION_CONTROL");
