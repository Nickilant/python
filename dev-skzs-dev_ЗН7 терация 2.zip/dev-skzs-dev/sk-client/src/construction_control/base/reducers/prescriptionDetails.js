import { managementFormReducerFactory } from "../../../shared/reducers/formFactory";

const initialState = {
    type: "prescription",
    formValidated: false,
    data: {
        prescription_number: "",
        priority: "elimination", // TODO: enum
        issued_to: "",
        issued_with_role: "",
        issued_organization: "",
        result: "survey",
        document: "",
        document_code: "",
    },
};

export const prescriptionDetailsReducer = managementFormReducerFactory(initialState, initialState.type, "CONSTRUCTION_CONTROL");
