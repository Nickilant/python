import geoListReducer from "./geoList";
import { testTypes } from "../../../../shared/constants/testTypes";
import { MODULE_TYPES } from "../../../../shared/constants/moduleTypes";

describe(`${MODULE_TYPES.constructionControl} | ${testTypes.reducer} ---> geoListReducer`, () => {
    it("CASE 1: geotag selected", () => {
        let state = { selectedGeotag: null };
        const geotag = {
            id: 0,
            type: "geotag",
            name: "Геометка 1",
            desc: "Описание",
            favorite: true,
            local: false,
        };

        state = geoListReducer(state, {
            type: "SELECT_GEOTAG",
            payload: { geotag },
        });

        expect(state).toEqual({
            selectedGeotag: {
                id: 0,
                type: "geotag",
                name: "Геометка 1",
                desc: "Описание",
                favorite: true,
                local: false,
            },
        });
    });
});
