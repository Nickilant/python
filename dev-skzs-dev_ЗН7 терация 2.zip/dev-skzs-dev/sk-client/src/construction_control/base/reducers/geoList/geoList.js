// import { ADD_GEOTAG } from "../actions/geoList/actionTypes";

import { SELECT_GEOTAG } from "../../actions/geoList/actionTypes";

const initialState = {
    selectedGeotag: null,
};

export default (state = initialState, action) => {
    switch (action.type) {
        case SELECT_GEOTAG: {
            return {
                ...state,
                selectedGeotag: action.payload.geotag,
            };
        }
        default:
            return state;
    }
};
