import { combineReducers } from "redux";
import geoListReducer from "./geoList/geoList";
import { actDetailsReducer } from "./actDetails";
import { remarkDetailsReducer } from "./remarkDetails";
import { prescriptionDetailsReducer } from "./prescriptionDetails";
import { universalDetailsFormReducer } from "./universalDetailsForm";
import { documentFiltersReducer } from "./documentFilters";
import mapsReducer from "../../extra_2d/reducers/combined";

export default combineReducers({
    geotags: geoListReducer,
    extra2d: mapsReducer,
    actDetails: actDetailsReducer,
    remarkDetails: remarkDetailsReducer,
    prescriptionDetails: prescriptionDetailsReducer,
    universalDetailsForm: universalDetailsFormReducer,
    documentFilters: documentFiltersReducer,
});
