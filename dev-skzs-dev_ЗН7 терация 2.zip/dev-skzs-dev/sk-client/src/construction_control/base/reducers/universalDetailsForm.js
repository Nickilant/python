import { managementFormReducerFactory } from "../../../shared/reducers/formFactory";

const initialState = {
    type: "base",
    data: {
        location: "test location",
        code: "",
        date: new Date(),
        type: "prescription",
    },
};

export const universalDetailsFormReducer = managementFormReducerFactory(initialState, initialState.type, "CONSTRUCTION_CONTROL");
