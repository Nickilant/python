import { DOCUMENT_FILTER_SET } from "../actions/documentFilters/actionTypes";

const initialState = {
    statusFilters: [],
    searchQuery: "",
    typeFilters: [],
    attribute: {},
};

export const documentFiltersReducer = (state = initialState, action) => {
    switch (action.type) {
        case DOCUMENT_FILTER_SET: {
            return {
                ...state,
                ...action.payload,
            };
        }
        default:
            return state;
    }
};
