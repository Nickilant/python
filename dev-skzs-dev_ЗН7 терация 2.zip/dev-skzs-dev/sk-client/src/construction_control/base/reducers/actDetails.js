import { managementFormReducerFactory } from "../../../shared/reducers/formFactory";

const initialState = {
    type: "act",
    formValidated: false,
    data: {
        as_prescribed: "",
        act_number: "",
        act_date: new Date(),
        act_issued_by: "",
        by_order: "",
        event_description: "",
    },
};

export const actDetailsReducer = managementFormReducerFactory(initialState, initialState.type, "CONSTRUCTION_CONTROL");
