/* eslint import/prefer-default-export:0 */
export const SELECT_GEOTAG = "SELECT_GEOTAG";
