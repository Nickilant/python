import { SELECT_GEOTAG } from "./actionTypes";

/* eslint import/prefer-default-export:0 */
export const selectGeotagAction = (geotag) => ({
    type: SELECT_GEOTAG,
    payload: {
        geotag,
    },
});
