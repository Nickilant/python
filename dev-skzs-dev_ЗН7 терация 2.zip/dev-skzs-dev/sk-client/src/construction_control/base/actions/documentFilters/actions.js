import { DOCUMENT_FILTER_SET } from "./actionTypes";

export const setFilterAction = (payload) => ({
    type: DOCUMENT_FILTER_SET,
    payload,
});
