import { CONSTRUCTION_CONTROL_CHANGE_INPUT_DETAILS_FORM } from "./actionTypes";

export const changeInputAction = (newInput) => ({
    type: CONSTRUCTION_CONTROL_CHANGE_INPUT_DETAILS_FORM,
    payload: newInput,
});
