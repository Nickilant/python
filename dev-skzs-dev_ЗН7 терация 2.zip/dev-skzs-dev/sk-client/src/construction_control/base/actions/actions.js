import {
    DOCUMENT_LIST_ORDER_BY,
    DOCUMENT_LIST_SEARCH,
    DOCUMENT_LIST_SELECT_DOCUMENT,
    DOCUMENT_LIST_TOGGLE_ALL,
    DOCUMENT_LIST_TOGGLE_ATTRIBUTE,
    DOCUMENT_TO_MAP_TRANSITION,
} from "./actionTypes";

export const selectItem = (id) => ({
    type: DOCUMENT_LIST_SELECT_DOCUMENT,
    payload: {
        id,
    },
});

export const orderBy = (attribute, order) => ({
    type: DOCUMENT_LIST_ORDER_BY,
    payload: {
        attribute, order,
    },
});

export const searchDocuments = (query) => ({
    type: DOCUMENT_LIST_SEARCH,
    payload: {
        query,
    },
});

export const toggleAttribute = (type) => ({
    type: DOCUMENT_LIST_TOGGLE_ATTRIBUTE,
    payload: {
        type,
    },
});

export const toggleAll = () => ({
    type: DOCUMENT_LIST_TOGGLE_ALL,
});

export const triggerDocumentToMapTransition = (documentTitle) => ({
    type: DOCUMENT_TO_MAP_TRANSITION,
    payload: {
        documentTitle,
    },
});
