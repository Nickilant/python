import { DOCUMENT_TYPES } from "../../../../documents/constants/types";

export const types = [
    {
        name: DOCUMENT_TYPES.PRESCRIPTION,
        active: false,
        label: "Предписания",
    },
    // {
    //     name: DOCUMENT_TYPES.REMARK,
    //     active: false,
    //     label: "Замечания",
    // },
    {
        name: DOCUMENT_TYPES.ACT,
        active: false,
        label: "Акты",
    },
];
