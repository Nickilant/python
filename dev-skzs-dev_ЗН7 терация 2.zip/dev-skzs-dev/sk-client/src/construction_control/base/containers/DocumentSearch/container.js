import React from "react";
import { connect, useSelector } from "react-redux";

import { UniversalTypeFilters } from "../../../../executive_documentation/widgets/UniversalTypeFilters/component";
import { Search } from "../../../../shared/components/Search/component";
import { setFilterAction } from "../../actions/documentFilters/actions";
import { types } from "./documentTypes";

import "./styles.scss";

const DocumentSearch = (props) => {
    const {
        setFilter,
    } = props;

    const handleSearch = (value) => {
        setFilter({ searchQuery: value });
    };

    const searchValue = useSelector((state) => state.constructionControl.documentFilters.searchQuery);

    return (
        <div className="document-search">
            <div className="search-bar">
                <Search
                    defaultValue={searchValue}
                    placeholder="Поиск по названию"
                    onSearch={handleSearch}
                    allowClear
                />
            </div>

            <UniversalTypeFilters
                types={types}
                setActionReducer={setFilter}
            />
        </div>
    );
};

export default connect(() => ({}), {
    setFilter: setFilterAction,
})(DocumentSearch);
