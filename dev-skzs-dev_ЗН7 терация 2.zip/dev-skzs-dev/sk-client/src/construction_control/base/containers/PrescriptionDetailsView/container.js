import React from "react";
import { connect } from "react-redux";

import { PrescriptionDetailsViewComponent } from "../../widgets/PrescriptionDetailsView/component";
import { selectedDocumentView } from "../../../../documents/selectors/documents";

import "./styles.scss";

export const PrescriptionDetailsViewContainer = (props) => {
    const { selectedDocument } = props;

    return (
        <PrescriptionDetailsViewComponent
            document={selectedDocument}
        />
    );
};

const mapStateToProps = (state) => {
    const selectedDocument = selectedDocumentView(state);

    return {
        selectedDocument,
    };
};

export const PrescriptionDetailsView = connect(mapStateToProps)(PrescriptionDetailsViewContainer);
