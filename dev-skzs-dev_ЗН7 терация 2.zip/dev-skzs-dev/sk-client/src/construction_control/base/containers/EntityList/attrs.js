export const attrs = [
    {
        name: "status",
        label: "",
        active: false,
        order: "asc",
    },
    {
        name: "title",
        label: "Имя",
        active: false,
        order: "asc",
    },
    {
        name: "number",
        label: "Номер",
        active: false,
        order: "asc",
    },
    {
        name: "date",
        label: "Дата",
        active: false,
        order: "asc",
    },
    {
        name: "issued_to_full",
        label: "Подрядчик",
        active: false,
        order: "asc",
    },
    {
        name: "deadline",
        label: "Срок",
        active: false,
        order: "asc",
    },
];
