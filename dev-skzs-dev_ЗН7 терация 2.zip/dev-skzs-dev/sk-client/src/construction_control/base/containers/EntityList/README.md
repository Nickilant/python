## Example data

```
{
    "documents": [
        {
            "title":              "Предписание 20/72/О от 09.07.2019",
            "icon":               "",
            "description":        "Истёк срок действия удостоверения-допуска персонала пригады",
            "status":             "checked",
            "date":               1562619600000,
            "deadline":           0,
            "dateOfCompletion":   1563321600,
            "geotagsCount":       0,
            "commentsCount":      3,
            "filesCount":         2,
            "isFavorite":         false,
            "isDownloaded":       true,
            "selected":           false
        },
        {
            "title":              "Акт о устранении 20/73/А от 17.07.2019",
            "icon":               "",
            "description":        "На предписание 20/72/О от 09.07.2019. Допуски оформлены",
            "status":             "",
            "date":               1563321600,
            "deadline":           0,
            "dateOfCompletion":   0,
            "geotagsCount":       0,
            "commentsCount":      0,
            "filesCount":         0,
            "isFavorite":         true,
            "isDownloaded":       false,
            "selected":           false
        },
        {
            "title":              "Предписание 64/127/У от 10.07.2019",
            "icon":               "",
            "description":        "Не производится полный контроль материалов при производстве СМР",
            "status":             "default",
            "date":               1562706000000,
            "deadline":           1563051600000,
            "dateOfCompletion":   0,
            "geotagsCount":       1,
            "commentsCount":      4,
            "filesCount":         0,
            "isFavorite":         false,
            "isDownloaded":       false,
            "selected":           false
        },
        {
            "title":              "Предписание 53/122/У от 11.07.2019",
            "icon":               "",
            "description":        "1. Электроинструмент (УШМ) не отключается от сети при переходе рабочего на другой вид работ.
2. Эксплуатация удлинителей без бирок с инвентарными номерами и датой испытаний.",
            "status":             "default",
            "date":               1562792400000,
            "deadline":           1563138000000,
            "dateOfCompletion":   0,
            "geotagsCount":       3,
            "commentsCount":      2,
            "filesCount":         2,
            "isFavorite":         false,
            "isDownloaded":       true,
            "selected":           false
        },
        {
            "title":              "Предписание 34/122/О от 13.07.2019",
            "icon":               "",
            "description":        "Не предоставлен проект производства работ.",
            "status":             "notChecked",
            "date":               1562965200000,
            "deadline":           1563829200000,
            "dateOfCompletion":   0,
            "geotagsCount":       0,
            "commentsCount":      6,
            "filesCount":         8,
            "isFavorite":         true,
            "isDownloaded":       true,
            "selected":           false
        },
        {
            "title":              "Предписание 12/123/О от 13.07.2019",
            "icon":               "",
            "description":        "СМР проводит неутвержденная заказчиком организация ООО 'Шараш-монтаж'",
            "status":             "postponed",
            "date":               1562965200000,
            "deadline":           1567112400000,
            "dateOfCompletion":   0,
            "geotagsCount":       0,
            "commentsCount":      2,
            "filesCount":         0,
            "isFavorite":         true,
            "isDownloaded":       true,
            "selected":           false
        },
        {
            "title":              "Предписание 23/113/У от 14.07.2019",
            "icon":               "",
            "description":        "1. При перерывах в работе строительный инструмент не отключается от сети электропитания.
2. При производстве газопламенных работ не выдерживается расстояние между баллонами и местом проведения работ - менее 10 м.
3. Не утилизируются неисправные текстильные стропы (разрыв ленты)",
            "status":             "checked",
            "date":               0,
            "deadline":           0,
            "dateOfCompletion":   1563483600000,
            "geotagsCount":       3,
            "commentsCount":      2,
            "filesCount":         12,
            "isFavorite":         false,
            "isDownloaded":       true,
            "selected":           false
        }

    ]
}
```
