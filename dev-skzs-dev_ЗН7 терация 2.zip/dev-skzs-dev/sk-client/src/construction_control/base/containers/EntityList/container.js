import React, { useEffect } from "react";
import { connect, useDispatch } from "react-redux";
import { push } from "connected-react-router";

import DocumentListItem from "../../components/DocumentsListItem/component";
import {
    documentSearch,
    filterByStatus, filterByType, sort,
} from "../../selectors/documents";
import "./styles.scss";
import { getAllChildren } from "../../../../categories/selectors/treeStructure";
import {
    filterByGroup,
    selectCurrentProjectDocuments,
    selectedDocumentView,
} from "../../../../documents/selectors/documents";
import { documentsCRUDActions } from "../../../../documents/actions/actions";
import { selectActiveProject } from "../../../../projects/selectors/projects";
import { commentsCRUDActions } from "../../../../comments/actions/actions";
import { getURL } from "../../../../shared/helpers/getPath";
import { PREVIEW_MODULES } from "../../widgets/DocumentPreviewColumn/previewModules";
import { UniversalAttrFilters } from "../../../../executive_documentation/widgets/UniversalAttrFilters/component";
import { setFilterAction } from "../../actions/documentFilters/actions";
import { attrs } from "./attrs";

const EntityList = (props) => {
    const {
        project,
        documents,
        selectItem,
        selectedItem,
        openDetails,
        documentsCount,
        loadComments,
        routerPathParams,
        setFilter,
    } = props;

    const dispatch = useDispatch();

    const handleSelectItem = (id) => {
        const path = getURL(routerPathParams, ["projects", "section", "group", ["document", id]]);
        dispatch(push(path));
    };

    const openDocument = (item) => {
        selectItem({ ...item, project });
        openDetails({ ...item, module: PREVIEW_MODULES.CONSTRUCTION_CONTROL });
        loadComments({ source: { project, entity: item } });
    };

    useEffect(() => {
        const documentId = routerPathParams.document;
        const item = documents.filter((it) => it.id === documentId)[0];

        if (item) {
            openDocument(item);
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [routerPathParams, documentsCount]);

    return (
        <div className="entity-list">
            <div className="head">
                <UniversalAttrFilters
                    attrs={attrs}
                    setActionReducer={setFilter}
                />
            </div>
            <div className="list">
                { documents.map((item) => (
                    <DocumentListItem
                        key={item.id}
                        document={item}
                        selected={selectedItem && (selectedItem.id === item.id)}
                        selectItem={handleSelectItem}
                    />
                ))}
            </div>
        </div>
    );
};

const mapStateToProps = (state) => {
    const documents = selectCurrentProjectDocuments(state);
    const selectedGroups = getAllChildren(state, "documents-list");
    const filteredByGroup = filterByGroup(documents, selectedGroups);
    const filteredByType = filterByType(filteredByGroup, state);
    const filteredByStatus = filterByStatus(filteredByType, state);
    const filteredBySearch = documentSearch(filteredByStatus, state);

    const documentsCount = filteredBySearch.length;

    return {
        documentsCount,
        project: selectActiveProject(state),
        selectedItem: selectedDocumentView(state),
        documents: sort(filteredBySearch, state),
        routerPathParams: state.core.router,
        documentsCRUDList: documents,
    };
};

export default connect(
    mapStateToProps,
    {
        selectItem: documentsCRUDActions.use.SELECT_SINGLE_ENTITY,
        openDetails: documentsCRUDActions.use.ENTITY_PREVIEW,
        loadComments: commentsCRUDActions.use.LIST_ENTITIES,
        setFilter: setFilterAction,
    },
)(EntityList);
