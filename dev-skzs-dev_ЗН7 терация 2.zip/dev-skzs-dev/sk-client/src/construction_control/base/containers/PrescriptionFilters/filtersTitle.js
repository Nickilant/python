export const filtersTitle = {
    ALL: "Всего предписаний и замечаний",
    PRESCRIPTION: "Всего предписаний",
    REMARK: "Всего замечаний",
    OTHERS: "Всего документов",
    DEFAULT: "Всего",
};
