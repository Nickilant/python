export const statuses = [
    {
        name: "new",
        active: false,
        count: 10,
    },
    {
        name: "expired",
        active: false,
        count: 10,
    },
    {
        name: "resolved",
        active: false,
        count: 10,
    },
    {
        name: "checked",
        active: false,
        count: 10,
    },
    {
        name: "rescheduled",
        active: false,
        count: 10,
    },
];
