import React from "react";
import { connect } from "react-redux";
import { statuses } from "./statuses";

import { UniversalStatusFilters } from "../../../../executive_documentation/widgets/UniversalStatusFilters/component";
import { setFilterAction } from "../../actions/documentFilters/actions";

import "./styles.scss";
import { filterByGroup, selectCurrentProjectDocuments } from "../../../../documents/selectors/documents";
import { getAllChildren } from "../../../../categories/selectors/treeStructure";
import { filterByType } from "../../selectors/documents";

export const infoContent = () => (
    <div className="ed-info-block">
        <div className="info-text-content">
            <div className="active">Голубым цветом</div>
            обозначены все документы
        </div>
        <div className="info-text-content">
            <div className="blue">Синим цветом</div>
            обозначены составленные документы
        </div>
        <div className="info-text-content">
            <div className="red">Красным цветом</div>
            обозначены просроченные документы
        </div>
        <div className="info-text-content">
            <div className="yellow">Желтым цветом</div>
            обозначены документы, которые выполнены, но еще не проверены (есть акт)
        </div>
        <div className="info-text-content">
            <div className="green">Зеленым цветом</div>
            обозначены документы, которые выполнены и полностью проверены
        </div>
        <div className="info-text-content">
            <div className="grey">Серым цветом</div>
            обозначены документы с перенесённым сроком
        </div>
        <div className="info-text-content">
            При нажатии на какую-либо из категорий, откроются все документы
            <div className="bold">из выбранной категории</div>
        </div>
    </div>
);

function PrescriptionFiltersContainer(props) {
    const {
        documents,
        setFilter,
    } = props;

    return (
        <UniversalStatusFilters
            title="Всего предписаний:"
            statuses={statuses}
            setActionReducer={setFilter}
            items={documents}
            infoContent={infoContent}
        />
    );
}

export const PrescriptionFilters = connect((state) => {
    const documents = selectCurrentProjectDocuments(state);
    const selectedGroups = getAllChildren(state, "documents-list");
    const filteredByGroup = filterByGroup(documents, selectedGroups);
    const filteredByType = filterByType(filteredByGroup, state);

    return {
        documents: filteredByType,
    };
}, {
    setFilter: setFilterAction,
})(PrescriptionFiltersContainer);
