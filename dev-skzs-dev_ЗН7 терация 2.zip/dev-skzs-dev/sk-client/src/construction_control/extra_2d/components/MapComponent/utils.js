import Feature from "ol/Feature";
import Point from "ol/geom/Point";
import VectorLayer from "ol/layer/Vector";
import VectorSource from "ol/source/Vector";
import { Icon, Style } from "ol/style";
import {
    featureIconBase,
    featureIconBorder,
    featureIconDocument,
    featureIconMapLink,
    iconBorderColors,
    iconStatusLetters,
    shadow,
} from "./svg_layers";

export const initLayers = (map, layers, visibleMarkers, selectedMarker, latestMovedMarker) => {
    // const newSids = layers.map(l => l.sid);
    // map.getLayers().getArray().filter(it => ! newSids.includes(it.get('ccmeta').sid)).forEach(it => map.removeLayer(it));

    map.getLayers().getArray().filter((it) => it.get("ccmeta")).forEach((it) => map.removeLayer(it));

    layers.forEach((layer) => {
        const markers = [];
        layer.geo_markers.forEach((marker) => {
            let source = visibleMarkers[marker.sid];

            if (source && source.source) {
                const svg = prepareFeatureIcon(source, selectedMarker && marker.sid === selectedMarker.sid);

                if (latestMovedMarker && latestMovedMarker.sid === source.sid) {
                    source = latestMovedMarker;
                }

                const mysvg = new Image();
                mysvg.src = `data:image/svg+xml,${escape(svg)}`;

                const iconStyle = new Style({
                    image: new Icon({
                        anchor: [0.5, 1],
                        anchorXUnits: "fraction",
                        anchorYUnits: "fraction",
                        opacity: 1,
                        scale: 1,
                        img: mysvg,
                        imgSize: [56, 74],
                    }),
                });

                const iconFeature = new Feature({
                    geometry: new Point([
                        source.coordinate_x,
                        source.coordinate_y,
                    ]),
                    name: marker.name,
                });
                iconFeature.setStyle(iconStyle);
                iconFeature.set("marker", marker);
                iconFeature.set("document", marker.document);
                iconFeature.set("source", marker.source);
                iconFeature.set("ccmeta", { sid: marker.sid });

                markers.push(iconFeature);
            }
        });

        const vectorLayer = new VectorLayer({
            source: new VectorSource({
                features: [...markers],
            }),
        });
        vectorLayer.set("ccmeta", { sid: layer.sid, name: layer.name });

        map.addLayer(vectorLayer);
    });
};

const prepareFeatureIcon = (featureSource, isSelected) => {
    const width = 56;
    const height = 74;
    const sep = "\n";
    const iconLayers = [];

    // Opening svg tag
    iconLayers.push(`<svg width="${width}" height="${height}" viewBox="-3 -3 ${width + 6} ${height + 6}" fill="none" xmlns="http://www.w3.org/2000/svg">${sep}`);

    // Generic body for the feature icon
    iconLayers.push(featureIconBase);

    // Adding border
    const borderLayer = featureIconBorder(iconBorderColors[featureSource.source.status]);
    iconLayers.push(borderLayer);

    // Adding core icon
    const coreIcon = featureSource.source.type !== "map" ? featureIconDocument : featureIconMapLink;
    iconLayers.push(coreIcon);

    // Adding status icon
    if (featureSource.source.criticality) {
        // const statusIcon = iconStatusLetters[featureSource.source.criticality];
        const statusIcon = iconStatusLetters.MAJOR;
        iconLayers.push(statusIcon);
    }

    if (isSelected) iconLayers.push(shadow);

    // And lastly we're closing svg tag
    iconLayers.push(`</svg>${sep}`);

    return iconLayers.join(sep);
};
