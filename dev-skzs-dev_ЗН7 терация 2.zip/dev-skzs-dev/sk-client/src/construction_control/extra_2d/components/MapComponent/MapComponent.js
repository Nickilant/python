import React, { useEffect, useState } from "react";
import Projection from "ol/proj/Projection";
import { getCenter, getTopLeft } from "ol/extent";
import { defaults as defaultInteractions } from "ol/interaction";
import TileGrid from "ol/tilegrid/TileGrid";
import XYZ from "ol/source/XYZ";
import TileLayer from "ol/layer/Tile";
import View from "ol/View";
import Map from "ol/Map";
import cx from "classnames";
import { useDispatch, useSelector } from "react-redux";
import { push } from "connected-react-router";
import { Button, Modal, Popover } from "antd";
import { GeotagPopup } from "../GeotagPopup/GeotagPopup";
import { initLayers } from "./utils";
import { WIDGET_TYPES } from "../../../../shared/constants/widgetTypes";
import { selectGeotagAction } from "../../../base/actions/geoList/actions";
import { selectedGeotag } from "../../selectors/maps";
import { selectLayerAction } from "../../actions/actions";
import { PREVIEW_MODULES } from "../../../base/widgets/DocumentPreviewColumn/previewModules";
import { closeRightColumnContainerAction } from "../../../../shared/actions/RightColumnContainer/actions";

export const MapComponent = (props) => {
    const {
        map,
        filteredGeoMarkers,
        project,
        openRightColumn,
        selectDocument,
        openDocumentDetails,
        layer,
        markerAdd,
        handleCreateMarker,
        // handleUpdateMarker, SM-471
        handleDeleteMarker,
    } = props;

    const resolutions = map.metadata.tile_sets.map((it) => it.units_per_pixel);
    const baseExtentEdge = resolutions[0] * map.metadata.tile_format.width;

    const baseExtent = [0, 0, baseExtentEdge, baseExtentEdge];

    const imageExtent = [0, 0, map.metadata.bounding_box.maxx, Math.abs(map.metadata.bounding_box.miny)];

    const [mapZoom, setMapZoom] = useState(0);
    const [mapCenter, setMapCenter] = useState(getCenter(baseExtent));
    const [olMap, setOlMap] = useState(null);
    const initMarkerDeleting = { modalOpen: false };
    const [markerDeleting, setMarkerDeleting] = useState(initMarkerDeleting);

    const initTopLeft = { top: 0, left: 0 };
    const [topLeft, setTopLeft] = useState(initTopLeft);
    const [featureSource, setFeatureSource] = useState(null);
    // SM-471
    // const [isDraggable, setDraggable] = useState(false);
    // const [latestMovedMarker, setLatestMovedMarker] = useState(false);

    const selectedMarker = useSelector(selectedGeotag);

    const dispatch = useDispatch();

    // componentDidMount
    useEffect(() => {
        let draggable;
        let geometryClone;
        let startingPoint;
        // let moved = false; SM-471
        let draggingTimeout;

        const projection = new Projection({
            code: map.metadata.srs,
            units: "pixels",
            // extent: baseExtent
        });

        const tileGrid = new TileGrid({
            extent: baseExtent,
            resolutions,
            origin: getTopLeft(baseExtent),
        });

        const tileSource = new XYZ({
            url: `${`${window.location.protocol}//${process.env.NODE_ENV === "production" ? window.location.hostname : process.env.REACT_APP_HOST}`}${props.map.tiles_link}/{z}/{x}/{-y}.png`, // HERE WE NEED TO PROVIDE PROPER LINK FOR HOSTING
            projection,
            tileGrid,
        });
        const rasterLayer = new TileLayer({
            source: tileSource,
        });

        const view = new View({
            center: getCenter(imageExtent),
            // extent: imageExtent,
            projection,
            resolutions: tileGrid.getResolutions(),
            // minZoom: 0, // TODO zoom levels potentially might differ from image to image, need to double check
            // maxZoom: 6,
        });

        const olmap = new Map({
            interactions: defaultInteractions({ altShiftDragRotate: false, pinchRotate: false }),
            target: null,
            layers: [rasterLayer],
            view,
        });

        initLayers(olmap, [layer], filteredGeoMarkers, selectedMarker);

        const selectedGeoTag = layer.geo_markers.find((it) => it.sid === (selectedMarker && selectedMarker.sid));

        if (selectedGeoTag) {
            openRightColumn(WIDGET_TYPES.DOCUMENT_PREVIEW, { module: PREVIEW_MODULES.CONSTRUCTION_CONTROL });
            openDocumentDetails(selectedGeoTag.source);
        }

        // Listeners
        olmap.on("moveend", () => {
            const center = olmap.getView().getCenter();
            const zoom = olmap.getView().getZoom();
            setMapZoom(zoom);
            setMapCenter(center);
        });

        // This one is gonna live here because useState won't work
        let hoveredFeatureId;
        olmap.on("pointermove", (event) => {
            if (startingPoint) {
                const pixel = olmap.getEventPixel(event.originalEvent);
                const coordinate = olmap.getCoordinateFromPixel(pixel);
                const diffx = coordinate[0] - startingPoint[0];
                const diffy = coordinate[1] - startingPoint[1];
                if (diffy > 50 || diffx > 50) clearTimeout(draggingTimeout);

                if (draggable) {
                    const gClone = geometryClone.clone();
                    gClone.translate(diffx, diffy);
                    draggable.setGeometry(gClone);
                    // moved = true; SM-471
                    return;
                }
            }

            const feature = olmap.forEachFeatureAtPixel(event.pixel, (feature) => feature);

            if (feature) {
                if (hoveredFeatureId !== feature.ol_uid) {
                    hoveredFeatureId = feature.ol_uid;
                    const coord = feature.getGeometry().getCoordinates();
                    const p = olmap.getPixelFromCoordinate(coord);
                    setTopLeft({ top: p[1], left: p[0] + 3 });
                    setFeatureSource(feature.values_.source);
                    setTimeout(() => {
                        const popup = document.getElementById("popup");
                        if (popup) popup.click();
                    }, 50);
                }
            } else {
                setTopLeft(initTopLeft);
                setFeatureSource(null);
                hoveredFeatureId = null;
            }
        });

        setInterval(() => olmap.updateSize(), 300);

        // SM-471 Disable d'n'd for geo markers.
        // olmap.on('pointerdown', (event) => {
        //     let feature = olmap.forEachFeatureAtPixel(event.pixel, (feature) => {
        //         return feature;
        //     });
        //
        //     if (feature) {
        //         // save current pixel, set feature as draggable
        //         let pixel = olmap.getEventPixel(event.originalEvent);
        //         startingPoint = olmap.getCoordinateFromPixel(pixel);
        //         geometryClone = feature.getGeometry().clone();
        //         draggingTimeout = setTimeout(() => {
        //             draggable = feature;
        //             setLatestMovedMarker(draggable.values_.marker);
        //         }, 100);
        //         moved = false;
        //         event.stopPropagation();
        //         return false;
        //     }
        // });
        //
        // olmap.on('pointerup', (event) => {
        //     if (draggable) {
        //         const [x, y] = draggable.getGeometry().getCoordinates();
        //         if (moved) {
        //             draggable.values_.marker.coordinate_x = x;
        //             draggable.values_.marker.coordinate_y = y;
        //
        //             handleUpdateMarker(draggable.values_.marker, {
        //                 coordinate_x: x,
        //                 coordinate_y: y
        //             });
        //         }
        //         startingPoint = null;
        //         draggable = null;
        //         setDraggable(false);
        //     }
        // });

        olmap.on("click", (event) => {
            const feature = olmap.forEachFeatureAtPixel(event.pixel, (feature) => feature);
            if (feature) {
                const { marker } = feature.values_;
                const attachedEntity = feature.values_.source;
                if (attachedEntity.type === "map") {
                    dispatch(push(`/projects/${project.key}/section/geodata/group/${attachedEntity.group}`));
                } else {
                    // better solution to reset right column context might be needed
                    dispatch(closeRightColumnContainerAction());
                    //
                    selectDocument({ ...attachedEntity, project });
                    dispatch(selectLayerAction(marker.layer));
                    dispatch(selectGeotagAction(marker));
                    openRightColumn(WIDGET_TYPES.DOCUMENT_PREVIEW, { module: PREVIEW_MODULES.CONSTRUCTION_CONTROL });
                    openDocumentDetails(attachedEntity);
                }
            }
        });

        olmap.on("contextmenu", (event) => {
            event.preventDefault();
            const feature = olmap.forEachFeatureAtPixel(event.pixel, (feature) => feature);
            if (feature) {
                const markerSid = feature.values_.ccmeta.sid;
                openMarkerDeleteModal(markerSid);
            }

            return false; // Needed to prevent default context menu
        });

        const handleCreateFeatureClick = (event) => {
            if (markerAdd) {
                const resizeInterval = setInterval(() => olmap.updateSize(), 500);
                setTimeout(() => clearInterval(resizeInterval), 1000);

                if (!event.target.closest("#map")) {
                    event.stopPropagation();
                    handleCreateMarker(null);
                } else if (olmap) {
                    const pixel = olmap.getEventPixel(event);
                    const coordinate = olmap.getCoordinateFromPixel(pixel);
                    const x = coordinate[0];
                    const y = coordinate[1];
                    if (
                        (x > 0) && (x < map.metadata.bounding_box.maxx)
                            && (y > 0) && (y < Math.abs(map.metadata.bounding_box.miny))
                    ) {
                        handleCreateMarker(coordinate);
                    } else {
                        event.stopPropagation();
                        handleCreateMarker(null);
                        alert("Координаты метки вне допустимой площади!");
                    }
                }
            }
            return true;
        };

        olmap.setTarget("map");
        olmap.getView().setZoom(mapZoom);
        if (selectedMarker) {
            olmap.getView().animate({ center: [selectedMarker.coordinate_x, selectedMarker.coordinate_y] });
            olmap.getView().setZoom(5);
        } else {
            olmap.getView().setCenter(mapCenter);
        }
        olmap.getView().fit(imageExtent);

        olmap.setView(
            new View({
                center: olmap.getView().getCenter(),
                extent: olmap.getView().calculateExtent(olmap.getSize()),
                projection,
                resolutions: tileGrid.getResolutions(),
                zoom: 1,
            }),
        );

        setOlMap(olmap);

        document.addEventListener("click", handleCreateFeatureClick);

        return () => {
            if (olmap) {
                document.removeEventListener("click", handleCreateFeatureClick);
                olmap.setTarget(null);
            }
        };
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [markerAdd]);

    useEffect(() => {
        // if (olMap && map && !isDraggable) SM-471
        if (olMap && map) {
            initLayers(olMap, [layer], filteredGeoMarkers, selectedMarker, null);
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [map, layer, filteredGeoMarkers, selectedMarker]);

    const openMarkerDeleteModal = (sid) => {
        setMarkerDeleting({ modalOpen: true, sid });
    };

    const deleteMarkerOk = (sid) => {
        handleDeleteMarker(sid);
        closeMarkerDeleteModal();
    };

    const closeMarkerDeleteModal = () => {
        setMarkerDeleting(initMarkerDeleting);
    };

    return (
        <>
            <div id="map" className={cx("map", { focused: markerAdd })} />
            <Modal
                title="Удаление геометки"
                visible={markerDeleting.modalOpen}
                onOk={() => deleteMarkerOk(markerDeleting.sid)}
                onCancel={closeMarkerDeleteModal}
                footer={[
                    <Button key="back" onClick={closeMarkerDeleteModal}>
                        ОТМЕНА
                    </Button>,
                    <Button
                        key="submit"
                        type="danger"
                        onClick={() => deleteMarkerOk(markerDeleting.sid)}
                    >
                        ОК
                    </Button>,
                ]}
            >
                <div>
                    Вы точно хотите
                    <b>удалить</b>
                    {" "}
                    геометку?
                </div>
            </Modal>
            <div className="map-title">
                {map && map.name}
            </div>
            {
                featureSource
                && (
                    <Popover content={<GeotagPopup source={featureSource} />} trigger="click">
                        <div
                            id="popup"
                            style={{ ...topLeft }}
                        />
                    </Popover>
                )
            }
        </>
    );
};
