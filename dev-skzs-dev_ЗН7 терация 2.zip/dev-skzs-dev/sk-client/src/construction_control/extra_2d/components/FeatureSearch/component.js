import React from "react";
import cx from "classnames";
import { connect } from "react-redux";
import { Input } from "antd";
import LayersControlsComponent from "../LayersControls/component";
import "./styles.scss";

// import {
//     searchDocumentsAction,
//     toggleAllAction,
//     toggleAttributeAction,
// } from "../../actions/documentList/actions";

const { Search } = Input;

const FeatureSearch = (props) => {
    const {
        // attributes,
        searchDocuments,
        // toggleAttribute,
        showAll,
        toggleAll,
    } = props;
    // const handleToggleAttribute = (type) => () => {
    //     toggleAttribute(type);
    // };

    return (
        <div className="feature-search">
            <div className="search-bar">
                <Search allowClear placeholder="Поиск по названию" onChange={(e) => searchDocuments(e.target.value)} />
            </div>

            <div className="attributes">
                <button
                    onClick={toggleAll}
                    className={cx("attribute", "toggle-all-button", { active: showAll })}
                >
                    Все
                </button>
                {/* { */}
                {/*    attributes.map((item) => ( */}
                {/*        <button */}
                {/*            onClick={handleToggleAttribute(item.type)} */}
                {/*            className={cx("attribute", { active: item.value })} */}
                {/*            key={item.type} */}
                {/*        > */}
                {/*            {item.title} */}
                {/*        </button> */}
                {/*    )) */}
                {/* } */}
                {/* <LayersControlsComponent /> */}
            </div>
        </div>
    );
};

const mapStateToProps = (state) => ({
    // ...state.constructionControl.featuresList,
});

export default connect(mapStateToProps, {
    // searchDocuments: searchDocumentsAction,
    // toggleAttribute: toggleAttributeAction,
    // toggleAll: toggleAllAction,
})(FeatureSearch);
