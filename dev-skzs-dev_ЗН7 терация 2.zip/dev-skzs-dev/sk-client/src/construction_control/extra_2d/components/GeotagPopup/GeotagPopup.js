import moment from "moment";
import React from "react";
import "./style.scss";
import { iconBorderColors } from "../MapComponent/svg_layers";

export const GeotagPopup = (props) => {
    const { source } = props;
    let title;
    let expiresInDays;
    let description;
    let thumbnailUrl;

    if (source.type === "map") {
        title = source.name;
        thumbnailUrl = `${`${window.location.protocol}//${window.location.hostname}`}${source.tiles_link}/thumbnail.png`;
    } else {
        title = source.title;

        let deadline;
        if (source.type === "aosr") {
            deadline = source.work_end_date;
        } else {
            deadline = source.deadline;
        }

        if (typeof deadline === "object") {
            deadline = moment(deadline);
        }
        expiresInDays = deadline.diff(moment(), "days");
        description = source.description;
    }

    const statusColor = iconBorderColors[source.status];

    return (
        <div className="popup-container">
            {
                statusColor && <div className="popup-status-bar" style={{ background: statusColor }} />
            }
            <div className="popup-content">
                <div className="popup-title">{title || "Без имени"}</div>
                {
                    (expiresInDays && expiresInDays > 0)
                        ? (
                            <div className="popup-days-left">
                                Осталось
                                {expiresInDays}
                                {" "}
                                дней
                            </div>
                        ) : null
                }
                {
                    description && <div className="popup-description">{description}</div>
                }
                {
                    thumbnailUrl && <img className="popup-map-preview" src={thumbnailUrl} alt="Предпросмотр карты" />
                }
            </div>
        </div>
    );
};
