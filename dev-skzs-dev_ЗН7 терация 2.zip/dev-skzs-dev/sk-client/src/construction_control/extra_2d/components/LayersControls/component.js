import React, { Component } from "react";
import { connect } from "react-redux";
import {
    Button, Form, Input, Modal, Select,
} from "antd";
import iconAdd from "./assets/iconAdd.svg";
import iconEdit from "./assets/iconEdit.svg";
import iconDelete from "./assets/iconDelete.svg";
import "./style.scss";
import { selectCurrentProjectDocuments } from "../../../../documents/selectors/documents";
import { selectActiveProject } from "../../../../projects/selectors/projects";
import { currentCategory } from "../../../../categories/selectors/treeStructure";
import { layersCRUDActions, selectLayerAction } from "../../actions/actions";
import { selectedLayer } from "../../selectors/maps";

const { Option } = Select;

class LayersControls extends Component {
    constructor(props) {
        super(props);

        this.state = {
            creatingLayer: false,
            editingLayer: false,
            deletingLayer: false,
            deleteButtonAvailable: true,
            modalInputValue: "",
            status: undefined,
            errorMessage: undefined,
        };
    }

    handleInputChange = (event) => {
        this.setState({
            modalInputValue: event.target.value,
            status: undefined,
            errorMessage: undefined,
        });
    };

    onChangeLayers = (value) => {
        this.props.onLayerSelected(value);
    };

    handleOpenCreateModal = () => {
        this.setState({ creatingLayer: true });
    };

    handleOpenEditModal = () => {
        this.setState({ editingLayer: true, modalInputValue: this.props.selectedLayer.name });
    };

    handleOpenDeleteModal = () => {
        this.setState({ deleteButtonAvailable: false, deletingLayer: true });
        setTimeout(() => {
            this.setState({ deleteButtonAvailable: true });
        }, 3000);
    };

    handleCloseModals = () => {
        this.setState({
            creatingLayer: false,
            editingLayer: false,
            deletingLayer: false,
            modalInputValue: "",
        });
    };

    handleCreateLayer = () => {
        const {
            project, category, map, createLayer,
        } = this.props;
        if (this.state.modalInputValue) {
            createLayer({
                source: { project, category, map },
                form: {
                    name: this.state.modalInputValue,
                    map: map.sid,
                    author: map.author.sid,
                    project,
                    category,
                },
            });
            this.handleCloseModals();
        } else {
            this.setState({
                status: "error",
                errorMessage: "Имя слоя не может быть пустым",
            });
        }
    };

    handleUpdateLayer = () => {
        const {
            project, category, map, selectedLayer, updateLayer,
        } = this.props;
        if (this.state.modalInputValue) {
            updateLayer({
                source: {
                    project, category, map, sid: selectedLayer.sid,
                },
                form: {
                    name: this.state.modalInputValue,
                    project,
                    category,
                },
            });
            this.handleCloseModals();
        } else {
            this.setState({
                status: "error",
                errorMessage: "Имя слоя не может быть пустым",
            });
        }
    };

    handleDeleteLayer = () => {
        const {
            project, category, map, selectedLayer, deleteLayer,
        } = this.props;
        deleteLayer({
            source: {
                project, category, map, sid: selectedLayer.sid,
            },
        });
        this.handleCloseModals();
    };

    render() {
        const {
            map,
            selectedLayer,
        } = this.props;

        const {
            creatingLayer,
            editingLayer,
            deletingLayer,
            modalInputValue,
            deleteButtonAvailable,
        } = this.state;

        return (
            <div className="layer-controls">
                <Select value={selectedLayer.sid} onChange={this.onChangeLayers}>
                    {
                        map.layers.map((layer) => <Option key={layer.sid}>{layer.name}</Option>)
                    }
                </Select>
                {/* Create layer */}
                <Button onClick={this.handleOpenCreateModal} title="Создать слой">
                    <img src={iconAdd} alt="Добавить слой" />
                </Button>
                <Modal
                    title="Создание слоя"
                    visible={creatingLayer}
                    onOk={this.handleCreateLayer}
                    onCancel={this.handleCloseModals}
                >
                    <Form.Item validateStatus={this.state.status} help={this.state.errorMessage}>
                        <Input placeholder="Имя слоя" value={modalInputValue} onChange={this.handleInputChange} />
                    </Form.Item>
                </Modal>

                {/* Edit layer */}
                <Button onClick={this.handleOpenEditModal} title="Редактировать слой">
                    <img src={iconEdit} alt="Редактировать слой" />
                </Button>
                <Modal
                    title="Редактирование слоя"
                    visible={editingLayer}
                    onOk={this.handleUpdateLayer}
                    onCancel={this.handleCloseModals}
                >
                    <Form.Item validateStatus={this.state.status} help={this.state.errorMessage}>
                        <Input placeholder="Имя слоя" value={modalInputValue} onChange={this.handleInputChange} />
                    </Form.Item>
                </Modal>

                {/* Delete layer */}
                <Button onClick={this.handleOpenDeleteModal} title="Удалить слой">
                    <img src={iconDelete} alt="Удалить слой" />
                </Button>
                <Modal
                    title="Удаление слоя"
                    visible={deletingLayer}
                    onOk={this.handleDeleteLayer}
                    onCancel={this.handleCloseModals}
                    footer={[
                        <Button key="back" onClick={this.handleCloseModals}>
                            ОТМЕНА
                        </Button>,
                        <Button
                            key="submit"
                            type="danger"
                            disabled={!deleteButtonAvailable}
                            onClick={this.handleDeleteLayer}
                        >
                            УДАЛИТЬ
                        </Button>,
                    ]}
                >
                    <div>
                        Вы точно хотите
                        <b>удалить</b>
                        {" "}
                        слой:
                        {this.props.selectedLayer.name}
                        ?
                    </div>
                </Modal>
            </div>
        );
    }
}

const mapStateToProps = (state) => ({
    documents: selectCurrentProjectDocuments(state),
    project: selectActiveProject(state),
    category: currentCategory(state),
    selectedLayer: selectedLayer(state),
});

export default connect(mapStateToProps, {
    createLayer: layersCRUDActions.use.CREATE_ENTITY,
    updateLayer: layersCRUDActions.use.UPDATE_ENTITY,
    deleteLayer: layersCRUDActions.use.DELETE_ENTITY,
    onLayerSelected: selectLayerAction,
})(LayersControls);
