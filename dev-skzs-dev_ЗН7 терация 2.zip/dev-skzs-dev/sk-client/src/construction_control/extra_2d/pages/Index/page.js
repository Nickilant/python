import React, { Component } from "react";
import { Button, Modal, Spin } from "antd";
import "./styles.scss";
import "ol/ol.css";
import { connect } from "react-redux";
import Dropzone from "react-dropzone";
import cx from "classnames";
import { push } from "connected-react-router";
import { TreeStructureContainer } from "../../../../categories/containers/TreeStructure/container";

import noMapIcon from "./assets/no_map_icon.svg";
import {
    geoMarkersCRUDActions,
    layersCRUDActions,
    mapsCRUDActions,
    markerCreatingAction,
} from "../../actions/actions";
import { selectActiveProject } from "../../../../projects/selectors/projects";
import { currentCategory } from "../../../../categories/selectors/treeStructure";
import {
    filteredGeoMarkers,
    getMarkerDocument,
    mapsListPending,
    selectedDocumentTypes,
    selectedLayer,
    selectedMap,
    selectedStatuses,
} from "../../selectors/maps";
import { MapComponent } from "../../components/MapComponent/MapComponent";
import { openRightColumnContainerAction } from "../../../../shared/actions/RightColumnContainer/actions";
import { documentsCRUDActions } from "../../../../documents/actions/actions";
import { commentsCRUDActions } from "../../../../comments/actions/actions";
import { selectCurrentProjectDocuments, selectedDocumentView } from "../../../../documents/selectors/documents";
import MapItemsControlsContainer from "../../containers/MapItemsControls/container";
import { CCFiltersWidget } from "../../containers/CCFilters/container";
import { DocumentAttachment } from "../../containers/DocumentAttchment/container";
import { openAttachmentFormAction } from "../../actions/DocumentAttachment/actions";
import { FileAttachment } from "../../../../documents/containers/FileAttachment/container";
import { canAddGeotagPredicate, canCreateDocument, canDeleteDocument } from "../../../base/selectors/permissions";
import { DOCUMENT_TYPES } from "../../../../documents/constants/types";

class ConstructionControlGeoDataPageComponent extends Component {
    constructor(props) {
        super(props);

        this.state = {
            mapDeleting: false,
            deleteModalVisible: false,
            deleteButtonAvailable: true,
            markerAdd: false,
            textFilter: null,
        };

        this.onDrop = (acceptedFiles) => {
            const file = acceptedFiles[0];
            const { project, category, createMap } = this.props;
            createMap({
                source: { project, category },
                form: { file, project, category },
            });
        };
    }

    componentDidUpdate(prevProps, prevState, snapshot) {
        if (this.props.map !== prevProps.map) {
            this.setState({ mapDeleting: false });
        }
    }

    handleOpenDeleteModal = () => {
        this.setState({ deleteModalVisible: true, deleteButtonAvailable: false });
        setTimeout(() => {
            this.setState({ deleteButtonAvailable: true });
        }, 3000);
    };

    handleCloseDeleteModal = () => {
        this.setState({ deleteModalVisible: false });
    };

    handleDeleteMap = () => {
        this.handleCloseDeleteModal();
        const { project, category, map } = this.props;
        if (map) {
            this.setState({ mapDeleting: true });
            const { sid } = map;
            this.props.deleteMap({
                source: { project, category, sid },
            });
        }
    };

    toggleCreateMarker = () => {
        if (this.props.markerDocument && this.state.markerAdd) {
            this.props.markerCreating(null);
            this.setState({ markerAdd: false });
        } else {
            this.props.openAttachmentForm();
        }
    };

    handleCreateMarker = (coordinate) => {
        if (coordinate === null || !this.props.markerDocument) {
            return; // Click was outside the map container
        }

        const {
            project, category, map, selectedLayer,
        } = this.props;

        this.setState({ markerAdd: false });
        const document = this.props.documents.find((it) => it.id === this.props.markerDocument.id);

        // Incrementing index for existing marker names if any
        const initMarkerName = `${category.name} / ${selectedLayer.name}`;
        let newMarkerName = `${initMarkerName}`;
        const byName = (it) => it.name === newMarkerName;
        let geoMarker = selectedLayer.geo_markers.find(byName);
        let postfix = 2;
        while (geoMarker) {
            newMarkerName = `${initMarkerName} / ${postfix}`;
            geoMarker = selectedLayer.geo_markers.find(byName);
            ++postfix;
        }

        if (this.props.markerDocument.type === "document") {
            this.props.createMarker({
                source: { project, category, map },
                form: {
                    coordinate_x: coordinate[0],
                    coordinate_y: coordinate[1],
                    map: map.sid,
                    project,
                    category,
                    layer: selectedLayer.sid,
                    name: newMarkerName,
                    document_type: document.type,
                    document_sid: this.props.markerDocument.id,
                    type: this.props.markerDocument.type,
                },
            });
        } else {
            this.props.createMarker({
                source: { project, category, map },
                form: {
                    coordinate_x: coordinate[0],
                    coordinate_y: coordinate[1],
                    map: map.sid,
                    project,
                    category,
                    layer: selectedLayer.sid,
                    name: newMarkerName,
                    category_sid: this.props.markerDocument.id,
                    type: "map-link",
                },
            });
        }

        this.props.markerCreating(null);
    };

    handleUpdateMarker = (marker, data) => {
        const {
            project, category, map, updateMarker,
        } = this.props;
        updateMarker({
            source: {
                project,
                category,
                map,
                sid: marker.sid,
            },
            form: { ...data },
        });
    };

    handleDeleteMarker = (sid) => {
        const {
            project, category, map, deleteMarker,
        } = this.props;
        deleteMarker({
            source: {
                project, category, map, sid,
            },
        });
    };

    render() {
        const {
            mapsListPending,
            map,
            documentTypes,
            selectedTypes,
            selectedLayer,
            filteredGeoMarkers,
            project,
            documents,
            openRightColumn,
            selectDocument,
            openDocumentDetails,
            statusesCounters,
            markersForStatuses,
            canCreateMap,
            canCreateGeotagForMap,
            canCreateGeotagForAct,
            canCreateGeotagForPrescription,
            canDeleteMap,
        } = this.props;

        let {
            deleteModalVisible,
            deleteButtonAvailable,
            mapDeleting,
            markerAdd,
        } = this.state;

        markerAdd = !!this.props.markerDocument;
        const mapTilesReady = map && map.tiles_link;

        return (
            <div className="construction-control-module construction-control-module-2d construction-control-geodata-page columns">
                { this.props.attachmentFormOpened && <FileAttachment /> }
                { this.props.markerAttachmentFormOpened && <DocumentAttachment /> }
                <TreeStructureContainer treeName="documents-list" sectionOverride="construction-control" />
                <div className="content">
                    {map && (
                        <div className="controls-container">
                            <div className="crud">
                                {
                                    (canCreateGeotagForAct || canCreateGeotagForMap || canCreateGeotagForPrescription) && (
                                        <Button
                                            id="create"
                                            onClick={this.toggleCreateMarker}
                                            disabled={!mapTilesReady}
                                        >
                                            {!markerAdd ? "Создать метку" : "Отмена"}
                                        </Button>
                                    )
                                }
                                {
                                    canDeleteMap && <Button id="delete" onClick={this.handleOpenDeleteModal}>Удалить карту-план</Button>
                                }
                                <Modal
                                    title="Удаление карты-плана"
                                    visible={deleteModalVisible}
                                    onOk={this.handleDeleteMap}
                                    onCancel={this.handleCloseDeleteModal}
                                    footer={[
                                        <Button key="back" onClick={this.handleCloseDeleteModal}>
                                            ОТМЕНА
                                        </Button>,
                                        <Button
                                            key="submit"
                                            type="danger"
                                            disabled={!deleteButtonAvailable}
                                            onClick={this.handleDeleteMap}
                                        >
                                            УДАЛИТЬ
                                        </Button>,
                                    ]}
                                >
                                    <div>
                                        Вы точно хотите
                                        <b>удалить</b>
                                        {" "}
                                        карту-план?
                                    </div>
                                </Modal>
                                <CCFiltersWidget statusesCounters={statusesCounters} markers={markersForStatuses} />
                            </div>
                            <MapItemsControlsContainer
                                selectedTypes={selectedTypes}
                                documentTypes={documentTypes}
                            />
                        </div>
                    )}

                    <div className="map-container">
                        {
                            map
                                ? mapTilesReady && documents.length && !mapDeleting
                                    ? (
                                        <MapComponent
                                            key={map.sid}
                                            map={map}
                                            layer={selectedLayer}
                                            filteredGeoMarkers={filteredGeoMarkers}
                                            markerAdd={markerAdd}
                                            project={project}
                                            documents={documents}
                                            openRightColumn={openRightColumn}
                                            selectDocument={selectDocument}
                                            openDocumentDetails={openDocumentDetails}
                                            handleCreateMarker={(coordinate) => this.handleCreateMarker(coordinate)}
                                            handleUpdateMarker={(marker, data) => this.handleUpdateMarker(marker, data)}
                                            handleDeleteMarker={(sid) => this.handleDeleteMarker(sid)}
                                        />
                                    )
                                    : (
                                        <div className="map-loading">
                                            <div>
                                                <div><Spin size="large" /></div>
                                                <div>Идёт подготовка карты...</div>
                                            </div>
                                        </div>
                                    )
                                : (
                                    !mapsListPending ? (
                                        <div className="no-map-message">
                                            {canCreateMap ? (
                                                <Dropzone onDrop={this.onDrop}>
                                                    {
                                                        ({ getRootProps, getInputProps }) => (
                                                            <div {...getRootProps({ className: cx("upload-space", { active: true }) })}>
                                                                <input {...getInputProps()} />
                                                                <div className="description">
                                                                    <img src={noMapIcon} alt="Карта отсутствует" />
                                                                    <div>Карта или генплан отсутствуют</div>
                                                                    <div className="bg-img icon icon-upload" />
                                                                    <div className="text">
                                                                        Перетащите нужные файлы прямо
                                                                        сюда
                                                                    </div>
                                                                    <div className="or">или</div>
                                                                    <span className="upload-button">
                                                                        Выбрать документ для создания подосновы
                                                                    </span>
                                                                </div>
                                                            </div>

                                                        )
                                                    }
                                                </Dropzone>
                                            )
                                                : (
                                                    <div className="description">
                                                        <img src={noMapIcon} alt="Карта отсутствует" />
                                                        <div>Карта или генплан отсутствуют</div>
                                                    </div>
                                                )}
                                        </div>
                                    ) : (
                                        <div className="map-loading">
                                            <div>
                                                <div><Spin size="large" /></div>
                                                <div>Идёт загрузка карты...</div>
                                            </div>
                                        </div>
                                    )
                                )
                        }
                    </div>
                </div>
            </div>
        );
    }
}

const mapStateToProps = (state) => {
    const documents = selectCurrentProjectDocuments(state);
    const layer = selectedLayer(state);
    const documentTypes = [];

    const markerTypes = {
        prescription: "Предписания",
        remark: "Замечания",
        act: "Акты",
        map: "Карты",
        aosr: "АОСР",
    };

    if (layer) {
        layer.geo_markers.forEach((it) => {
            const type = it.document.type.toLowerCase();
            if (!documentTypes.find((it) => it.value === type)) {
                documentTypes.push({
                    value: type,
                    title: markerTypes[type],
                });
            }
        });
    }

    let filteredMarkers = filteredGeoMarkers(state);
    const statusesCounters = {};

    filteredMarkers.forEach((it) => {
        if (statusesCounters.all === undefined) {
            statusesCounters.all = 1;
        } else {
            statusesCounters.all += 1;
        }

        if (it.source && it.source.status) {
            if (statusesCounters[it.source.status] === undefined) {
                statusesCounters[it.source.status] = 1;
            } else {
                statusesCounters[it.source.status] += 1;
            }
        }
    });

    // Filter by status
    const statuses = selectedStatuses(state);
    if (statuses) {
        filteredMarkers = filteredMarkers.filter(
            (it) => it.source.status && statuses.includes(it.source.status.toLowerCase()),
        );
    }

    const mappedMarkers = {};
    filteredMarkers.forEach((it) => mappedMarkers[it.sid] = it);

    return {
        documents,
        documentTypes,
        project: selectActiveProject(state),
        category: currentCategory(state),
        map: selectedMap(state),
        mapsListPending: mapsListPending(state),
        selectedLayer: layer,
        selectedTypes: selectedDocumentTypes(state),
        statusesCounters,
        markersForStatuses: filteredGeoMarkers(state),
        filteredGeoMarkers: mappedMarkers,
        selectedGroup: state.categories.treeStructure["documents-list"].selectedNode,
        selectedSection: state.categories.treeStructure["documents-list"].section,
        selectedDocument: selectedDocumentView(state), // TODO: something else,
        routerPathParams: state.core.router,
        markerDocument: getMarkerDocument(state),
        markerAttachmentFormOpened: state.constructionControl.extra2d.page.attachmentFormOpened,
        attachmentFormOpened: state.documents.attachmentForm.attachmentFormOpened,
        canCreateMap: canCreateDocument(state, DOCUMENT_TYPES.MAP),
        canCreateGeotagForMap: canAddGeotagPredicate(state, DOCUMENT_TYPES.MAP),
        canCreateGeotagForAct: canAddGeotagPredicate(state, DOCUMENT_TYPES.ACT),
        canCreateGeotagForPrescription: canAddGeotagPredicate(state, DOCUMENT_TYPES.PRESCRIPTION),
        canDeleteMap: canDeleteDocument(state, DOCUMENT_TYPES.MAP),
    };
};

export const ConstructionControlGeoDataPage = connect(
    mapStateToProps,
    {
        openRightColumn: openRightColumnContainerAction,
        markerCreating: markerCreatingAction,

        selectDocument: documentsCRUDActions.use.SELECT_SINGLE_ENTITY,
        openDocumentDetails: documentsCRUDActions.use.ENTITY_PREVIEW,
        loadComments: commentsCRUDActions.use.LIST_ENTITIES,

        createMap: mapsCRUDActions.use.CREATE_ENTITY,
        deleteMap: mapsCRUDActions.use.DELETE_ENTITY,

        createLayer: layersCRUDActions.use.CREATE_ENTITY,
        updateLayer: layersCRUDActions.use.UPDATE_ENTITY,
        deleteLayer: layersCRUDActions.use.DELETE_ENTITY,

        createMarker: geoMarkersCRUDActions.use.CREATE_ENTITY,
        updateMarker: geoMarkersCRUDActions.use.UPDATE_ENTITY,
        deleteMarker: geoMarkersCRUDActions.use.DELETE_ENTITY,

        pushUrl: push,
        openAttachmentForm: openAttachmentFormAction,
    },
)(ConstructionControlGeoDataPageComponent);
