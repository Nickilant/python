import React from "react";
import { connect } from "react-redux";

import { UniversalStatusFilters } from "../../../../executive_documentation/widgets/UniversalStatusFilters/component";
import { infoContent } from "../../../base/containers/PrescriptionFilters/container";
import { setStatusesFilterAction } from "../../actions/actions";
import { statuses } from "../../../base/containers/PrescriptionFilters/statuses";

import "./styles.scss";

function CCFiltersContainer(props) {
    const {
        statusesCounters,
        setStatusesFilter,
        markers,
    } = props;

    const items = Object.values(markers).reduce((acc, val) => (val.source ? [...acc, val.source] : acc), []);

    return (
        <UniversalStatusFilters
            title="Всего меток:"
            statuses={statuses}
            infoContent={infoContent}
            setActionReducer={(it) => setStatusesFilter(it.statusFilters.length ? it.statusFilters : null)}
            items={items}
            allConfig={{
                count: statusesCounters.all,
            }}
        />
    );
}

export const CCFiltersWidget = connect(() => ({}), {
    setStatusesFilter: setStatusesFilterAction,
})(CCFiltersContainer);
