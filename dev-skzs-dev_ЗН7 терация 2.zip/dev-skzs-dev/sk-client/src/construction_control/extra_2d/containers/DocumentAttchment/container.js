import React, { useCallback, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Input } from "antd";
import "./styles.scss";
import cx from "classnames";
import { TreeStructureContainer } from "../../../../categories/containers/TreeStructure/container";
import { selectCurrentProjectDocuments } from "../../../../documents/selectors/documents";
import { SectionDocumentListItem } from "../../../../documents/components/SectionDocumentsListItem/component";
import {
    attachToDocumentAction,
    closeAttachmentFormAction,
    searchDocumentsAction,
    setModeAction,
} from "../../actions/DocumentAttachment/actions";
import { search } from "../../selectors/attachmentForm";
import { markerCreatingAction } from "../../actions/actions";
import { canAddGeotagPredicate } from "../../../base/selectors/permissions";
import { DOCUMENT_TYPES } from "../../../../documents/constants/types";

const { Search } = Input;

export const DocumentAttachment = () => {
    // Dispatch
    const dispatch = useDispatch();

    // Selectors
    const unfilteredDocs = useSelector(selectCurrentProjectDocuments);
    const searchQuery = useSelector((state) => state.constructionControl.extra2d.page.attachmentFormQuery);
    const documents = search(unfilteredDocs, searchQuery);
    const mode = useSelector((state) => state.constructionControl.extra2d.page.attachmentFormMode);
    const selectedCategory = useSelector((state) => state.categories.treeStructure["document-attachment"].selectedNode);
    const selectedDocument = useSelector((state) => state.constructionControl.extra2d.page.attachmentFormSelectedDocument);

    // Handlers
    const handleSelectDocument = (id) => {
        dispatch(attachToDocumentAction(id));
    };

    const closeAttachmentForm = () => {
        dispatch(closeAttachmentFormAction());
    };

    const handleSetMode = (type) => {
        dispatch(setModeAction(type));
    };

    const handleSearch = (query) => {
        dispatch(searchDocumentsAction(query));
    };

    const handleSubmitForm = () => {
        let entity;

        if (mode === "document") {
            entity = selectedDocument;
        } else if (mode === "category") {
            entity = selectedCategory;
        }

        if (entity) {
            closeAttachmentForm();
            dispatch(markerCreatingAction({
                type: mode,
                id: entity,
            }));
        }
    };

    const canAddGeotagJump = useSelector((state) => canAddGeotagPredicate(state, DOCUMENT_TYPES.MAP));
    const canAddGeotag = useSelector((state) => canAddGeotagPredicate(state, DOCUMENT_TYPES.PRESCRIPTION) || canAddGeotagPredicate(state, DOCUMENT_TYPES.ACT));
    const canCreateGeotagForAct = useSelector((state) => canAddGeotagPredicate(state, DOCUMENT_TYPES.ACT));
    const canCreateGeotagForPrescription = useSelector((state) => canAddGeotagPredicate(state, DOCUMENT_TYPES.PRESCRIPTION));

    useEffect(() => {
        if (canAddGeotagJump) {
            handleSetMode("category");
        }
        if (canAddGeotag) {
            handleSetMode("document");
        }
    }, []);

    return (
        <div
            className="document-attachment-form-wrapper"
            onClick={(e) => (e.currentTarget === e.target ? closeAttachmentForm() : null)}
        >
            <div className="file-attachment-form">
                <div className="head">
                    <div className="block-title">Прикрепление геометки</div>
                    <div
                        className="close-icon bg-img"
                        onClick={
                            closeAttachmentForm
                        }
                    />
                </div>
                <div className="select-section">
                    <div className="sections-list">
                        <div className="sections">
                            {
                                [
                                    { id: "category", title: "Переход на другую карту" },
                                    { id: "document", title: "Ссылка на документ" },
                                ].filter((it) => {
                                    if (it.id === "category" && canAddGeotagJump) {
                                        return true;
                                    }
                                    if (it.id === "document" && canAddGeotag) {
                                        return true;
                                    }
                                    return false;
                                }).map(({ id, title }) => (
                                    <div
                                        className={cx("section", { active: mode === id })}
                                        onClick={() => handleSetMode(id)}
                                        key={id}
                                    >
                                        <div className={`icon icon-${id}`} />
                                        {title}
                                    </div>
                                ))
                            }
                        </div>
                    </div>
                </div>
                <div className="data">

                    {
                        mode === "category"
                    && (
                        <div className="groups-list">
                            <div className="block-title">
                                Выберите категорию
                            </div>
                            <div className="tree-wrapper">
                                <TreeStructureContainer sectionOverride="construction-control" treeName="document-attachment" />
                            </div>
                        </div>
                    )
                    }
                    {
                        mode === "document"

                && (
                    <div className="files-list">
                        <div className="filters-wrapper">
                            <div className="block-title">
                                Выберите документ
                            </div>
                            <div className="filters">
                                <div className="search-bar">
                                    <Search
                                        allowClear
                                        placeholder="Поиск по названию"
                                        onSearch={
                                            handleSearch
                                        }
                                    />
                                </div>
                            </div>
                        </div>
                        <div className="files-wrapper ">
                            <div className="files">
                                {/* <div className="head" /> */}
                                <div className="list">

                                    {documents
                                        .filter((it) => {
                                            if (it.type === DOCUMENT_TYPES.PRESCRIPTION && canCreateGeotagForPrescription) {
                                                return true;
                                            }
                                            if (it.type === DOCUMENT_TYPES.ACT && canCreateGeotagForAct) {
                                                return true;
                                            }
                                            return false;
                                        })
                                        .map((item) => (
                                            <div
                                                className="list-item"
                                                key={item.id}
                                            >
                                                <SectionDocumentListItem
                                                    id={item.id}
                                                    item={item}
                                                    showActions={false}
                                                    currentItem={selectedDocument === item.id}
                                                    onSelect={handleSelectDocument}
                                                />
                                            </div>
                                        ))}
                                </div>
                            </div>

                        </div>
                    </div>
                )
                    }
                    <button
                        className="attach-files attachment"
                        onClick={
                            handleSubmitForm
                        }
                    >
                        Прикрепить
                    </button>
                </div>
            </div>

        </div>
    );
};
