import React from "react";
import cx from "classnames";
import { connect } from "react-redux";
import { without } from "lodash";
import LayersControlsComponent from "../../components/LayersControls/component";

import "./styles.scss";
import { Input } from "antd";
import { selectCurrentProjectDocuments } from "../../../../documents/selectors/documents";
import { selectActiveProject } from "../../../../projects/selectors/projects";
import { currentCategory } from "../../../../categories/selectors/treeStructure";
import { getMarkerTextFilter, selectedMap } from "../../selectors/maps";
import { setStatusesFilterAction, setTextFilterAction, setTypesFilterAction } from "../../actions/actions";

const { Search } = Input;

class MapItemsControlsContainer extends React.Component {
    handleToggleAttribute = (type) => () => {
        if (type === null) this.props.setTypesFilter(null);
        else {
            let selected = this.props.selectedTypes;

            if (selected === null) {
                selected = [];
            }

            let updated = [];

            if (selected.includes(type)) {
                updated = without(selected, type);
            } else {
                updated = [...selected, type];
            }

            if (updated.length === 0) updated = null;

            this.props.setTypesFilter(updated);
        }
    };

    render() {
        const {
            setTextFilter, map, documentTypes, selectedTypes, markerTextFilter,
        } = this.props;

        return (
            <div className="feature-search">
                <div className="search-bar">
                    <Search
                        allowClear
                        placeholder="Поиск по названию"
                        value={markerTextFilter}
                        onChange={(e) => setTextFilter(e.target.value)}
                    />
                </div>

                <div className="map-toolbar">
                    <div className="attributes">
                        <button
                            onClick={this.handleToggleAttribute(null)}
                            className={cx("attribute", "toggle-all-button", { active: selectedTypes === null })}
                        >
                            Все
                        </button>
                        {
                            documentTypes.map((item) => (
                                <button
                                    onClick={this.handleToggleAttribute(item.value)}
                                    className={cx("attribute", { active: selectedTypes && selectedTypes.includes(item.value) })}
                                    key={item.value}
                                >
                                    {item.title}
                                </button>
                            ))
                        }
                    </div>
                    {/* { */}
                    {/*    map && map.layers && map.layers.length > 0 && <LayersControlsComponent map={map} /> */}
                    {/* } */}
                </div>
            </div>
        );
    }
}

const mapStateToProps = (state) => ({
    documents: selectCurrentProjectDocuments(state),
    project: selectActiveProject(state),
    category: currentCategory(state),
    map: selectedMap(state),
    markerTextFilter: getMarkerTextFilter(state),
});

export default connect(mapStateToProps, {
    setTextFilter: setTextFilterAction,
    setStatusesFilter: setStatusesFilterAction,
    setTypesFilter: setTypesFilterAction,
})(MapItemsControlsContainer);
