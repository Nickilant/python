import { selectedCategory } from "../../../categories/selectors/treeStructure";

export const selectedMap = (state) => {
    const maps = Object.values(state.constructionControl.extra2d.mapsCrud.items);
    if (maps) {
        return maps.find((it) => it.project_document.related_category === selectedCategory(state));
    }
};

export const mapsListPending = (state) => state.constructionControl.extra2d.mapsCrud.isListPending;

export const selectedLayer = (state) => {
    const map = selectedMap(state);
    if (map) {
        let layer = map.layers.find((it) => it.sid === selectedLayerId(state));
        if (!layer) {
            layer = map.layers[0];
        }

        return layer;
    }
};

export const selectedLayerId = (state) => state.constructionControl.extra2d.layersReducer.selectedLayerId || selectedMap(state).layers[0].sid;

export const selectedGeotag = (state) => state.constructionControl.geotags.selectedGeotag;

export const filteredGeoMarkers = (state) => {
    const map = selectedMap(state);
    if (map) {
        const layer = selectedLayer(state);
        if (layer) {
            let filteredMarkers = [...layer.geo_markers];

            filteredMarkers.forEach((it) => {
                const documentSid = it.document[it.document.type.toLowerCase()];
                it.source = state.documents.crud.items[documentSid];
            });

            // Filter by text
            const { textFilter } = state.constructionControl.extra2d.page;
            if (textFilter) {
                filteredMarkers = filteredMarkers.filter((it) => {
                    if (it.document) {
                        if (it.source.type !== "map") {
                            return it.source.title.toLowerCase().includes(textFilter);
                        }
                        const category = state.categories.crud.items[it.source.group];
                        return category.name.toLowerCase().includes(textFilter);
                    }
                    return true; // TODO: filter categories
                });
            }

            // Filter by type
            const documentTypes = selectedDocumentTypes(state);
            if (documentTypes) {
                filteredMarkers = filteredMarkers.filter((it) => documentTypes.includes(it.document.type.toLowerCase()));
            }

            return filteredMarkers;
        }
        return [];
    }
    return [];
};

export const selectedDocumentTypes = (state) => state.constructionControl.extra2d.page.types;
export const selectedStatuses = (state) => state.constructionControl.extra2d.page.statuses;
export const getMarkerDocument = (state) => state.constructionControl.extra2d.page.markerDocument;
export const getMarkerTextFilter = (state) => state.constructionControl.extra2d.page.textFilter;
