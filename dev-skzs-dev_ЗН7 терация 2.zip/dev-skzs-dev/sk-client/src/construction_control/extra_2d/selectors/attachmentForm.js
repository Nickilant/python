export const search = (array, str) => {
    if (!str) return array;

    const searchStr = str.toLowerCase();

    const foundFields = array.filter((item) => {
        const value = item.title.toLowerCase();
        return value.indexOf(searchStr) + 1;
    });

    return foundFields;
};
