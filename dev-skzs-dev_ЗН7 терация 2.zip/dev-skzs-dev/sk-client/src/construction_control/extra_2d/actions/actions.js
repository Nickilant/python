import { getCRUDEntityActions } from "../../../shared/actions/entityCrudActions";
import {
    LAYER_ENTITY_NAME, MAP_ENTITY_NAME, MARKER_ENTITY_NAME, MODULE_NAME,
} from "../constants/extra_2d";
import { CONSTRUCTION_CONTROL_EXTRA2D, LAYERS_LAYER_SELECTED } from "./actionTypes";

export const mapsCRUDActions = getCRUDEntityActions(MODULE_NAME, MAP_ENTITY_NAME);
export const layersCRUDActions = getCRUDEntityActions(MODULE_NAME, LAYER_ENTITY_NAME);
export const geoMarkersCRUDActions = getCRUDEntityActions(MODULE_NAME, MARKER_ENTITY_NAME);

export const selectLayerAction = (sid) => ({
    type: LAYERS_LAYER_SELECTED,
    payload: { sid },
});

export const setTextFilterAction = (text) => ({
    type: CONSTRUCTION_CONTROL_EXTRA2D.SET_TEXT_FILTER,
    payload: { text },
});

export const setStatusesFilterAction = (statuses) => ({
    type: CONSTRUCTION_CONTROL_EXTRA2D.SET_STATUSES_FILTER,
    payload: { statuses },
});

export const setTypesFilterAction = (types) => ({
    type: CONSTRUCTION_CONTROL_EXTRA2D.SET_TYPES_FILTER,
    payload: { types },
});

export const markerCreatingAction = (creating) => ({
    type: CONSTRUCTION_CONTROL_EXTRA2D.MARKER_CREATING,
    payload: creating,
});
