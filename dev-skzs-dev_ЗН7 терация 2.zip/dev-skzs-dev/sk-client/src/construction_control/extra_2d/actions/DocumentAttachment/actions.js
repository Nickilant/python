import {
    DOCUMENT_ATTACHMENT_DOCUMENT_LIST_SEARCH,
    DOCUMENT_ATTACHMENT_FORM_ATTACH_TO_CATEGORY,
    DOCUMENT_ATTACHMENT_FORM_ATTACH_TO_DOCUMENT,
    DOCUMENT_ATTACHMENT_FORM_CLOSE,
    DOCUMENT_ATTACHMENT_FORM_OPEN,
    DOCUMENT_ATTACHMENT_SET_MODE,
} from "./actionTypes";

export const setModeAction = (mode) => ({
    type: DOCUMENT_ATTACHMENT_SET_MODE,
    payload: {
        mode,
    },
});

export const openAttachmentFormAction = () => ({
    type: DOCUMENT_ATTACHMENT_FORM_OPEN,
});

export const closeAttachmentFormAction = () => ({
    type: DOCUMENT_ATTACHMENT_FORM_CLOSE,
});

export const attachToCategoryAction = (sid) => ({
    type: DOCUMENT_ATTACHMENT_FORM_ATTACH_TO_CATEGORY,
    payload: {
        sid,
    },
});

export const attachToDocumentAction = (sid) => ({
    type: DOCUMENT_ATTACHMENT_FORM_ATTACH_TO_DOCUMENT,
    payload: {
        sid,
    },
});

export const searchDocumentsAction = (query) => ({
    type: DOCUMENT_ATTACHMENT_DOCUMENT_LIST_SEARCH,
    payload: {
        query,
    },
});
