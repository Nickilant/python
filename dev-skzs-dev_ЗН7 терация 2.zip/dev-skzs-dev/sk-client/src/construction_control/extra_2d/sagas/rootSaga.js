import { all } from "@redux-saga/core/effects";
import { createCRUDSaga } from "../../../shared/sagas/entityCrudFactory";
import {
    LAYER_ENTITY_NAME, MAP_ENTITY_NAME, MARKER_ENTITY_NAME, MODULE_NAME,
} from "../constants/extra_2d";
import { mapsSaga } from "./maps";
import { markersSaga } from "./markers";
import { layersSaga } from "./layers";

const mapsCrudSaga = createCRUDSaga({
    moduleName: MODULE_NAME,
    entityName: MAP_ENTITY_NAME,

    getPrefixPath: ({ payload }) => `/projects/${payload.source.project.key}/categories/${payload.source.category.sid}/${MAP_ENTITY_NAME}s`,
});

const layersCrudSaga = createCRUDSaga({
    moduleName: MODULE_NAME,
    entityName: LAYER_ENTITY_NAME,

    getPrefixPath: ({ payload }) => `/projects/${payload.source.project.key}/categories/${payload.source.category.sid}/${MAP_ENTITY_NAME}s/${payload.source.map.sid}/${LAYER_ENTITY_NAME}s`,
});

const markersCrudSaga = createCRUDSaga({
    moduleName: MODULE_NAME,
    entityName: MARKER_ENTITY_NAME,

    getPrefixPath: ({ payload }) => `/projects/${payload.source.project.key}/categories/${payload.source.category.sid}/${MAP_ENTITY_NAME}s/${payload.source.map.sid}/${MARKER_ENTITY_NAME}s`,
});

export function* extra2dRootSaga() {
    yield all([
        mapsCrudSaga(),
        mapsSaga(),
        layersCrudSaga(),
        layersSaga(),
        markersCrudSaga(),
        markersSaga(),
    ]);
}
