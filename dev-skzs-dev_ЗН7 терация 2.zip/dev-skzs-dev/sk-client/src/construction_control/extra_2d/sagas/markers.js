import { put, take, takeEvery } from "@redux-saga/core/effects";
import { geoMarkersCRUDActions, mapsCRUDActions, setTextFilterAction } from "../actions/actions";
import { documentsCRUDActions } from "../../../documents/actions/actions";
import { TREE_STRUCTURE_SELECT_NODE } from "../../../categories/actions/actionTypes";
import { DOCUMENT_TO_MAP_TRANSITION } from "../../base/actions/actionTypes";

export function* markersSaga() {
    function* watchMarkersCreated({ payload }) {
        yield put(documentsCRUDActions.use.LIST_ENTITIES({
            source: {
                project: payload.source.project,
            },
        }));

        yield put(mapsCRUDActions.use.LIST_ENTITIES({
            source: {
                project: payload.source.project,
                category: payload.source.category,
            },
        }));
    }

    function* watchMarkersUpdated({ payload }) {
        yield put(mapsCRUDActions.use.LIST_ENTITIES({
            source: {
                project: payload.source.project,
                category: payload.source.category,
            },
        }));
    }

    function* watchMarkersDeleted({ payload }) {
        yield put(mapsCRUDActions.use.LIST_ENTITIES({
            source: {
                project: payload.source.project,
                category: payload.source.category,
            },
        }));

        if (payload.source.document) {
            yield put(documentsCRUDActions.use.GET_ENTITY_DETAILS({
                source: {
                    ...payload.source.document,
                    project: payload.source.project,
                },
            }));
        }
    }

    function* watchDocumentToMapTransition({ payload }) {
        yield take(TREE_STRUCTURE_SELECT_NODE);
        yield put(setTextFilterAction(payload.documentTitle));
    }

    yield takeEvery(geoMarkersCRUDActions.CREATE_ENTITY_COMPLETE, watchMarkersCreated);
    yield takeEvery(geoMarkersCRUDActions.UPDATE_ENTITY_COMPLETE, watchMarkersUpdated);
    yield takeEvery(geoMarkersCRUDActions.DELETE_ENTITY_COMPLETE, watchMarkersDeleted);
    yield takeEvery(DOCUMENT_TO_MAP_TRANSITION, watchDocumentToMapTransition);
}
