import { put, takeEvery } from "@redux-saga/core/effects";
import { layersCRUDActions, mapsCRUDActions } from "../actions/actions";

export function* layersSaga() {
    function* watchLayersCreated({ payload }) {
        yield put(mapsCRUDActions.use.LIST_ENTITIES({
            source: {
                project: payload.source.project,
                category: payload.source.category,
            },
        }));
    }

    function* watchLayersDeleted({ payload }) {
        yield put(mapsCRUDActions.use.LIST_ENTITIES({
            source: {
                project: payload.source.project,
                category: payload.source.category,
            },
        }));
    }

    function* watchLayersUpdated({ payload }) {
        yield put(mapsCRUDActions.use.LIST_ENTITIES({
            source: {
                project: payload.source.project,
                category: payload.source.category,
            },
        }));
    }

    yield takeEvery(layersCRUDActions.CREATE_ENTITY_COMPLETE, watchLayersCreated);
    yield takeEvery(layersCRUDActions.DELETE_ENTITY_COMPLETE, watchLayersDeleted);
    yield takeEvery(layersCRUDActions.UPDATE_ENTITY_COMPLETE, watchLayersUpdated);
}
