import {
    delay, put, select, takeEvery,
} from "@redux-saga/core/effects";
import { mapsCRUDActions } from "../actions/actions";
import { TREE_STRUCTURE_SELECT_NODE } from "../../../categories/actions/actionTypes";
import { selectActiveProject } from "../../../projects/selectors/projects";
import { mapsListPending, selectedMap } from "../selectors/maps";
import { currentCategory, selectedCategory } from "../../../categories/selectors/treeStructure";

export function* mapsSaga() {
    const watched = new Set();

    function* watchMapsCreated({ payload }) {
        const watchedCategory = payload.source.category.sid;

        if (watched.has(watchedCategory)) {
            return;
        }
        watched.add(watchedCategory);

        while (true) {
            // Update maps list immediately
            yield put(mapsCRUDActions.use.LIST_ENTITIES({
                source: {
                    project: payload.source.project,
                    category: payload.source.category,
                },
            }));
            // And throttle a little
            while (true) {
                const isListPending = yield select(mapsListPending);
                if (isListPending) {
                    yield delay(500);
                } else {
                    break;
                }
            }

            const loadedCategory = yield select(selectedCategory);
            const currentFullCategory = yield select(currentCategory);
            const loadedMap = yield select(selectedMap);
            // The "throttle" step should ensure that if there's a map then we'll catch it here
            if (!loadedMap) {
                watched.delete(watchedCategory);
                // Otherwise it's a category without a map
                return;
            }

            // TODO: actually inverse this and add MAP_CATEGORY type
            if ((currentFullCategory && currentFullCategory.type === "CALENDAR_CATEGORY")
                || (loadedMap && loadedMap.tiles_link !== null)
                || (loadedCategory !== watchedCategory)) {
                watched.delete(watchedCategory);
                return;
            }
            yield delay(5000);
        }
    }

    function* watchMapsDeleted({ payload }) {
        yield put(mapsCRUDActions.use.LIST_ENTITIES({
            source: {
                project: payload.source.project,
                category: payload.source.category,
            },
        }));
    }

    function* watchCategorySelected({ payload }) {
        if (payload.id === "undefined" || !payload.id || payload.treeName !== "documents-list") {
            return;
        }
        const project = yield select(selectActiveProject);
        yield watchMapsCreated({
            payload: {
                source: {
                    project,
                    category: { sid: payload.id },
                },
            },
        });
    }

    yield takeEvery(mapsCRUDActions.CREATE_ENTITY_COMPLETE, watchMapsCreated);
    yield takeEvery(mapsCRUDActions.DELETE_ENTITY_COMPLETE, watchMapsDeleted);
    yield takeEvery(TREE_STRUCTURE_SELECT_NODE, watchCategorySelected);
}
