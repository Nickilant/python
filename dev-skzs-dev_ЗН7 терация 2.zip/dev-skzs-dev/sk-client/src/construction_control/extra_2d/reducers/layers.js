import { LAYERS_LAYER_SELECTED } from "../actions/actionTypes";
import { TREE_STRUCTURE_SELECT_NODE } from "../../../categories/actions/actionTypes";

const initialState = {
    selectedLayerId: null,
};

export default (state = initialState, action) => {
    switch (action.type) {
        case TREE_STRUCTURE_SELECT_NODE:
            if (action.payload.treeName === "documents-list") {
                return {
                    ...state,
                    selectedLayerId: null,
                };
            }
            return state;

        case LAYERS_LAYER_SELECTED:
            const { sid } = action.payload;
            return {
                ...state,
                selectedLayerId: sid,
            };
        default:
            return state;
    }
};
