import { TREE_STRUCTURE_SELECT_NODE } from "../../../categories/actions/actionTypes";
import { CONSTRUCTION_CONTROL_EXTRA2D } from "../actions/actionTypes";
import {
    DOCUMENT_ATTACHMENT_DOCUMENT_LIST_SEARCH,
    DOCUMENT_ATTACHMENT_FORM_ATTACH_TO_DOCUMENT,
    DOCUMENT_ATTACHMENT_FORM_CLOSE,
    DOCUMENT_ATTACHMENT_FORM_OPEN,
    DOCUMENT_ATTACHMENT_SET_MODE,
} from "../actions/DocumentAttachment/actionTypes";

const initialState = {
    textFilter: null,
    statuses: null,
    types: null,
    attachmentFormOpened: false,
    attachmentFormQuery: "",
    attachmentFormMode: "document",
    attachmentFormSelectedDocument: null,
    markerDocument: null,
};

export const MapPageReducer = (state = initialState, action) => {
    switch (action.type) {
        case TREE_STRUCTURE_SELECT_NODE:
            if (action.payload.treeName === "documents-list") {
                return {
                    ...state,
                    textFilter: null,
                    types: null,
                    statuses: null,
                };
            }
            return state;

        case CONSTRUCTION_CONTROL_EXTRA2D.SET_TEXT_FILTER:
            return {
                ...state,
                textFilter: action.payload.text.toLowerCase(),
            };

        case CONSTRUCTION_CONTROL_EXTRA2D.SET_STATUSES_FILTER:
            return {
                ...state,
                statuses: action.payload.statuses,
            };

        case CONSTRUCTION_CONTROL_EXTRA2D.SET_TYPES_FILTER:
            return {
                ...state,
                types: action.payload.types,
            };

        case DOCUMENT_ATTACHMENT_FORM_OPEN: {
            return {
                ...state,
                attachmentFormOpened: true,
            };
        }
        case DOCUMENT_ATTACHMENT_FORM_CLOSE: {
            return {
                ...state,
                attachmentFormOpened: false,
            };
        }
        case DOCUMENT_ATTACHMENT_DOCUMENT_LIST_SEARCH: {
            return {
                ...state,
                attachmentFormQuery: action.payload.query,
            };
        }
        case DOCUMENT_ATTACHMENT_SET_MODE: {
            return {
                ...state,
                attachmentFormMode: action.payload.mode,
            };
        }
        case DOCUMENT_ATTACHMENT_FORM_ATTACH_TO_DOCUMENT: {
            return {
                ...state,
                attachmentFormSelectedDocument: action.payload.sid,
            };
        }

        case CONSTRUCTION_CONTROL_EXTRA2D.MARKER_CREATING: {
            return {
                ...state,
                markerDocument: action.payload,
            };
        }

        default:
            return state;
    }
};
