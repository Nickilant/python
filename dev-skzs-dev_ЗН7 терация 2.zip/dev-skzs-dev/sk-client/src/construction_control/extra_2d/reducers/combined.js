import { combineReducers } from "redux";
import { crudReducerFactory } from "../../../shared/reducers/crudFactory";
import {
    LAYER_ENTITY_NAME, MAP_ENTITY_NAME, MARKER_ENTITY_NAME, MODULE_NAME,
} from "../constants/extra_2d";
import layersReducer from "./layers";
import { MapPageReducer } from "./page";

export default combineReducers({
    mapsCrud: crudReducerFactory(MODULE_NAME, MAP_ENTITY_NAME, "sid"),
    layersCrud: crudReducerFactory(MODULE_NAME, LAYER_ENTITY_NAME, "sid"),
    layersReducer,
    page: MapPageReducer,
    geoMarkersCrud: crudReducerFactory(MODULE_NAME, MARKER_ENTITY_NAME, "sid"),
});
