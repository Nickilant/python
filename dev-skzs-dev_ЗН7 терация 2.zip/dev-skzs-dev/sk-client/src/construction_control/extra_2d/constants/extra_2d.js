export const MODULE_NAME = "construction_control_extra_2d";
export const MAP_ENTITY_NAME = "map";
export const LAYER_ENTITY_NAME = "layer";
export const MARKER_ENTITY_NAME = "marker";
