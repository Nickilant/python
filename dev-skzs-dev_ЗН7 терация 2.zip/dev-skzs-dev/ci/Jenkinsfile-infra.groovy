#!groovy

// populate variables from folder

withFolderProperties {
    DEPLOY_ENVIRONMENT = "${env.DEPLOY_ENVIRONMENT}"
    OCP_URL_TARGET = "${env.OCP_URL_TARGET}"
    OCP_CRED_ID = "${env.OCP_CRED_ID}"
    REGISTRY_TRUST = "${env.REGISTRY_TRUST}"
    REGISTRY_TRUST_CRED_ID = "${env.REGISTRY_TRUST_CRED_ID}"
    REGISTRY_DEV = "${env.REGISTRY_DEV}"
    REGISTRY_DEV_CRED_ID = "${env.REGISTRY_DEV_CRED_ID}"
    MIRROR_REGISTRY_DEV = "${env.MIRROR_REGISTRY_DEV}"
    MIRROR_REGISTRY_DEV_CRED_ID = "${env.MIRROR_REGISTRY_DEV_CRED_ID}"
}

if (DEPLOY_ENVIRONMENT == 'trust') {
    REGISTRY = REGISTRY_TRUST
    REGISTRY_CRED_ID = REGISTRY_TRUST_CRED_ID
    REGISTRY_LIST = [
            'registry.gazprom-neft.local',
            'rh-registry.gazprom-neft.local',
            'quay-registry.gazprom-neft.local',
            'ms-registry.gazprom-neft.local',
    ]
    REGISTRY_PORT = ':5000'
}

if (DEPLOY_ENVIRONMENT == 'dev') {
    REGISTRY = REGISTRY_DEV
    REGISTRY_CRED_ID = REGISTRY_DEV_CRED_ID
    REGISTRY_LIST = [
            'registry.dso.techpark.local',
            'rh-registry.dso.techpark.local',
            'quay-registry.dso.techpark.local',
            'ms-registry.dso.techpark.local',
            'mirror-registry.dso.techpark.local',
    ]
    REGISTRY_PORT = ''
}

if ("${params.DEPLOY_ENVIRONMENT}" == 'trust_to_dev') {
    REGISTRY = MIRROR_REGISTRY_DEV
    REGISTRY_CRED_ID = MIRROR_REGISTRY_DEV_CRED_ID
}

pipeline {

    agent {
        label "${DEPLOY_ENVIRONMENT}"
    }

    options {
        buildDiscarder(logRotator(numToKeepStr: '10', artifactNumToKeepStr: '10'))
    }

    environment {
        GIT_COMMIT_SHORT = sh(script: "printf \$(git rev-parse --short ${GIT_COMMIT})", returnStdout: true)
    }

    stages {
        stage("Set build name") {
            steps {
                // use name of the patchset as the build name

                wrap([$class: 'BuildUser']) {
                    script {
                        if ("${params.BRANCH}" == 'null') {
                            buildName "$BUILD_NUMBER-$GIT_COMMIT_SHORT"
                        } else {
                            buildName "$BUILD_NUMBER-$DEPLOY_ENVIRONMENT-${params.BRANCH}-$GIT_COMMIT_SHORT"
                        }
                    }

                    buildDescription "Executed @ ${NODE_NAME}. Build started by ${BUILD_USER}"

                }
            }
        }

        stage("OCP login") {
            steps {
                echo "=====ocp login====="
                withCredentials([string(credentialsId: "$OCP_CRED_ID", variable: 'TOKEN')]) {
                    sh """oc login $OCP_URL_TARGET --token $TOKEN"""
                }
            }
        }

        stage("OCP deploy/change templates") {
            steps {
                echo "=====ocp deploy/change templates====="
                script {
                    sh """oc process -f ci/common/oc/infra/infra.template.yml | oc apply -f -"""
                    //sh """oc exec skzs-mvp-backend-119-jx2z5 python3 manage.py migrate"""
                    //sh """oc exec skzs-mvp-backend-119-jx2z5 python3 manage.py seed_tz_project"""
                }
            }
        }

        stage("OCP create secrets for registry") {
            steps {
                echo "=====OCP create secrets for registry====="
                withCredentials([
                        usernamePassword(
                                credentialsId: "$REGISTRY_CRED_ID",
                                usernameVariable: 'USERNAME',
                                passwordVariable: 'PASSWORD'
                        )
                ]) {
                    script {
                        REGISTRY_LIST.each {
                            sh "oc create secret docker-registry ${it}" +
                                    " --docker-server=${it}${REGISTRY_PORT}" +
                                    " --docker-username=${USERNAME}" +
                                    " --docker-password=${PASSWORD}" +
                                    " --docker-email=koa@gazprom-neft.ru" + " || true"
                            sh "oc secrets link --for=pull default ${it}"
                        }
                    }
                }
            }
        }
    }
}

